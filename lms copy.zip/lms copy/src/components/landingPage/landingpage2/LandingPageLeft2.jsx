import React from "react";
import landingPage2 from "../../../assets/images/LandingPage2.png";

const LandingPageLeft2 = () => {
  return (
    <div>
      <img   className="page2-img" src={landingPage2} alt="landingPage2" />
    </div>
  );
};

export default LandingPageLeft2;
