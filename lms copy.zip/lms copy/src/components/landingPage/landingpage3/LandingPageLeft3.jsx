import React from "react";
// import Startedbutton from "../../share/Startedbutton";
import "./landingpage3-style.scss";
import CustomButton from "../../shared/button/Button";

const LandingPageLeft3 = () => {
  return (
    <div className="page3-right-container">
      <div>
        <p className="page3-heading">Products</p>
      </div>
      <div className="page3-context">
        <span className="page3-content-text">
          Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maiores
          impedit perferendis suscipit eaque, iste dolor cupiditate blanditiis
          ratione. Lorem ipsum, dolor sit amet consectetur adipisicing elit.
        </span>
      </div>
      <div >
        <CustomButton className="container-btn"  variant="primary" >LearnMore</CustomButton>
      </div>
    </div>
  );
};

export default LandingPageLeft3;
