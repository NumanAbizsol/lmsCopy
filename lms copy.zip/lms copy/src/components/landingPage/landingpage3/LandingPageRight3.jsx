import React from 'react'
import landingpageImage from '../../../assets/images/LandingPage3.png'
const LandingPageRight3 = () => {
  return (
    <div>
        <img className='pg3-img' src={landingpageImage} alt="landingpage3" />
    </div>
  )
}

export default LandingPageRight3