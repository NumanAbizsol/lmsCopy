import React from "react";
import "./landingpage4-style.scss";
import LandingPageLeft4 from "./LandingPageLeft4";
import LandingPageRight4 from "./LandingPageRight4";

const LandingPage4 = () => {
  return (
    <div className="landingpage4-main-container">
      <div className="landingPage4-div">
      <LandingPageLeft4 />
      </div>
      <div className="modulepage4-heading">
        <span>Our Modules</span>
      </div>
      <div className="landingPage4-div">
      <LandingPageRight4 />
      </div>
    </div>
  );
};

export default LandingPage4;
