import React from "react";
import "./landingpage5-style.scss";
import landingpage5image from "../../../assets/images/LandingPage5.png";

const LandingPageLeft5 = () => {
  return (
    <div>
      <div>
        <img src={landingpage5image} alt="landingpage5image" className="pg5-img"/>
      </div>
    </div>
  );
};

export default LandingPageLeft5;
