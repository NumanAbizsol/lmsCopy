import React from "react";
import landingpage from "../../../assets/images/LandingPage1.png";

const LeftIMainImage = () => {
  return (
    <div >
      <img className="img-size"  src={landingpage} alt="landingpage" />
    </div>
  );
};

export default LeftIMainImage;
