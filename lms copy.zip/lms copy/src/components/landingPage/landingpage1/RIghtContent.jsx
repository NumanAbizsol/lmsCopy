import React from "react";
import "./landing-style.scss";
const RIghtContent = () => {
  
  return (
    <div className="content-page1">
      <div className="content-text">
        <div className="content-light-text">Tommorow,</div>
        <div className="content-dark-text">Begins Today</div>
      </div>

      <div className="content-paragraph">
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nesciunt odit,
        iure soluta repellat
      </div>
      <div className="container-btn">Get Started</div>
    </div>
  );
};

export default RIghtContent;
