import type { Dayjs } from 'dayjs';
import React from 'react';
import { Calendar, theme } from 'antd';
import type { CalendarProps } from 'antd';
import { Icon } from '@iconify/react';
import arrowLeftIcon from '@iconify/icons-ic/arrow-back'; 
import arrowRightIcon from '@iconify/icons-ic/arrow-forward';
import { CalendarMode } from 'antd/es/calendar/generateCalendar';

const CustomCalender: React.FC = () => {
  const { token } = theme.useToken();

  const wrapperStyle: React.CSSProperties = {
    width: '90%',
    border: `1px solid ${token.colorBorderSecondary}`,
    borderRadius: token.borderRadiusLG,
    justifyContent: 'center',
  };

  const handlePanelChange = (value: Dayjs, mode: CalendarProps<Dayjs>['mode']) => {
  };

  const handleTypeChange = (type: CalendarMode) => {
  };

  return (
    <div style={wrapperStyle}>
      <Calendar
        fullscreen={false}
        onPanelChange={handlePanelChange}
        headerRender={({ value, type, onChange, onTypeChange }) => (
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px', borderBottom: `1px solid ${token.colorBorderSecondary}` }}>
            <div style={{ fontWeight: 'bold' }}>Exam Plan</div>
            <div style={{display:'flex',flexDirection:'row',justifyContent:'center',alignItems:'center',gap:'10px'}}>
            <Icon
              icon={'raphael:arrowleft2'}
              height='15px'
              onClick={() => {
                onChange(value.subtract(1, 'month')); 
              }}
              style={{ cursor: 'pointer', backgroundColor: '' }}
            />
            <div>{value.format('MMMM YYYY')}</div>
            <Icon
              icon={'raphael:arrowright2'}
              height='15px'
              onClick={() => {
                onChange(value.add(1, 'month')); 
              }}
              style={{ cursor: 'pointer' }}
            />
            </div>
          </div>
        )}
      />
    </div>
  );
};

export default CustomCalender;
