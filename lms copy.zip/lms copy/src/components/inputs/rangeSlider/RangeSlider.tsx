import React from 'react';
import { Slider } from 'antd';

export default function RangeSlider(): JSX.Element {
    return (
        <div>
            eeiei
            <Slider defaultValue={30} />
        </div>
    );
}
