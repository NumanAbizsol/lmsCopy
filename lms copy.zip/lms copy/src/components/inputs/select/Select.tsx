import React from "react";
import { Select, Space } from "antd";
import Checkbox from "../checkbox/Checkbox";
import { CustomSelectProps } from "./Select.d";
import './Select.scss'

export default function CustomSelect({
  customStyle,
  children,
  options,
  variant,
  handleChange,
  value,
  selected,
  customClass,
  icon
}: CustomSelectProps): JSX.Element {
  const { Option } = Select;

  return variant === "multi-select" ? (
    <Select
      style={{
        width: "100%",
        ...customStyle,
      }}
      className={`select_height ${customClass}`}
      mode="multiple"
      allowClear
    >
      <Option value="china" label="China">
        <Space>
          <span>
            <Checkbox />
          </span>
          China (中国)
        </Space>
      </Option>
    </Select>
  ) : (
    <Select
    className={`select_height ${customClass}`}
      style={{
        width: "100%",
        ...customStyle,
      }}
      onChange={handleChange}
      value={ selected??value}
      options={
        options || [
          {
            value: "jack",
            label: "Jack",
          },
        ]
      }
    >{children}</Select>
  );
}
// import React, { useState, useEffect, useRef } from 'react';
// import './Select.scss';

// const CustomSelect = ({ options, handleChange,value,icon,customStyle }:any) => {
//   const [isOpen, setIsOpen] = useState(false);
//   const dropdownRef = useRef<any>(null);
//   const [selectedOption, setSelectedOption] = useState('');

//   const handleToggle = () => {
//     setIsOpen(!isOpen);
//   };

//   const handleClickOutside = (event:any) => {
//     if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
//       setIsOpen(false);
//     }
//   };

//   useEffect(() => {
//     document.addEventListener('mousedown', handleClickOutside);
//     setSelectedOption(value)

//     return () => {
//       document.removeEventListener('mousedown', handleClickOutside);
//     };
//   }, []);

//   return (
//     <div className={`custom-dropdown ${isOpen ? 'open' : ''}`} ref={dropdownRef}>
//     <div className="selected-option" style={customStyle} onClick={handleToggle}>
//     {icon&&icon}  {selectedOption || 'Select an option'}
//     </div>
//     {isOpen && (
//       <div className="options">
//         {options.map((option:any) => (
//           <div
//             key={option.value}
//             className="option"
//             onClick={() => {setSelectedOption(option.label);handleChange(option.label)}}

//           >
//             {option.label}
//           </div>
//         ))}
//       </div>
//     )}
//   </div>

//   );
// };

// export default CustomSelect;
