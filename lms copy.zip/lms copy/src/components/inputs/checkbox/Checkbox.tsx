import React from "react";
// orginal line
// import { Checkbox, CheckboxChangeEvent } from 'antd';
import { Checkbox } from "antd";
import { CustomCheckboxProps } from "./Checkbox.d";
import './Checkbox.scss'
export default function CustomCheckbox({
  id,
  onChange,
  checked,
  style,
  label,
  disabled,
  labelStyle,
  
}: CustomCheckboxProps) {
  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (onChange) {
      onChange(e.target.checked);
    }
  };

  return (
    <>
      <Checkbox
      className={checked===true?`custom-checkbox`:"custom-checkbox-size"}
        style={style}
        checked={checked}
        disabled={disabled}
        id={id}
        onChange={(e: any) => handleCheckboxChange(e)}
      />
      <label style={labelStyle} >{label}</label>
    </>
  );
}
