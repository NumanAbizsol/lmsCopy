export type CustomCheckboxProps = {
    // onChange?: (checked: e) => void;
    onChange?: (e: ChangeEvent<HTMLInputElement>) => void;
    checked?: boolean;
    label?:string;
    style?:{};
    disabled?:boolean
    id?:string;
    labelStyle?:any;
  }