import React from "react";
import { Checkbox } from "antd";
import type { CheckboxChangeEvent } from "antd/es/checkbox";

interface CustomCheckboxProps {
  label?: string;
  id?: string;
  onChange?: (e: CheckboxChangeEvent) => void;
  disabled?: boolean;
  defaultChecked?: boolean; // Add this prop
}

export default function CustomCheckbox({
  label,
  onChange,
  id,
  disabled,
  defaultChecked,
}: CustomCheckboxProps) {
  return (
    <Checkbox
      onChange={onChange}
      id={id}
      disabled={disabled}
      defaultChecked={defaultChecked}
    >
      <span>{label}</span>
    </Checkbox>
  );
}
