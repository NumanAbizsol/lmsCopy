import React, { ChangeEvent, FocusEvent, CSSProperties } from "react";
import { Input } from "antd";
import { CustomInputProps } from "./Input.d";
import "./Input.scss";

export default function CustomInput({
  name,
  placeholder,
  customClass,
  height,
  width,
  customStyles,
  value,
  type,
  onChange,
  onBlur,
  disabled,
  onKeyDown,
}: CustomInputProps): JSX.Element {
  return (
    <Input
    name={name}
      onChange={onChange}
      onBlur={onBlur}
      value={value}
      type={type}
      disabled={disabled}
      placeholder={placeholder}
      style={{ ...customStyles, height, width }}
      className={`input-field ${customClass}`}
      onKeyDown={onKeyDown}
    />
  );
}
