export type CustomInputProps = {
    placeholder?: string;
    customClass?: string;
    height?: number;
    width?: number;
    value?:any;
    name?:string;
    type?:string;
    customStyles?: CSSProperties;
    onChange?: (e: ChangeEvent<HTMLInputElement>) => void;
    onBlur?: (e: FocusEvent<HTMLInputElement>) => void;
    disabled?:boolean;
    onKeyDown?: (e: React.KeyboardEvent<HTMLInputElement>) => void;
  }
  