// Radio.d.ts
export interface CustomRadioProps {
  name?: string;
  onChange?: any;
  value?:string;
  checked?:boolean;
  disabled?:boolean;

}
