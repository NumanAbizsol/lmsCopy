// CustomRadio.tsx
import React from 'react';
import { CustomRadioProps } from './Radio.d';

const CustomRadio: React.FC<CustomRadioProps> = ({ onChange, value ,checked,name,disabled}: CustomRadioProps): JSX.Element => {
  return (
    <input
      className='radio-button'
      value={value || ''} 
      onClick={onChange}
      type='radio'
      checked={checked}
      name={name}
      disabled={disabled}
    
    />
  );
};

export default CustomRadio;
