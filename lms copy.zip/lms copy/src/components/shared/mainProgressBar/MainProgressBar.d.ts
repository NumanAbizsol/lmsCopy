export type VerticalProgressBarProps ={
    currentStep: number;
    steps: Array<{ title: string; description?: string }>;
}