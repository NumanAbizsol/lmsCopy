import React from "react";
import { PieChart } from "react-minimal-pie-chart";

interface CustomPieChartProps {
  data: { title: string; value: number; color: string }[];
  totalValue: number;
  labelPosition?:number;
  lineWidth?:number;
}

const CustomPieChart: React.FC<CustomPieChartProps> = ({ data, totalValue ,labelPosition=70,lineWidth=50}) => {
  return (
    <PieChart
      data={data.map((item) => ({
        title: item.title,
        value: item.value,
        color: item.color,
        label: `${Math.round((item.value / totalValue) * 100)}%`,
      }))}
      label={({ dataEntry }) => dataEntry.label}
      lineWidth={lineWidth}
      labelStyle={{
        fontSize: "5px",
        fontFamily: "sans-serif",
        fill: "black",
      }}
      center={[50, 50]}
      lengthAngle={360}
      totalValue={totalValue}
      radius={45}
      labelPosition={labelPosition}
      startAngle={0}
      animate
    />
  );
};

export default CustomPieChart;
