export type FooterProps = {
    // Add any necessary props here
  }