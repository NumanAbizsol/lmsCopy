import { useEffect, useState } from "react";
import "./orgDropdown.css";
import setting from "../../../assets/images/settings.png";
import display from "../../../assets/images/Vector.png";
import { FaChevronRight } from "react-icons/fa";
import { MdOutlineDarkMode } from "react-icons/md";
import { IoArrowBack } from "react-icons/io5";
import language from "../../../assets/images/globe.png";
import log from "../../../assets/images/logout (1).png";
import profile from "../../../assets/images/OegProfile.png";
import { FaHouseUser } from "react-icons/fa6";
import { RiLockPasswordFill } from "react-icons/ri";
import { MdOutlineLanguage } from "react-icons/md";
import { MdOutlineLightMode } from "react-icons/md";
import { useNavigate } from "react-router-dom";
import { Avatar } from "antd";
import {
  useAppDispatch,
  useAppSelector,
} from "../../../hooks/useTypedSelector";
import { getUser } from "../../../redux/Slices/login-registerSlice";

const DropDownMenu = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isDisplayOpen, setIsDisplayOpen] = useState("");
  const [showSubopt, setShowSubOptions] = useState(false);
  const { user }: any = useAppSelector((state) => state.user);
  const dispatch = useAppDispatch();

  useEffect(() => {
    dispatch(getUser());
  }, [dispatch]);
  console.log("user", user);


  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
    setIsDisplayOpen("");
    setShowSubOptions(false);
  };

  const toggleDisplay = (value: any) => {
    setIsDisplayOpen(value);
    setShowSubOptions(value !== "");
  };
  const getAvatarFromName = (firstName: string, lastName: any) => {
    const initials = "bdjf"//(firstName[0] + lastName[0]).toUpperCase();
    return (
      <Avatar size={32} style={{ backgroundColor: "#87d068" }}>
        {initials}
      </Avatar>
    );
  };
  const navigate = useNavigate();

  const handleLogout = () => {
    navigate("/organization");
  };
  const data = [
    {
      name: "Display Mode",
      tabs: [
        { name: "Dark Mode", icon: <MdOutlineDarkMode /> },
        { name: "Light Mode", icon: <MdOutlineLightMode /> },
      ],
      icon: display,
    },
    {
      name: "Language",
      tabs: [
        { name: "English", icon: <MdOutlineLanguage /> },
        { name: "Arabic", icon: <MdOutlineLanguage /> },
        { name: "Italian", icon: <MdOutlineLanguage /> },
      ],
      icon: language,
    },
    {
      name: "Profile Settings",
      tabs: [
        { name: "Personal Info", icon: <FaHouseUser /> },
        { name: "Password", icon: <RiLockPasswordFill /> },
      ],
      icon: setting,
    },
    {
      name: "Logout",
      icon: log,
      onClick: handleLogout,
    },
  ];
  const firstName = localStorage.getItem("firstName") || "";
  const lastName = localStorage.getItem("lastName") || "";

  return (
    <nav>
      <div
        style={{
          width: "-webkit-fill-available",
          display: "flex",
        }}
        onClick={toggleMenu}
      >
        {getAvatarFromName(firstName, lastName)}
        

     {/* <strong>
                          {user[0]
                            ? `${user[0]?.firstName} ${user[0]?.lastName}`
                            : "invalid name"}
                        </strong> */}
        {/* shahzaib */}
      </div>

      <div
        className={`wrapper ${isMenuOpen ? "show" : ""}`}
        style={{ position: "absolute", right: "0" }}
      >
        <ul className={`menu-bar ${isMenuOpen ? "show-menu" : ""}`}>
          {data.map((tab, key) => (
            <li
              key={key}
              className={`setting-item ${
                showSubopt && tab.name === isDisplayOpen
                  ? "submenu submenu-open"
                  : ""
              }`}
              onClick={() => toggleDisplay(showSubopt ? "" : tab.name)}
            >
              {!showSubopt && (
                <a href="#" style={{ display: "block" }}>
                  <div className="list">
                    <div className="profile-img-icon">
                      <img
                        className="list-img"
                        src={tab?.icon}
                        alt={tab.name}
                      />
                    </div>
                    <div className="text-arrow-align">
                      <div className="display-text">{tab.name}</div>
                      {tab.name !== "Logout" && (
                        <div className="arrow-icon">
                          <FaChevronRight />
                        </div>
                      )}
                    </div>
                  </div>
                </a>
              )}
              {showSubopt && tab.name === isDisplayOpen && (
                <>
                  <li
                    className="arrow back-setting-btn"
                    onClick={() => toggleDisplay("")}
                  >
                    <div className="back-function">
                      <div className="arrow-back" style={{ padding: "5px" }}>
                        <IoArrowBack />
                      </div>
                      <div>{tab.name}</div>
                    </div>
                  </li>

                  {tab?.tabs &&
                    tab?.tabs.map((tb, subKey) => (
                      <li className="block-list submenu-item" key={subKey}>
                        <a href="#">
                          <div className="icon">
                            <span className="fas fa-user">{tb.icon}</span>
                          </div>
                          {tb.name}
                        </a>
                      </li>
                    ))}
                </>
              )}
            </li>
          ))}
        </ul>
      </div>
    </nav>
  );
};

export default DropDownMenu;

