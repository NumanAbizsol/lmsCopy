import { Dropdown, Space } from "antd";
import { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import MainHeader from "../Header/Header";
import "./OrgHeader.scss";
import { DownOutlined } from "@ant-design/icons";

import {
  useAppDispatch,
  useAppSelector,
} from "../../../hooks/useTypedSelector";
import OrgDropdown from "./OrgDropdown";
import { getUser, register } from "../../../redux/Slices/login-registerSlice";

const Header = () => {
  const [isDropdownOpen, setDropdownOpen] = useState(false);
  const { user }: any = useAppSelector((state) => state.user);
  const dispatch = useAppDispatch();

  useEffect(() => {
    dispatch(getUser());
  }, [dispatch]);
  
  const { organization } = useAppSelector((state: any) => state.organization);

  const toggleDropdown = () => {
    setDropdownOpen(!isDropdownOpen);
  };

  let hideHeaderForPaths = [
    "/register",
    "/login",
    "/otp",
    "/create-course",
    "/lms-setup",
    "/teacher/course-builder",
    "/create-quiz",
  ];

  const location = useLocation();
  const show = ["/"];

  const items = [
    {
      label: (
        <a href="">
          <img alt="1st menu item" />
        </a>
      ),
      key: "0",
    },
    {
      label: <a href="">LMS</a>,
      key: "1",
    },
    {
      label: <a href="">3nd Organization</a>,
      key: "3",
    },
  ];

  return (
    <>
      {hideHeaderForPaths.find((pre) => location.pathname.includes(pre)) ? (
        <></>
      ) : (
        <>
          {show.includes(location.pathname) ? (
            <MainHeader />
          ) : (
            <div
              className="main-continer"
              style={{
                width: "min-content",
                minWidth: "-webkit-fill-available",
              }}
            >
              <div className="navbar">
                <div className="ORGheader-left-section">
                  <div className="ORGheader-head-logo">
                    <div className="logo-img-section">
                      <img
                        className="logo-image"
                        src={organization[0]?.Thumbnail}
                        alt="Logo"
                      />
                    </div>
                    <div className="org-dropdown">
                      <Dropdown
                        menu={{
                          items,
                        }}
                        trigger={["click"]}
                      >
                        <a onClick={(e) => e.preventDefault()}>
                          <Space>
                            <DownOutlined />
                          </Space>
                        </a>
                      </Dropdown>
                    </div>
                  </div>
                </div>

                <div className="right-section">
                  <div>
                    <span className="line"></span>
                  </div>

                  <div className="profile-container" onClick={toggleDropdown}>
                    <div className="profile">
                      <div className="profile-info">
                        <OrgDropdown />
                        <strong>
                          {user[0]
                            ? `${user[0]?.firstName} ${user[0]?.lastName}`
                            : "invalid name"}
                        </strong>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </>
  );
};

export default Header;
