// orgHeader.d.ts
// export interface UserState {
//     loading: boolean;
//     error: string | null;
//     user: {
//       firstName: string;
//       lastName: string;
//       email: string;
//       Thumbnail?: string;
//       // Add other user properties as needed
//     };
//   }
  
  export interface UserState {
    loading: boolean;
    error: string | null;
    user: {
      firstName: string;
      lastName: string;
    };
  }
  