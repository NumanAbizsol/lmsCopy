import { Icon } from '@iconify/react';
import { useNavigate } from 'react-router-dom';

const Header = ({ header }: any) => {
  const navigate=useNavigate()
  return <>
    <div className="tabs-navbar">
      <div className="back-btn" onClick={()=> {navigate(header[0].route);console.log(header)}}>
        <span> <Icon icon="eva:arrow-ios-back-outline" height="24" /></span>
        {header[0].name}
      </div>
      <div className="course-name">
        <h3> {header[1].name}</h3>
      </div>
      <div className="preview-btn" onClick={()=>navigate(header[2].route)}>
        {header[2].name}
        <span> <Icon icon="eva:arrow-ios-forward-outline" height="24" /></span>
      </div>
    </div>
  </>
}
export default Header