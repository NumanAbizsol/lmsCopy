import React, { useEffect, useState } from "react";
import Sidebar from "./sidebar/Sidebar";
import Header from "./Header";
import Tab from "./Tabs";
const HeaderTabsAndNevbar = ({
  tabData,
  header,
  quiz,
  showTabsOnly = false,
  setQuiz,
  setCourse,
  course,
  setHeader,
  data,
  chData,
}: any) => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(true);
  const [selectedTab, setSelectedTab] = useState(0);
  useEffect(() => {
    console.log('Updated Header:', header);
  }, [header]);
  return (
    <>
      <div className="header-sideBar-tabs-container">
          {!showTabsOnly && (
            <Header
              header={header}
              setCourses={setCourse}
              setHeader={setHeader}
            />
          )}
        <div className="tabs-header">
          {!showTabsOnly && (
            <div className="sidebarr">
              <Sidebar
                isSidebarCollapsed={isSidebarCollapsed}
                setIsSidebarCollapsed={setIsSidebarCollapsed}
              />
            </div>
          )}
          <div className="tabs-and-content">
            <Tab
              tabData={tabData}
              setSelectedTab={setSelectedTab}
              selectedTab={selectedTab}
            />
            <div className="tab-content">
              {tabData[selectedTab].page &&
                React.createElement(
                  tabData[selectedTab].page as React.ComponentType<any>,
                  {
                    quiz: quiz,
                    setQuiz: setQuiz,
                    course: course,
                    setCourses: setCourse,
                    setSelectedTab: setSelectedTab,
                    data: data,
                    chData: chData,
                  }
                )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default HeaderTabsAndNevbar;
