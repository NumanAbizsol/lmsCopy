import "./CourseTabs.scss";
function Tab({ tabData ,selectedTab,setSelectedTab}: any) {
  
  return (
    <>
      <div className="tabs-main-container" id="tabs-width-fix">
        {tabData.map((tab:any,index: any) => (
          <div
            style={{
              width: `${100 / tabData.length}%`,
            }}
            className={`tab ${selectedTab === index ? "selectedTab" : ""}`}
            onClick={() => {
              setSelectedTab(index);
            }}
          >
            {tab?.name}
          </div>
        ))}
      </div>
    </>
  );
}

export default Tab;
