import React, { useState } from "react";
import Item from "../item/Item";
import './SidebarItems.scss';
import { ReactComponent as HomeIcon } from "../../../../../../assets/images/HomeStudent.svg";
import { sidebarOptions, sidebarOptionsOrganization, sidebarOptionsStudent } from "../../SidebarMeta";

const SidebarItems = ({ isSidebarCollapsed, isForOrganization, isForCoursePlayer }: any) => {
  const [selectedOption, setSelectedOption] = useState({
    option: 0,
    subOption: 0,
  });
  const setMenuOption = (option: number, subOption: number) => {
    setSelectedOption({ option, subOption });
  };

  const [sidebarOpt, setSidebarOptions] = useState(isForOrganization ? sidebarOptionsOrganization : isForCoursePlayer ? sidebarOptionsStudent : sidebarOptions)

  return (
    <div className="teacher-sidebar-items">
      {sidebarOpt.map((sidebarOption: any, index: number) => (
        <Item
          key={index}
          optionIndex={index}
          Icon={sidebarOption.icon}
          label={sidebarOption.label}
          options={sidebarOption.options}
          href={sidebarOption.href}
          selectedOption={selectedOption}
          isSidebarCollapsed={isSidebarCollapsed}
          setSelectedOption={setMenuOption}
        />
      ))}
    </div>
  );
};

export default SidebarItems;
