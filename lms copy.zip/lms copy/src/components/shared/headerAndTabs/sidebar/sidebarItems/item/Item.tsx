import React, { useEffect, useState } from "react";
import { ReactComponent as CheveronDown } from "../../../../../../assets/images/Chevron2.svg";
import SubItem from "../subItem/SubItem";
import { useNavigate } from "react-router-dom";
import { ItemProps } from "./Item.d";
import "./Item.scss";

const Item: React.FC<ItemProps> = ({
  Icon,
  label,
  options,
  selectedOption,
  setSelectedOption,
  optionIndex,
  href,
  isSidebarCollapsed,
}) => {
  useEffect(() => {
    console.log(href)
  }, [href])
  const [isMounted, setIsMounted] = useState(false);
  const [showDiv, setShowDiv] = useState(false);

  const mountedStyle = {
    animation: "inAnimation 250ms ease-in",
  };
  const unmountedStyle = {
    animation: "outAnimation 270ms ease-out",
    animationFillMode: "forwards",
  };

  const navigate = useNavigate();
  const toggleSubMenu = () => {
    if (isSidebarCollapsed) {
      setIsMounted(!isMounted);
      if (!showDiv) setShowDiv(true);
    }
  };
  return (
    <div className="teacher-sidebar-box">

      <div className="teacher-sidebar-item" onClick={() => {
        setSelectedOption(optionIndex + 1, -1);
        toggleSubMenu();
        href && navigate(href);
      }}
        style={{
          backgroundColor: selectedOption.option - 1 === optionIndex && selectedOption.subOption < 0 && isSidebarCollapsed ? "#10baac" : "",
          color: selectedOption.option - 1 === optionIndex && selectedOption.subOption < 0 ? 'white' : 'black',
          position: 'relative',
        }}
      >
        {!isSidebarCollapsed && selectedOption.option - 1 === optionIndex && selectedOption.subOption < 0 && (
          <div className="sidecolor" style={{ padding: "20px 5px", position: 'absolute', left: '-35px', top: '10', borderRadius: '0px 4px 4px 0px' }}> &nbsp;&nbsp; &nbsp;</div>
        )}


        <div className="item-content" >
          <div className="item-content item-text">
            {Icon && <Icon className="item-icon" />}
            {isSidebarCollapsed && <p className="item-text" style={{
              color: selectedOption.option - 1 === optionIndex && selectedOption.subOption < 0 ? 'white' : 'black',
              fontWeight: selectedOption.option - 1 === optionIndex && selectedOption.subOption < 0 ? 'bold' : ''
            }}  >{label}</p>}
          </div>
        </div>
        {isSidebarCollapsed
          ? options && (
            <CheveronDown
              className={`cheveron ${showDiv ? "cheveron-up" : ""}`}
            />
          )
          : null}
      </div>


      {
        showDiv && options && (
          <div
            className="suboption-wrapper"
            style={isMounted ? mountedStyle : unmountedStyle}
            onAnimationEnd={() => {
              if (!isMounted) setShowDiv(false);
            }}
          >
            {options &&
              options.map((option, index) => {
                return (
                  <SubItem
                    key={index}
                    optionIndex={optionIndex}
                    subOptionIndex={index}
                    Icon={option.icon}
                    label={option.label}
                    href={option.href}
                    setSelectedOption={setSelectedOption}
                    selectedOption={selectedOption}
                  />
                );
              })}
          </div>
        )
      }
    </div >
  );
};

export default Item;
