import React from "react";
import SidebarItems from "./sidebarItems/sidebarItems/SidebarItems";
import "./Sidebar.scss";
import UpgradePlan from "../../../../features/teacherDashboard/upgradePlan/UpgradePlan";
import { Icon } from "@iconify/react";

const Sidebar = ({
  isSidebarCollapsed,
  setIsSidebarCollapsed,
  isForOrganization,
  isForCoursePlayer,
}: any) => {
  

  const handleToggleSidebar = () => {
    setIsSidebarCollapsed((state: any) => !state);
  };

  return (
    <div className="teacher-sidebar-container">
      <div className="teacher-sidebar-wrapper" style={{position:"relative"}}>
        <div
          className="header-left"
          style={
            isSidebarCollapsed
              ? {
                width: "95%",
                display: "flex",
                alignItems: "center",
                justifyContent: "flex-end",
                padding: "2px 12px 2px 32px",
              }
              : {
                width: "95%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                padding: "0px",
              }
          }
        >
          {isSidebarCollapsed && (
            <div className="toggle-btn" onClick={handleToggleSidebar}>
              <Icon icon="ri:arrow-left-double-fill" height="24" />
            </div>
          )}
        </div>
        {!isSidebarCollapsed && (
          <div className="toggle-btn d-flex align-center" onClick={handleToggleSidebar} style={{right:'-25px'}}>
            <Icon icon="ri:arrow-right-double-fill" height="24" />
          </div>
        )}
        <SidebarItems
          isForOrganization={isForOrganization}
          isSidebarCollapsed={isSidebarCollapsed}
          isForCoursePlayer={isForCoursePlayer}
                  />
        {/* {isSidebarCollapsed && !isForOrganization && <UpgradePlan />} */}
      </div>
    </div>
  );
};

export default Sidebar;
