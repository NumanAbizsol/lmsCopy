import { Switch } from "antd";
export default function SwitchButton({ onChange, value }: any): JSX.Element {
  return (
    <Switch
      className="switch-color"
      style={value ? { backgroundColor: "#10BAAC" } : {}}
      checked={value}
      onChange={() => {
        onChange(!value);
      }}
    />
  );
}
