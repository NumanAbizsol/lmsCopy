
export type CustomAlertProps = {
    type: 'success' | 'info' | 'warning' | 'error';
  }