import React from "react";
import { CardProps } from "./Card.d";
import "./Card.scss";
import { ReactComponent as Star } from "../../../assets/images/yellowStar.svg";
import {
  EllipsisOutlined,
  DeleteOutlined,
  CopyOutlined,
} from "@ant-design/icons";
import { Dropdown, Menu } from "antd";
import { Icon } from "@iconify/react";

const Card: React.FC<CardProps> = ({
  title,
  imageSrc,
  enrolledCount,
  section = null,
  style,
  customClassName,
  simpleCourses,
  review,
  mode,
  questionCount = null,
  onImageClick,
}) => {
  const options = [
    { key: "duplicate", label: "Duplicate", icon: <CopyOutlined /> },
    { key: "delete", label: "Delete", icon: <DeleteOutlined /> },
  ];
  const handleMenuClick = (option: string) => {
    console.log("option clicked");
  };
  const menu = (
    <Menu
      className="custom-card-menu"
      style={{ padding: "20px" }}
      onClick={({ key }) => handleMenuClick(key)}
    >
      {options.map((option) => (
        <Menu.Item key={option.key} icon={option.icon}>
          {option.label}
        </Menu.Item>
      ))}
    </Menu>
  );
  return (
    <div
      className="p-20"
      style={{
        boxShadow: "0 0 10px rgba(0, 0, 0, 0.1)",
        backgroundColor: "#ffff",
        borderRadius: "2px",
        padding:'20px'
      }}
    >
      <div
        className="  divide-screen gap-5"

        // className={`card ${customClassName}`}
        // style={{
        //   ...style,
        //   ...(simpleCourses
        //     ? { flexDirection: "row", flexWrap: "nowrap" }
        //     : { flexDirection: "row", flexWrap: "nowrap" }),
        // }}
      >
        <div className="divide-screen gap-10">
          <div className="divide-screen-column gap-5">
            <img
              src={imageSrc}
              alt="Card Image"
              className=""
              onClick={onImageClick}
              style={{
                width: "150px",
                height: "90px",
                borderRadius: "8px",
                cursor: "pointer",
              }}
            />
          </div>
          <div className=" divide-screen-column gap-10">
            <h5 className="enrolled-count">Enrolled {enrolledCount} </h5>
            {section ? (
              <span className="card-stats">{section} Section</span>
            ) : null}
            {questionCount ? (
              <span className="card-stats"> {questionCount} Question</span>
            ) : null}{" "}
            <h5 className="mode text-center">{mode}</h5>
          </div>
        </div>
        <div className="">
          <Dropdown overlay={menu} trigger={["click"]}>
            <span
              style={{ cursor: "pointer" }}
              onClick={(e) => e.preventDefault()}
            >
              <Icon
                icon="ion:ellipsis-vertical"
                height="24px"
                style={{
                  backgroundColor: "#F3FCFB",
                  borderRadius: "5px",
                  color: "lightgray",
                }}
              />
            </span>
          </Dropdown>
        </div>

        {/* <div className="divide-screen align-center m_t_10 justify-space-between"> 
       <div className="">
          <span>
            <Star />
            <Star />
            <Star />
            <Star />
            <Star />
          </span>
          <span>({review})</span>
        </div>
        <div>Pricing $5</div>
        </div> */}
        {/* <img
        src={imageSrc}
        alt="Card Image"
        className="card-image"
        onClick={onImageClick}
        style={{ width: "150px", height: "90px", borderRadius: "8px" ,cursor:'pointer'}}
      />
      <div className="cards-content">
        <div className="d-flex justify-space-between align-center">
          <span className="notification-heading">{title}</span>
          <span className="enrolled-count">{enrolledCount} enrolled</span>
          <Dropdown overlay={menu} trigger={["click"]}>
            <span
              style={{ cursor: "pointer" }}
              onClick={(e) => e.preventDefault()}
            >
              <Icon
                icon="ion:ellipsis-vertical"
                height="24px"
                style={{ backgroundColor: "#F3FCFB", borderRadius: "5px" }}
              />
            </span>
          </Dropdown>
        </div>
        <div className="d-flex justify-space-between align-center">
          {section ? (
            <span className="card-stats">{section} Section</span>
          ) : null}
          {questionCount ? (
            <span className="card-stats"> {questionCount} Question</span>
          ) : null}
          <span>{mode}</span>
        </div>
        <div className="card-reviews">
          <span>
            <Star />
            <Star />
            <Star />
            <Star />
            <Star />
          </span>
          <span>({review})</span>
        </div>
      </div> */}
      </div>
      <div className="d-flex justify-center text-center m_t_10">
        {" "}
        <h5 className="notification-heading" style={{ flexGrow: 1 }}>
          {title}
        </h5>
      </div>
      <div className="divide-screen align-center m_t_10 justify-space-between">
        <div className=" divide-screen align-center">
          <span>
            <Star />
            <Star />
            <Star />
            <Star />
            <Star />
          </span>
          <span>({review})</span>
        </div>
        <div>Pricing$5</div>
      </div>
    </div>
  );
};

export default Card;
