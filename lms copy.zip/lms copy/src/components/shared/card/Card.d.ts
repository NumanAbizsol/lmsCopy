export type CardProps = {
  title: string;
  imageSrc?: string;
  enrolledCount?: number;
  section?: number;
  style?: React.CSSProperties;
  customClassName?: string;
  simpleCourses?:boolean;
  review?:number;
  mode?:string;
  questionCount?:number;
  onImageClick?: () => void
};
