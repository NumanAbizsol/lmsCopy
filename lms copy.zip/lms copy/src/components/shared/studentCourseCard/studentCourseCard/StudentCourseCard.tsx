// StudentCourseCard.tsx
import React, { useState } from 'react';
import './StudentCourseCard.scss';
import ProgressBar from '../../progressBar/ProgressBar';
import thumbnail1 from '../../../../assets/images/schoolSetup.png';
import instructorImg from '../../../../assets/images/dp.png'
import { Icon } from '@iconify/react';

const StudentCourseCard: React.FC<any> = ({
    thumbnail,
    title,
    description,
    instructor,
    price,
    isFavourite: propIsFavourite,
    isHidden: propIsHidden,
    progress,
    isDashboard,
}) => {
    const [isFavourite, setIsFavourite] = useState<boolean>(propIsFavourite);
    const [isHidden, setIsHidden] = useState<boolean>(propIsHidden);

    const toggleFavourite = () => {
        setIsFavourite(!isFavourite);
    };

    const toggleHidden = () => {
        setIsHidden(!isHidden);
    };
    const cardStyle = isDashboard ? { width: '90%' } : {};
    return (
        <div className={`student-course-card ${isHidden ? 'hidden' : ''} `} style={cardStyle}>
            <div className="dropdown-icon">
            <Icon icon="pepicons-pop:dots-y" height="24" />
            </div>
            <div className="course-thumnail-container">
                <img className="thumbnail" src={thumbnail1} alt={title} />
            </div>
            <div className="info">
                <h2 className="title-and-description">
                    {title}: <span>{description}</span>
                </h2>
                <div className="instructor">
                    <img className="instructor-image" src={instructorImg} alt={instructor?.name} />
                    <p className="instructor-name">{instructor?.name}</p>
                </div>
                <div className="price">{`$${price}`}</div>
                <div className="icons">
                    <div
                        className='favourite-icon'
                    >
                        <Icon icon="material-symbols-light:star" height="24" className={`fav-icon ${isFavourite ? 'favourite' : 'not-favourite'}`}
                            onClick={toggleFavourite} />
                        <span>Favourite</span>
                    </div>
                    <div className={`hide-icon ${isHidden ? 'hidden' : ''}`} onClick={toggleHidden}>
                        <Icon icon="mdi:hide-outline" height="24" />
                        Hide
                    </div>
                </div>
                <div className="progress">{`PROGRESS: ${progress}%`}</div>
                <ProgressBar progress={progress} />
            </div>
        </div>
    );
};

export default StudentCourseCard;
