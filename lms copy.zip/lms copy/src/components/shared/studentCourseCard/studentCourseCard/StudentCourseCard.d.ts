export type StudentCourseCardProps = {
    thumbnail?: string;
    title: string;
    description: string;
    instructor: {
      name: string;
      image?: string;
    };
    price: number;
    isFavourite: boolean;
    isHidden: boolean;
    progress: number;
  }