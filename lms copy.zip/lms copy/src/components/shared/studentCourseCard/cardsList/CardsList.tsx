// CardsList.tsx
import React, { useState } from 'react';
import { StudentCourseCardProps } from '../../../../components/shared/studentCourseCard/studentCourseCard/StudentCourseCard.d';
import StudentCourseCard from '../studentCourseCard/StudentCourseCard';
import './CardsList.scss';

interface CardsListProps {
  courses: StudentCourseCardProps[];
}

const CardsList: React.FC<CardsListProps> = ({ courses }) => {
  const [showAllCourses, setShowAllCourses] = useState(false);

  const visibleCourses = showAllCourses ? courses : courses.slice(0, 4);

  const handleViewAllClick = () => {
    setShowAllCourses(true);
  };

  return (
    <div className="cards-wraper">
      <div className="enroled-info">
        <h1>Courses you're taking</h1>
        <p>
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry.
        </p>
      </div>
      <div className="courses-list">
        {visibleCourses.map((course, index) => (
          <StudentCourseCard key={index} {...course} />
        ))}
      </div>
      {!showAllCourses && (
        <div className="view-all-courses" onClick={handleViewAllClick}>
          View All Courses
        </div>
      )}
    </div>
  );
};

export default CardsList;
