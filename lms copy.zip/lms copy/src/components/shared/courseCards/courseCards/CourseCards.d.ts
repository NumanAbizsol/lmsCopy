export type CourseCardsProps ={
    style?: React.CSSProperties;
    simpleCourses?:boolean;
    title?: string;
    course?:any;
    index?:number;
  }