import React from "react";
import Card from "../../card/Card";
import ImgSrc from "../../../../assets/images/Rectangle 1.png";
import "./CourseCards.scss";
import { CourseCardsProps } from "./CourseCards.d";
import { useNavigate } from "react-router-dom";
import usePermission from "../../../../PermissionHook";

const CourseCards: React.FC<CourseCardsProps> = ({ style, simpleCourses, course, index }: any) => {
  const navigate = useNavigate()
  const { hasRole, hasPermissionForAction } = usePermission();
  const handleImageClick = () => {
    if ((hasRole("admin") || hasRole("teacher")) && hasPermissionForAction("EDIT_COURSE")) {
      navigate(`${course.id}`);
    }
  };
  return (
    <div className="course-card-container">
      <div className="cards" >
        <Card
          key={index}
          title={course?.title}
          imageSrc={course?.thumbnail}
          enrolledCount={10}
          section={2}
          style={style}
          customClassName="cards"
          simpleCourses={simpleCourses}
          review={3}
          mode="Publish"
          onImageClick={handleImageClick}

        />
      </div>
      {(hasRole("admin") || hasRole("teacher")) && hasPermissionForAction("EDIT_COURSE")?null:"NO Permissions to edit!"}

    </div>
  );
};

export default CourseCards;
