import Password from "antd/es/input/Password";

export const validatePassword = (password: string): string | null => {
  if (!password) {
    return "Password is required";
  }

  if (password.length < 8) {
    return "Password must be at least 8 characters";
  }

  if (!/[A-Z]/.test(password)) {
    return "Password must contain at least one uppercase letter";
  }

  if (!/\d/.test(password)) {
    return "Password must contain at least one digit";
  }

  return null;
};

export const validateEmail = (email: string): string | null => {
  const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;

  if (!email) {
    return "Email is required";
  }

  if (!emailRegex.test(email)) {
    return "Invalid email address";
  }

  return null;
};
export const validateTitle = (title: string): string | null => {
  if (!/^[a-zA-Z0-9\s]+$/.test(title)) {
    return "Title is required";
  }
  return null;
};
export const validateTagline = (tagLine: string): string | null => {
  if (!/^[a-zA-Z0-9\s]+$/.test(tagLine)) {
    return "Tagline is required";
  }
  return null;
};
export const validateURL = (url: string): string | null => {
  if (!url) {
    return "URL is required";
  }
  if (!/^(ftp|http|https):\/\/[^ "]+$/.test(url)) {
    return "Invalid URL format";
  }
  return null;
};
export const validateDescription = (description: string): string | null => {
  if (!description.trim()) {
    return "Description is required";
  }
  return null;
};
export const validateThumbnail = (thumbnail: string): string | null => {
  if (!thumbnail.trim()) {
    return "Thumbnail is required";
  }
  return null;
};
export const validateFirstName = (firsName: string): string | null => {
  if (!/^[a-zA-Z0-9\s]+$/.test(firsName)) {
    return "First Name is Required";
  }
  return null;
};
export const validateLastName=(lastName:string):string | null =>{
  if(!/^[a-zA-Z0-9\s]+$/.test(lastName)){
    return "Last Name is Required"
  }
  return null
}
export const validateConfirmPassword=(password:string,confirmPassword:string): string | null=>{
  
  if (!confirmPassword) {
    return "Confirm Password is required";
  }
  if (confirmPassword !== password) {
    return "Passwords do not match";
  }


  return null;
}
export const validateOrganizationName=(OrganizationName:string):string | null =>{
  if(!OrganizationName){
    return "Organization name is required"
  }
  if (OrganizationName.toLowerCase().includes(".com")){
    return 'Organization name cannot contain ".com" '
  }

  return null
}
export const validateCompanyURL=(companyUrl:string):string | null=>{
  if(!companyUrl){
    return null
  }
  if (!/^(ftp|http|https):\/\/[^ "]+$/.test(companyUrl)) {
    return "Invalid URL format";
  }
  return null;
}