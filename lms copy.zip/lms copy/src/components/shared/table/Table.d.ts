export type CustomTableProps ={
    columns: any[]; // You should replace 'any[]' with the actual type of your column data.
    data: any[]; // You should replace 'any[]' with the actual type of your data.
  }