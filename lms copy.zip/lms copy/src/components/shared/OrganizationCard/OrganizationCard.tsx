import React from "react";

interface OrganizationCardProps {
  imageUrl: string;
  title: string;
  description: string;
}

const OrganizationCard: React.FC<OrganizationCardProps> = ({
  imageUrl,
  title,
  description,
}) => {
  return (
    <div className="card">
      <img src={imageUrl} alt={`Card Image`} />
      <div className="card-content">
        <h1>{title}</h1>
        <p>{description}</p>
      </div>
    </div>
  );
};

export default OrganizationCard;
