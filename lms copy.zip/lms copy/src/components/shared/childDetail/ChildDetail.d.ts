export type ChildDetailProps = {
    title: string;
    description?: string;
    showTabsContent?: boolean;
}