export type ProgressBarProps = {
    progress: number;
  }