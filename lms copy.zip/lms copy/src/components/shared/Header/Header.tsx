import React, { useEffect, useState } from "react";
import Logo from "../../../assets/images/urqaalogo.png";
import { Menu, Dropdown, Button, Select } from "antd";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";
import { DownOutlined, UserOutlined } from "@ant-design/icons";
import "./Header.scss";
import { useTranslation } from "react-i18next";
import CustomButton from "../button/Button";
import CustomSelect from "../../inputs/select/Select";
import { Icon } from "@iconify/react";
const Header: React.FC = () => {
  const [showCourseList, setShowCourseList] = useState(false);
  const navigate = useNavigate();
  const { id } = useParams();
  const toggleCourseList = () => {
    setShowCourseList(!showCourseList);
  };

  let hideHeaderForPaths = [
    "/register",
    "/login",
    "/otp",
    "/course-builder",
    "/create-course",
    "/my-courses",
    "/organization",
    "/lms-setup",
    "/teacher/course-builder",
    "/create-quiz",
    "/teacher",

  ];
  const location = useLocation();

  useEffect(()=>{

hideHeaderForPaths[11]=`/my-courses/${id}`
console.log(hideHeaderForPaths,location)
  },[id,location])
  const { t, i18n } = useTranslation();
  const changeLanguage = (language: any) => {
    console.log(language);
    i18n.changeLanguage(language);
  };
  const coursesMenu = (
    <Menu>
      <Menu.Item key="1">
        {" "}
        <Link to="/lms" className="menu-link">
          LMS{" "}
        </Link>
      </Menu.Item>
      <Menu.Item key="2">
        <Link to="/hrm" className="menu-link">
          HRM
        </Link>
      </Menu.Item>
      <Menu.Item key="3">
        {" "}
        <Link to="/cms" className="menu-link">
          CMS
        </Link>
      </Menu.Item>
    </Menu>
  );
  return (
    <>
      {hideHeaderForPaths.find((pre)=>location.pathname.includes(pre)) ? (
        <></>
      ) : (
        <div className="organization-header">
          <div className="logo-and-name">
            <img src={Logo} alt="Logo" />
          </div>
          <div className="menu-items">
            <ul>
              <li onClick={toggleCourseList} className="menu-link">
                <Dropdown overlay={coursesMenu}>
                  <Link to="/products" className="menu-link">
                    Products
                  </Link>
                </Dropdown>
                <DownOutlined style={{ fontSize: "12px", color: "black" }} />
              </li>
              <li style={{ width: "max-content" }}>
                <Link to="/community" className="menu-link">
                  Community
                </Link>
              </li>
              <li>
                <Link to="/blogs" className="menu-link">
                  Blogs
                </Link>
              </li>
              <li style={{ width: "max-content" }}>
                <Link to="/create-course" className="menu-link">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>
          <div className="user-and-language-selector">
            <div className="nightMode">
              <Icon color="" icon="ion:moon-sharp" height="24" />{" "}
            </div>
            <CustomSelect
            variant="single-select"
              options={[
                { value: "English", label: "ENG" },
                { value: "Turkish", label: "TUR" },
                { value: "German", label: "GER" },
              ]}
              handleChange={(e: any) => {
                changeLanguage(e);
              }}
              value={i18n.language}
              icon={<Icon color="" icon="tabler:world" height="24" />}
              customStyle={{ height: "40px" }}
            />
            <CustomButton
              variant="secondary"
              customStyle={{ height: "40px" }}
              onClick={() => {navigate('/login')}}
            >
              Login
            </CustomButton>
            <CustomButton
              variant="primary"
              customStyle={{ height: "40px" }}
              onClick={() => {navigate('/register')}}
            >
              Get Started
            </CustomButton>
          </div>
        </div>
      )}
    </>
  );
};
export default Header;