import React, { useEffect, useState } from 'react';
import './AssignmentCard.scss';
import { Icon } from '@iconify/react';

interface AssignmentCardProps {
  deadline: string;
  courseTitle: string;
  assignDate: string;
  timeSpent: string;
  backgroundColor: string;
}

const AssignmentCard: React.FC<any> = ({
  deadline,
  courseTitle,
  assignDate,
  timeSpent,
  backgroundColor,
}) => {
  const [timeLeft, setTimeLeft] = useState<any>({
    days: 0,
    hours: 0,
    minutes: 0,
  });

  useEffect(() => {
    const now = new Date();
    const deadlineDate = new Date(deadline);
    const timeDifference = deadlineDate.getTime() - now.getTime();

    const days = Math.floor(timeDifference / (1000 * 60 * 60 * 24));
    const hours = Math.floor((timeDifference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((timeDifference % (1000 * 60 * 60)) / (1000 * 60));

    setTimeLeft({
      days,
      hours,
      minutes,
    });

    console.log('timeleft', days, hours, minutes);
  }, [deadline]);

  return (
    <div className="assignment-card">
      <div className="left-div"style={{ background: backgroundColor }}>
        <h1>{deadline}</h1>
      </div>

      <div className="right-div">
        <div className="course-title">
          <h1>{courseTitle}</h1>
        </div>
        <div className="details">
          <span className='timeleft-days'>{timeLeft.days} :</span>
          <span className='timeleft-days-label'>{timeLeft.days === 1 ? 'day' : 'days'}</span>

          <span className='timeleft-hours'>{timeLeft.hours} :</span>
          <span className='timeleft-hours-label'>{timeLeft.hours === 1 ? 'hour' : 'hours'}</span>

          <span className='timeleft-minutes'>{timeLeft.minutes} :</span>
          <span className='timeleft-minutes-label'>{timeLeft.minutes === 1 ? 'minute' : 'minutes'}</span>
        </div>
        <hr />
        <div className="details">
          <span>
            <Icon icon="mingcute:time-line" height="24" color='#818181' />
            Assigned Date:
          </span>
          <span>{assignDate}</span>
        </div>
        <hr />
        <div className="details">
          <span>
            <Icon icon="mingcute:time-line" height="24" color='#818181' />
            Time Spent:
          </span>
          <span>{timeSpent}</span>
        </div>
      </div>
    </div>
  );
};

export default AssignmentCard;
