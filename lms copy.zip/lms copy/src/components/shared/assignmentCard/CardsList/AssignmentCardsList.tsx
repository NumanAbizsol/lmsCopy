import React from 'react';
import AssignmentCard from '../AssignmentCard';
import'./AssignmentCardsList.scss'

const AssignmentCardsList: React.FC = () => {
  const colors = ['#ffb6c1','#ff8c00', '#4caf50','#ffcccb', '#b0e57c', '#add8e6', '#2196f3', '#e91e63', '#673ab7', '#ff5722', '#795548', '#607d8b']; 

  const assignmentDataList = [
    {
      deadline: '12 DEC',
      courseTitle: 'Computer Science 101',
      timeLeft: '2 days 5 hours',
      assignDate: '2023-01-10',
      timeSpent: '1 hour 30 minutes',
      backgroundColor: colors[0],
    },
    {
        deadline: '02 DEC',
        courseTitle: 'Computer Science 101',
        timeLeft: '2 days 5 hours',
        assignDate: '2023-01-15',
        timeSpent: '1 hour 30 minutes',
        backgroundColor: colors[1],

      },
      {
        deadline: '10 DEC',
        courseTitle: 'Computer Science 101',
        timeLeft: '2 days 5 hours',
        assignDate: '2023-01-18',
        timeSpent: '1 hour 30 minutes',
        backgroundColor: colors[2],
      },
    // Add more assignment data objects as needed
  ];

  return (
    <div className='assignment-cards-wraper'>
      {assignmentDataList.map((assignmentData, index) => (
        <AssignmentCard key={index} {...assignmentData} />
      ))}
    </div>
  );
};

export default AssignmentCardsList;
