import { Modal } from "antd";
import React from "react";

const CustomModal = ({ title, open, onCancel, width = '900px', footer = null, modalContent }: any) => {
  return (
    <Modal
      title={title}
      open={open}  // Correcting the prop name from `open` to `visible`
      onCancel={onCancel}
      footer={footer}
      width={width}
    >
      {React.createElement(
        modalContent.type,  // Access the type of the component for createElement
        {
          ...modalContent.props,
          onCancel: onCancel,  // Pass onCancel to the modalContent component
        }
      )}
    </Modal>
  );
};

export default CustomModal;
