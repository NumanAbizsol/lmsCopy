import React, { ReactNode, CSSProperties, MouseEventHandler } from "react";
import { CustomButtonProps } from "./Button.d";
import { ReactComponent as Plus } from "../../../assets/images/plus2.svg";
import { Icon } from '@iconify/react';

import "./Button.scss";

export default function CustomButton({
  children,
  variant,
  className,
  customStyle,
  type='button',
  onClick,
  childClasses,
  disabled=false,
  showPlusButton=false,
  buttonIcon='',
  rotateArrowIcon = false
}: CustomButtonProps): JSX.Element {
  const buttonClass =
    variant === "primary"
      ? "primary-button"
      : variant === "secondary"
      ? "secondary-button"
      : "default-button";
      const arrowicons=rotateArrowIcon?"rotate-icon":'';
  return (
    <button
      type={type}
      onClick={onClick}
      style={customStyle}
      className={`${buttonClass} ${className} main-btn`}
      disabled={disabled}
    >
      {showPlusButton?<Icon icon="ic:baseline-plus" height="24" />:null}
      {buttonIcon?<Icon icon={buttonIcon} height="14" className={arrowicons}/>:null}

      <span className={`btn-text ${childClasses}`}>{children}</span>
    </button>
  );
}
