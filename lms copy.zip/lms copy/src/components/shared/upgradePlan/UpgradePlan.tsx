import { Icon } from "@iconify/react";
import React from "react";
import "./UpgradePlan.scss";
import CustomButton from "../button/Button";

export default function UpgradePlan({ planText = "premium plan" }) {
  return (
    <div>
      <div className="upgrade-plan">
        <div className="plan-info">
          <Icon icon="clarity:arrow-line" height="24px" />
          <p>
            Upgrade to the <span style={{ color: "#10baac" }}>start plan </span>
            {planText}
          </p>
        </div>
        <div className="upgrade-buttons">
          <CustomButton
            className="upgrade-button"
            variant="primary"
            customStyle={{ gap: "3px" }}
          >
            UPGRADE NOW
          </CustomButton>
          <CustomButton
          variant="default"
          buttonIcon={"teenyicons:arrow-solid"}
          rotateArrowIcon={true}
          className="learnmore-button"
          >
            LEARN MORE
          </CustomButton>
        </div>
      </div>
    </div>
  );
}
