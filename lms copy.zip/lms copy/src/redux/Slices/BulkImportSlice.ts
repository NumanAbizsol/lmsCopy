import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import {
  readFromLocalStorage,
  writeToLocalStorage,
} from "./localStorageReadWrite/readWrite";

export const setbulkImport = createAsyncThunk(
  "setbulkimport",
  async (payload: any) => {
    writeToLocalStorage("selectedFiles", JSON.stringify(payload));
    const response =JSON.parse(readFromLocalStorage("selectedFiles"));
    return response;
  }
);
export const setEditorContent = createAsyncThunk(
    "setEditorContent",
    async (payload: any) => {
      writeToLocalStorage("description", JSON.stringify(payload));
      const response =JSON.parse(readFromLocalStorage("description"));
      return response;
    }
  );
export const getbulkImport = createAsyncThunk(
  "getbulkImport",
  async () => {
    const responce = await JSON.parse(readFromLocalStorage("selectedFiles"));
    return responce;
  }
);

const bulkImport = createSlice({
  name: "bulkfile",
  initialState: {
    fileList: [],
    editorContent:""
  },
  reducers: {
    setFileList: (state, action) => {
      state.fileList = action.payload;
    },
    // setEditorContent: (state :any, action) => {
    //     state.editorContent = action.payload;
    //   },
  },
  extraReducers(builder) {
    builder
      .addCase(setbulkImport.fulfilled, (state, action: PayloadAction<any>) => {
        console.log('Reducer - SetBulkImport:', action.payload);
        state.fileList = action.payload;
        // state.editorContent=action.payload
      })
      .addCase(getbulkImport.fulfilled, (state, action: PayloadAction<any>) => {
        state.fileList = action.payload;
      })
      .addCase(setEditorContent.fulfilled, (state, action: PayloadAction<string>) => {
        state.editorContent = action.payload;
      })
  },
});
export const { setFileList } = bulkImport.actions;
export default bulkImport.reducer;
