// quizzesSlice.ts
import { createSlice, PayloadAction, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import {
  readFromLocalStorage,
  writeToLocalStorage,
} from "./localStorageReadWrite/readWrite";
interface QuizzesCreationState {
  loading: boolean;
  error: string | null;
  quiz: any;
  quizSettings: any;
  quizQuestions: any;
}

const initialState: QuizzesCreationState = {
  loading: false,
  error: null,
  quiz: {},
  quizSettings: {},
  quizQuestions: [],
};
export const createQuiz = createAsyncThunk(
  "createQuiz",
  async (payload: any, thunkApi) => {
    try {
      writeToLocalStorage("Quizzes", [{ ...payload }]);
      const response = readFromLocalStorage("Quizzes");
      return response;
    } catch (error: any) {
      const message = error.message;
      return thunkApi.rejectWithValue(message);
    }
  }
);
export const getQuizzes = createAsyncThunk(
  "getQuizzes",
  async (_, thunkApi) => {
    try {
      const response = await readFromLocalStorage("Quizzes");
      console.log("response", response);

      return response;
    } catch (error: any) {
      const message = error.message;
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const createQuizSettings = createAsyncThunk(
  "createQuizSettings",
  async (payload: any, thunkApi) => {
    try {
      writeToLocalStorage("QuizSettings", [{ ...payload }]);
      const response = readFromLocalStorage("QuizSettings");
      return response;
    } catch (error: any) {
      const message = error.message;
      return thunkApi.rejectWithValue(message);
    }
  }
);
export const getQuizsettings = createAsyncThunk(
  "getQuizSettings",
  async (_, thunkApi) => {
    try {
      const response = await readFromLocalStorage("QuizSettings");
      console.log("response", response);

      return response;
    } catch (error: any) {
      const message = error.message;
      return thunkApi.rejectWithValue(message);
    }
  }
);

export const createQuizQuestion = createAsyncThunk(
  "createQuizQuestion",
  async (payload: any, thunkApi) => {
    try {
      writeToLocalStorage("QuizQuestions", [ ...payload ]);
      const response = readFromLocalStorage("QuizQuestions");
      return response;
    } catch (error: any) {
      const message = error.message;
      return thunkApi.rejectWithValue(message);
    }
  }
);
export const getQuizQuestions = createAsyncThunk(
  "getQuizQuestions",
  async (_, thunkApi) => {
    try {
      const response = await readFromLocalStorage("QuizQuestions");
      console.log("response", response);

      return response;
    } catch (error: any) {
      const message = error.message;
      return thunkApi.rejectWithValue(message);
    }
  }
);

const quizzesSlice = createSlice({
  name: "quizzesCreation",
  initialState,
  reducers: {
    updateQuizzesData: (state, action: PayloadAction<any>) => {
      state.quiz = { ...state.quiz, ...action.payload };
    },
  },
  extraReducers(builder) {
    builder
      .addCase(createQuiz.pending, (state) => {
        state.loading = true;
      })
      .addCase(createQuiz.fulfilled, (state, action: PayloadAction<any>) => {
        state.loading = false;
        state.quiz = action.payload;
      })

      .addCase(
        createQuizSettings.fulfilled,
        (state, action: PayloadAction<any>) => {
          state.loading = false;
          state.quizSettings = action.payload;
        }
      )

      .addCase(
        createQuizQuestion.fulfilled,
        (state, action: PayloadAction<any>) => {
          state.loading = false;
          state.quizQuestions = action.payload;
        }
      )

      .addCase(createQuiz.rejected, (state, action: PayloadAction<any>) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(getQuizzes.pending, (state) => {
        state.loading = true;
      })
      .addCase(getQuizzes.fulfilled, (state, action: PayloadAction<any>) => {
        state.loading = false;
        state.quiz = action.payload;
      })

      .addCase(
        getQuizQuestions.fulfilled,
        (state, action: PayloadAction<any>) => {
          state.loading = false;
          state.quizQuestions = action.payload;
        }
      )

      .addCase(
        getQuizsettings.fulfilled,
        (state, action: PayloadAction<any>) => {
          state.loading = false;
          state.quizSettings = action.payload;
        }
      )

      .addCase(getQuizzes.rejected, (state, action: PayloadAction<any>) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export const { updateQuizzesData } = quizzesSlice.actions;

export default quizzesSlice.reducer;
