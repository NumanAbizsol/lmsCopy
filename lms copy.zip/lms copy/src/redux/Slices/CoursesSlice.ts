// organizationSlice.ts
import { createSlice, PayloadAction,createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { readFromLocalStorage, writeToLocalStorage } from './localStorageReadWrite/readWrite';
interface CourseCreationState {
        loading: boolean;
        error: string | null;
        course: any[] ;
        sections:[]
      }
      


const initialState: CourseCreationState = {
    loading: false,
    error: null,
    course:[] ,
    sections:[]
  };
  export const createCourse = createAsyncThunk (
    "createCourse",
    async (payload: any, thunkApi) => {
      console.log('payload',payload)
      try {
        writeToLocalStorage("course", {...payload});

        const response = readFromLocalStorage("course");
        // await axios.post<any>(
        //   "http://localhost:4000/organization",
        //   payload
        // );
        return response;
      } catch (error: any) {
        const message = error.message;
        return thunkApi.rejectWithValue(message);
      }
    }
  );
  export const  createSections=createAsyncThunk (
    "createSections",
    async (payload: any, thunkApi) => {
      console.log('payload',payload)
      try {
        writeToLocalStorage("sections", {...payload});

        const response = readFromLocalStorage("sections");
        // await axios.post<any>(
        //   "http://localhost:4000/organization",
        //   payload
        // );
        return response;
      } catch (error: any) {
        const message = error.message;
        return thunkApi.rejectWithValue(message);
      }
    }
  );
  export const getSections = createAsyncThunk (
    "getsections",
    async (_ ,thunkApi) => {
      try {
        const response =await readFromLocalStorage("sections");
        console.log("response",response)
        // axios.get<any>(
        //   "http://localhost:4000/organization"
        // );
        return [response];
      } catch (error: any) {
        const message = error.message;
        return thunkApi.rejectWithValue(message);
      }
    }
  ); 
  export const getCourse = createAsyncThunk (
    "getCourse",
    async (_ ,thunkApi) => {
      try {
        const response =await readFromLocalStorage("course");
        console.log("response",response)
        // axios.get<any>(
        //   "http://localhost:4000/organization"
        // );
        return [response];
      } catch (error: any) {
        const message = error.message;
        return thunkApi.rejectWithValue(message);
      }
    }
  );
const courseSlice = createSlice({
  name: 'courseCreation',
  initialState,
  reducers: {
    updateOrganizationData: (state, action: PayloadAction<any>) => {
      state.course = { ...state.course , ...action.payload };
    },

  },
  extraReducers(builder) {
    builder
      .addCase(createCourse.pending, (state) => {
        state.loading = true;
      })
      .addCase(createCourse.fulfilled, (state, action: PayloadAction<any>) => {
        state.loading = false;
        state.course = action.payload;
      })
      .addCase(createCourse.rejected, (state, action: PayloadAction<any>) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(createSections.fulfilled, (state, action: PayloadAction<any>) => {
        state.loading = false;
        state.sections = action.payload;
      })
      .addCase(getCourse.pending, (state) => {
        state.loading = true;
      })
      .addCase(getCourse.fulfilled, (state, action: PayloadAction<any>) => {
        state.loading = false;
        state.course = action.payload;
      })
      .addCase(getSections.fulfilled, (state, action: PayloadAction<any>) => {
        state.loading = false;
        state.sections = action.payload;
      })
      .addCase(getCourse.rejected, (state, action: PayloadAction<any>) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export const { updateOrganizationData } = courseSlice.actions;

export default courseSlice.reducer;
