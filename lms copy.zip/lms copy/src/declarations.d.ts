declare module '*.png,*.svg';
declare module '*.mp4' {
    const src: string;
    export default src;
  }

declare module 'react-html-parser';