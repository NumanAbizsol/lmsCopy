export const SMALL_MODAL: string = '300px';
export const MEDIUM_MODAL: string = '600px';
export const LARGE_MODAL: string = '800px';