import listoforganizationframe from "../assets/images/listofOrganizationframe.svg";
// UpdatedOrganizationDashoard
import orgProduct from "../assets/images/org-product.png";
import orgUser from "../assets/images/org-user.png";
import orgRevenue from "../assets/images/org-revenue.png";
import orgRating from "../assets/images/org-rating.png";
import Brandicon from "../assets/images/Brand icon.png";

import Brandiconnnnn from "../assets/images/Brand iconnnnn.png";
import Brandiconn from "../assets/images/Brand iconn.png";
import examcalender from '../assets/images/examcalender.png'
import hourGlass from '../assets/images/HorseGlass.png'
import clock from '../assets/images/clcok.png'
import hourSheet from '../assets/images/HourSheet.png'
import  {ExamDataItem}  from "../features/student/dashboard/examPlan/ExamPlanStudent.d";

// Footer
export const footerLinks = [
  { key: "1", name: "Our Company", path: "/" },
  { key: "2", name: "About Us", path: "/" },
  { key: "3", name: "Contact Us", path: "/" },
  { key: "4", name: "Community", path: "/" },
  { key: "5", name: "Student Perks", path: "/" },
  { key: "6", name: "Blog", path: "/" },
  { key: "7", name: "Affiliate Program", path: "/" },
  { key: "8", name: "Careers", path: "/" },
];
export const footerCommunity = [
  { key: "1", name: "HTML", path: "/" },
  { key: "2", name: "CSS", path: "/" },
  { key: "3", name: "Design", path: "/" },
  { key: "4", name: "JavaScript", path: "/" },
  { key: "5", name: "Ruby", path: "/" },
  { key: "6", name: "PHP", path: "/" },
  { key: "7", name: "Android", path: "/" },
  { key: "8", name: "Development Tools", path: "/" },
  { key: "9", name: "Business", path: "/" },
];
export const footerResources = [
  { key: "1", name: "Web Design", path: "/" },
  { key: "2", name: "Web Development", path: "/" },
  { key: "3", name: "Rails Development", path: "/" },
  { key: "4", name: "PHP Development", path: "/" },
  { key: "5", name: "Android Development", path: "/" },
  { key: "6", name: "Starting a Business", path: "/" },
];
export const footerSupport = [
  { key: "1", name: "Documentation", path: "/" },
  { key: "2", name: "Forums", path: "/" },
  { key: "3", name: "Language Packs", path: "/" },
  { key: "4", name: "Release Status", path: "/" },
];
// ABOUTYOURLMS

export const IdentifyYourSelf = [
  { label: "Select an option", value: "" },
  { label: "Speaker", value: "Speaker" },
  { label: "Author/Blogger", value: "Author/Blogger" },
  { label: "Social influencer", value: "Social influencer" },
  { label: "Coach", value: "Coach" },
  {
    label: "I Work As Part Of A Larger Company ",
    value: "I Work As Part Of A Larger Company",
  },
];

export const WorkInYourBusiness = [
  { label: "Select an option", value: "" },
  {
    label:
      "I Have An Online Learing Business, And I Am Switching From Another Platfrom",
    value:
      "I Have An Online Learing Business, And I Am Switching From Another Platfrom",
  },
  {
    label:
      "Have An Online Learing Business, But Don't Currently Use A Plateform ",
    value:
      "Have An Online Learing Business, But Don't Currently Use A Plateform",
  },
  {
    label: "I Have A Learning Business, But it is Not Online",
    value: "I Have A Learning Business, But it is Not Online",
  },
  { label: "I'm Just Messing Around", value: "I'm Just Messing Around" },
  { label: "I'm Just Messing Around", value: "I'm Just Messing Around" },
];

export const BusinessIn = [
  { label: "Select an option", value: "" },
  { label: "Arts & Entertainment", value: "Arts & Entertainment" },
  { label: "Business & Marketing", value: "Business & Marketing" },
  { label: "Career Development", value: "Career Development" },
  { label: "Fashion & Beauty", value: "Fashion & Beauty" },
  { label: "Health & Beauty", value: "Health & Beauty" },
];

export const LearingBusiness = [
  { label: "Select an option", value: "" },
  {
    label:
      "I Have An Online Learing Business, And I Am Switching From Another Platfrom",
    value:
      "I Have An Online Learing Business, And I Am Switching From Another Platfrom",
  },
  {
    label:
      "Have An Online Learing Business, But Don't Currently Use A Plateform ",
    value:
      "Have An Online Learing Business, But Don't Currently Use A Plateform",
  },
  {
    label: "I Have A Learning Business, But it is Not Online",
    value: "I Have A Learning Business, But it is Not Online",
  },
  { label: "I'm Just Messing Around", value: "I'm Just Messing Around" },
  { label: "I'm Just Messing Around", value: "I'm Just Messing Around" },
];
export const EmailList = [
  { label: "Select an option", value: "" },

  { label: "Yes 100,000+ people", value: "Yes 100,000+ people" },
  { label: "Yes 10,000-100,000 people", value: "Yes 10,000-100,000 people" },
  { label: "Yes 1,000-10,000 people", value: "Yes 1,000-10,000 people" },
  { label: "Yes 100-1,000 people", value: "Yes 100-1,000 people" },
];

// ListOfOrganization

export const ListOfOrganizationData = [
  {
    heading: "Learning Management System",
    para: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
  },
  {
    heading: "HRM",
    para: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
  },
  {
    heading: "Ecom",
    para: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
  },
];

export const monthlyPrices = [
  { price: "Free", buttonText: "Choose This Plan", smallHeading: "/Lifetime" },
  { price: "$40", buttonText: "Choose This Plan", smallHeading: "/month" },
  { price: "$90", buttonText: "Choose This Plan", smallHeading: "/month" },
];

export const yearlyPrices = [
  { price: "Free", buttonText: "Choose This Plan", smallHeading: "/Lifetime" },
  { price: "$400", buttonText: "Choose This Plan", smallHeading: "/year" },
  { price: "$900", buttonText: "Choose This Plan", smallHeading: "/year" },
];

export const rows = [
  {
    price: "Free",
    buttonText: "Choose This Plan",
    smallHeading: "/Lifetime",
  },
  {
    price: "$40",
    smallHeading: "/month",
    buttonText: "Choose This Plan",
  },
  {
    price: "$90",
    smallHeading: "/month",
    buttonText: "Choose This Plan",
  },
  {
    headings: "E-Com",
    para2: "Choose your workspace plan according to your organisational pla",
  },
  { heading: "Unlimited", para: "Pages Add-ons on Demand" },
  { heading: "Unlimited", para: "Pages Add-ons on Demand" },
  { heading: "Unlimited", para: "Pages Add-ons on Demand" },
  { headings: "Number of Users" },
  { heading: "Unlimited", para: "Pages Add-ons on Demand" },
  { heading: "Unlimited", para: "Pages Add-ons on Demand" },
  { heading: "Unlimited", para: "Pages Add-ons on Demand" },
  { headings: "Users Per Page" },
  {
    imgSrc: listoforganizationframe,
  },
  {
    imgSrc: listoforganizationframe,
  },
  {
    imgSrc: listoforganizationframe,
  },
  { headings: "Includes essential features to get started" },
  {
    imgSrc: listoforganizationframe,
  },
  {
    imgSrc: listoforganizationframe,
  },
  {
    imgSrc: listoforganizationframe,
  },
  {
    headings: "More advanced features for increased productivity",
  },
  {
    imgSrc: listoforganizationframe,
  },
  {
    imgSrc: listoforganizationframe,
  },
  {
    imgSrc: listoforganizationframe,
  },
  {
    headings: "Designing & Development",
  },
  {
    imgSrc: listoforganizationframe,
  },
  {
    imgSrc: listoforganizationframe,
  },
  {
    imgSrc: listoforganizationframe,
  },
  {
    headings: "Customizable options to meet your specific needs",
  },
  {
    imgSrc: listoforganizationframe,
  },
  {
    imgSrc: listoforganizationframe,
  },
  {
    imgSrc: listoforganizationframe,
  },
  {
    headings: "Secure data storage",
  },
  {
    imgSrc: listoforganizationframe,
  },
  {
    imgSrc: listoforganizationframe,
  },
  {
    imgSrc: listoforganizationframe,
  },
  {
    headings: "Email Support",
  },
  {
    imgSrc: listoforganizationframe,
  },
  {
    imgSrc: listoforganizationframe,
  },
  {
    imgSrc: listoforganizationframe,
  },
  {
    headings: "24/7 customer support",
  },
  {
    imgSrc: listoforganizationframe,
  },
  {
    imgSrc: listoforganizationframe,
  },
  {
    imgSrc: listoforganizationframe,
  },
  {
    headings: "Analytics and reporting",
  },
];

// AddVideo
export const checkboxData = [
  "Make this a free preview lesson.",
  "Enable discussion for this lesson apply to all lessons in this course.",
  "Make this video content downloadable.",
  "Make this a prerequisite.",
  "Lesson icons & label.",
];

// UpdatedOrganizationDashoard
export const cardData = [
  {
    id: 1,
    imageUrl: orgProduct,
    title: "3",
    description: "No of Products",
  },
  {
    id: 2,
    imageUrl: orgUser,
    title: "16",
    description: "No of Users",
  },
  {
    id: 3,
    imageUrl: orgRevenue,
    title: "$1242",
    description: "Total Revenue",
  },
  {
    id: 4,
    imageUrl: orgRating,
    title: "4.5/5",
    description: "Average Rating",
  },
];
// LandingPage 
export const boxData = [
  {
    id: 1,
    imgSrc: Brandicon,
    heading: "Lorem ipsum dolor sit amet",
    para: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maiores impedit perferendis suscipit eaque, iste dolor cupiditate blanditiis ratione.",
  },
  {
    id: 2,
    imgSrc: Brandiconnnnn,
    heading: "Lorem ipsum dolor sit amet",
    para: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maiores impedit perferendis suscipit eaque, iste dolor cupiditate blanditiis ratione.",
  },
  {
    id: 3,
    imgSrc: Brandiconn,
    heading: "Lorem ipsum dolor sit amet",
    para: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maiores impedit perferendis suscipit eaque, iste dolor cupiditate blanditiis ratione.",
  },
];


export const examData1:ExamDataItem[] = [
  {
    icon: examcalender,
    date: "11/10/23",
    description: "Sitting On",
    color: "#B7F9FF",
    backgroundColor: "#006D77",
  },
  {
    icon: hourGlass,
    date: "10/09/23",
    description: "Finish Studying on",
    color: "#FFFFFF",
    backgroundColor: "#83C5BE",
  },
  {
    icon: clock,
    date: "5 Days",
    description: "Time left for review",
    color: "#218C75",
    backgroundColor: "#EDF6F9",
  },
  {
    icon: hourSheet,
    date: "55 Hours for 3 week",
    description: "This Plan",
    color: "#FFFFFF",
    backgroundColor: "#FFB49C",
  },
];

export const examScheduleData=[
  { day: "Mon", isChecked: false, rangeValue: 12, age: 12 },
  { day: "Tue", isChecked: false, rangeValue: 12, age: 12 },
  { day: "Wed", isChecked: false, rangeValue: 12, age: 12 },
  { day: "Thr", isChecked: false, rangeValue: 12, age: 12 },
  { day: "Fri", isChecked: false, rangeValue: 12, age: 12 },
  { day: "Sat", isChecked: false, rangeValue: 12, age: 12 },
  { day: "Sun", isChecked: false, rangeValue: 12, age: 12 },
]