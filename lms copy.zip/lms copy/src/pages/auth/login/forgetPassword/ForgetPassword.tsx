import { useState } from "react";
import { Link } from "react-router-dom";
import back from "../../../../assets/images/Back.png";
import "./ForgetPassword.scss";
import { validateEmail } from "../../../../components/shared/formValidations/validation";
import { useAppSelector } from "../../../../hooks/useTypedSelector";
import CustomButton from "../../../../components/shared/button/Button";
import CustomInput from "../../../../components/inputs/input/Input";

const ForgetPassword = () => {
  const enteredEmail = useAppSelector((state: any) => state?.user?.user?.email);
  const [email, setEmail] = useState<string>(enteredEmail || "");
  const [error, setError] = useState<string | null>("");

  const handleSendCode = () => {
    setError(validateEmail(email));
    if (!error) {
      console.log(`Sending code to ${email}`);
    }
  };

  return (
    <div className="forget-password-container">
      <Link to="/login">
        <img src={back} alt="back-arrow" />
      </Link>
      <div className="content-wraper">
        <div className="main-heading">Forget Password</div>
        <p>Enter the email address associated with your account.</p>
        <p>
          Enter your email address below, and we'll send you a code or a reset
          password link.
        </p>
        <div className="email-input">
          <label className="input-label">
            Email<span className={` ${error ? "error" : ""}`}>*</span>
          </label>
          <CustomInput
            type="email"
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
              setError("");
            }}
            placeholder="Enter your email"
          />
          <div className="error-message">{error ?? " "}</div>
        </div>
        <CustomButton
          onClick={handleSendCode}
          variant="primary"
          className="code-custom-button"
          childClasses=""
        >
          Send Code
        </CustomButton>
      </div>
    </div>
  );
};

export default ForgetPassword;
