export type ForgetPasswordProps = {
    // You can define any additional props you need
    setShowForget?:any
  }