export type Login = {
    email: string;
    password: string;
  }