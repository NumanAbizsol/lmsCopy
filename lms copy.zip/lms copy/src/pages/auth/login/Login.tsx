import { useState, FormEvent, useEffect } from "react";
import "./Login.scss";
import Logo from "../../../assets/images/urqaalogo.png";
import { EyeInvisibleOutlined, EyeTwoTone } from "@ant-design/icons";
import {
  validateEmail,
  validatePassword,
} from "../../../components/shared/formValidations/validation";
import { useNavigate } from "react-router-dom";
import {
  useAppDispatch,
  useAppSelector,
} from "../../../hooks/useTypedSelector";
import { login, setEmail } from "../../../redux/Slices/login-registerSlice";
import { Login } from "./Login.d";
import { toast } from "react-toastify";
import CustomButton from "../../../components/shared/button/Button";
import CustomInput from "../../../components/inputs/input/Input";
import registerLogo from "../../../assets/images/registerLogo.svg";

export default function Home() {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  let { user } = useAppSelector((state: any) => state.user) || {};
  const [loginData, setLoginData] = useState<Login>({
    email: "",
    password: "",
  });
  const [error, setError] = useState<{ email: string; password: string }>({
    email: "",
    password: "",
  });
  const [passwordVisible, setPasswordVisible] = useState(false);

  useEffect(() => {
    if (user) {
      // navigate("/my-organizations");
    }
  }, [user]);

  // const handleVarificationClick = () => {
  //   if (!error.email && !error.password) {
  //     dispatch(login(loginData));
  //   } else {
  //     toast.error("Invalid email or password", {
  //       position: toast.POSITION.TOP_RIGHT,
  //     });
  //   }
  // };

  const handleForget = () => {
    navigate("/forget-password");
  };

  const handleFormSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const newError = {
      email: validateEmail(loginData.email) ?? "",
      password: validatePassword(loginData.password) ?? "",
    };
    setError(newError);
    if (!newError.email && !newError.password) {
      dispatch(login(loginData));
      navigate("/updated-organization-dashboard");
    } else {
      toast.error("Invalid email or password", {
        position: toast.POSITION.TOP_RIGHT,
      });
    }
  };

  return (
    <>
      <div className="divide-screen">
        <div className="home_image_Signin" style={{ background: "#F8FAFC" }}>
          <img src={Logo} alt="Logo" className="home_image_Signin_logo" />
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <img src={registerLogo} alt="Logo" style={{ width: "100%" }} />
          </div>
        </div>

        <div className="container_signin">
          <div>
            <div className="main-heading">Log in</div>
          </div>
          <form onSubmit={handleFormSubmit}>
            <div className="m_t_20">
              <label htmlFor="email" className="input-label">
                Email<span className={` ${error.email ? "error" : ""}`}>*</span>
              </label>
              <CustomInput
                placeholder="Enter your email"
                value={loginData.email}
                onChange={(e) => {
                  dispatch(setEmail(e.target.value));
                  setLoginData((state) => ({
                    ...state,
                    email: e.target.value,
                  }));
                  setError((state) => ({
                    ...state,
                    email: "",
                  }));
                }}
              />
              <div className="error-message">
                {error.email ? error.email : " "}
              </div>
            </div>

            <div className="m_t_20" style={{ position: "relative" }}>
              <label htmlFor="password" className="input-label">
                Password
                <span className={` ${error.password ? "error" : ""}`}>*</span>
              </label>
              <CustomInput
                type={passwordVisible ? "text" : "password"}
                placeholder="Create a password"
                value={loginData.password}
                onChange={(e) => {
                  setLoginData((state) => ({
                    ...state,
                    password: e.target.value,
                  }));
                  setError((state) => ({
                    ...state,
                    password: "",
                  }));
                }}
              />
              <span
                className="password-icon right-icon"
                onClick={() => setPasswordVisible(!passwordVisible)}
              >
                {passwordVisible ? <EyeInvisibleOutlined /> : <EyeTwoTone />}
              </span>

              <div className="error-message">
                {error.password ? error.password : " "}
              </div>
            </div>
            <div
              className="forget-password-text"
              onClick={handleForget}
              style={{ marginTop: "16px" }}
            >
              Forget Password.
            </div>

            <div>
              <CustomButton
                type="submit"
                variant="primary"
                className="form_btn_Signin"
              >
                Login
              </CustomButton>
            </div>
          </form>

          <div className="ending_details_Signin">
            Don't have an account ?
            <span>
              <b
                onClick={() => {
                  navigate("/register");
                }}
              >
                Sign up
              </b>
            </span>
          </div>
        </div>
      </div>
    </>
  );
}
