export interface Register {
    firstName: string;
    lastName: string;
    email: string;
    password: string;
    planType?:string;
    confirmPassword:string
  }