import React, { useEffect, useState } from "react";
import OtpInput from "react-otp-input";
import Otp from "../../../../assets/images/Otp.png";
import "./OtpPage.scss";
import { useNavigate } from "react-router-dom";
import CustomButton from "../../../../components/shared/button/Button";

function OtpPage() {
  const navigate = useNavigate();
  const [otp, setOtp] = useState("");
  const [resentCode, setResendCode] = useState(false);
  useEffect(() => {
    if (otp.length === 6) {
      navigate("/organization");
    }
  }, [otp]);
  const handleResendCode = () => {
    setResendCode(true);
  };

  const handleNextClick = () => {};
  const [seconds, setSeconds] = useState(59);
  const [minutes, setMinutes] = useState(1);

  useEffect(() => {
    const timerInterval = setInterval(() => {
      if (seconds > 0) {
        setSeconds(seconds - 1);
      } else {
        if (minutes > 0) {
          setMinutes(minutes - 1);
          setSeconds(59);
        } else {
          clearInterval(timerInterval);
        }
      }
    }, 1000);

    return () => clearInterval(timerInterval);
  }, [seconds, minutes]);
  return (
    <div className="MainBackground divide-screen">
      <div className="Background">
        <div className="centered-content">
          <div className="logo">
            <img src={Otp} alt="otp image" />
          </div>
          <h1 className="main-heading" style={{ justifyContent: "center" }}>
            OTP Authentication
          </h1>
          <p className="paragraph">
            please check the email linked to your account to retrieve your
            verification code
          </p>
          <div className="otp-input">
            <OtpInput
              value={otp}
              onChange={setOtp}
              numInputs={6}
              renderSeparator={<span>-</span>}
              renderInput={(props) => <input {...props} />}
              shouldAutoFocus
            />
          </div>
          <div className="timer" style={{ color: "#10BAAC" }}>
            Resend OTP in {String(minutes).padStart(2, "0")}:
            {String(seconds).padStart(2, "0")}
          </div>
          <p className="resend-code">
            I didn't receive the code.{" "}
            <span className="paragraph" onClick={handleResendCode}>
              {" "}
              Resend Code
            </span>
          </p>
          <br />
          <CustomButton
            variant="primary"
            className="centered-button "
            onClick={handleNextClick}
          >
            Next
          </CustomButton>
        </div>
      </div>
    </div>
  );
}

export default OtpPage;
