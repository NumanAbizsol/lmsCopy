import { useState, FormEvent } from "react";
import { EyeInvisibleOutlined, EyeTwoTone } from "@ant-design/icons";
import Logo from "../../../assets/images/urqaalogo.png";
import registerLogo from "../../../assets/images/registerLogo.svg";
import { useNavigate } from "react-router-dom";
import { Register } from "./Register.d";
import { useAppDispatch } from "../../../hooks/useTypedSelector";
import { register } from "../../../redux/Slices/login-registerSlice";
import CustomInput from "../../../components/inputs/input/Input";
import CustomButton from "../../../components/shared/button/Button";
import CustomCheckbox from "../../../components/inputs/Customcheckbox/CustomCheckbox";
import {
  validateConfirmPassword,
  validateEmail,
  validateFirstName,
  validatePassword,
} from "../../../components/shared/formValidations/validation";
import { Avatar } from "antd";


import { Icon } from "@iconify/react";
import { toast } from "react-toastify";
import PasswordValidator from "./ValidatePassword";
import axios from "axios";

export default function Home() {
  const [signupData, setSignupData] = useState<Register>({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const [errors, setErrors] = useState<{
    firstName: string;
    email: string;
    password: string;
    confirmPassword: string;
  }>({
    firstName: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [confirmPasswordVisible, setConfirmPasswordVisible] = useState(false);
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const handleFormSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const newErrors = {
      firstName: validateFirstName(signupData.firstName) ?? "",
      email: validateEmail(signupData.email) ?? "",
      password: validatePassword(signupData.password) ?? "",
      confirmPassword:
        validateConfirmPassword(
          signupData.password,
          signupData.confirmPassword
        ) ?? "",
    };
    setErrors(newErrors);

    if (
      newErrors.firstName === "" &&
      newErrors.email === "" &&
      newErrors.password === "" &&
      newErrors.confirmPassword === ""
    ) {
      const initials = (signupData.firstName[0] + signupData.lastName[0]).toUpperCase();
    const avatar = (
      <Avatar size={32} style={{ backgroundColor: "#87d068" }}>
        {initials}
      </Avatar>
    );

    setSignupData((state) => ({
      ...state,
      avatar,
    }));
      localStorage.setItem("firstName", signupData.firstName);
      localStorage.setItem("lastName", signupData.lastName);

      // Make OTP request
      try {
        const response = await axios.post(
          "https://a377-203-96-170-97.ngrok-free.app/user/otp/generate",
          {
            username: signupData.firstName,
            refrenece_key: signupData.email,
            user_case: "forgetpassword",
            subject: "Otp verify",
          }
        );

        if (response.status === 200) {
          dispatch(register(signupData));
          navigate("/otp");
        } else {
          toast.error("Failed to send OTP", {
            position: toast.POSITION.TOP_RIGHT,
          });
        }
      } catch (error) {
        toast.error("Network error while sending OTP", {
          position: toast.POSITION.TOP_RIGHT,
        });
      }
    }
  };
  const handleInputChange = (field: keyof Register, value: string) => {
    setSignupData((state) => ({
      ...state,
      [field]: value,
    }));
    setErrors((state) => ({
      ...state,
      [field]: "",
    }));
  };

  return (
    <>
      <div className="divide-screen">
        <div className="home_image_Signin" style={{ background: "#F8FAFC" }}>
          <img src={Logo} alt="Logo" className="home_image_Signin_logo" />
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <img src={registerLogo} alt="Logo" style={{ width: "100%" }} />
          </div>
        </div>

        <div className="signup_container">
          <div className="login_details">
            Already have an account?
            <span>
              <b onClick={() => navigate("/login")}>Log in</b>
            </span>
          </div>
          <div className="main-heading">Sign up</div>
          <form onSubmit={handleFormSubmit}>
            <label className="input-label">
              First Name
              <span className={` ${errors.firstName ? "error" : ""}`}>*</span>
            </label>
            <CustomInput
              placeholder="Enter Your Name"
              value={signupData.firstName}
              onChange={(e) => handleInputChange("firstName", e.target.value)}
            />
            <div className="error-message">
              {errors.firstName ? errors.firstName : " "}
            </div>

            <label className="input-label">Last Name</label>
            <CustomInput
              placeholder="Type Your Last Name"
              value={signupData.lastName}
              onChange={(e) => handleInputChange("lastName", e.target.value)}
            />

            <label className="input-label">
              Email
              <span className={` ${errors.firstName ? "error" : ""}`}>*</span>
            </label>
            <CustomInput
              placeholder="Enter your email"
              value={signupData.email}
              onChange={(e) => handleInputChange("email", e.target.value)}
            />
            <div className="error-message">
              {errors.email ? errors.email : " "}
            </div>
            <div style={{ position: "relative" }}>
              <label className="input-label">
                Password
                <span className={` ${errors.password ? "error" : ""}`}>*</span>
              </label>
              <CustomInput
                type={passwordVisible ? "text" : "password"}
                placeholder="Create a password"
                value={signupData.password}
                onChange={(e) => {
                  setSignupData((state) => ({
                    ...state,
                    password: e.target.value,
                  }));
                  setErrors((state) => ({
                    ...state,
                    password: "",
                  }));
                }}
              />
              <span
                className="password-icon right-icon"
                onClick={() => setPasswordVisible(!passwordVisible)}
              >
                {passwordVisible ? <EyeInvisibleOutlined /> : <EyeTwoTone />}
              </span>
              <div className="error-message">
                {errors.password ? errors.password : " "}
              </div>
            </div>
            <PasswordValidator password={signupData.password} />

            <div style={{ position: "relative" }}>
              <label className="input-label">
                Confirm Password
                <span className={` ${errors.password ? "error" : ""}`}>*</span>
              </label>
              <CustomInput
                type={confirmPasswordVisible ? "text" : "password"}
                placeholder="Confirm password"
                value={signupData.confirmPassword}
                onChange={(e) => {
                  setSignupData((state) => ({
                    ...state,
                    confirmPassword: e.target.value,
                  }));
                  setErrors((state) => ({
                    ...state,
                    confirmPassword: "",
                  }));
                }}
              />
              <span
                className="password-icon right-icon"
                onClick={() =>
                  setConfirmPasswordVisible(!confirmPasswordVisible)
                }
              >
                {confirmPasswordVisible ? (
                  <EyeInvisibleOutlined />
                ) : (
                  <EyeTwoTone />
                )}
              </span>
              <div className="error-message">
                {errors.confirmPassword ? errors.confirmPassword : " "}
              </div>
            </div>
            <div className="divide-screen" style={{ alignItems: "flex-start" }}>
              <CustomCheckbox
                onChange={(e) => console.log("checked")}
                defaultChecked={true}
              />
              <div className="promotional-text">
                Sign up to receive the latest product updates, exclusive
                subscriber promotions, and inspiring Hero stories.
              </div>
            </div>
            <div className="m_t_20">
              <CustomButton
                type="submit"
                variant="primary"
                className="form_btn_Signin"
                customStyle={{ width: "100%", height: "46px" }}
              >
                Continue
              </CustomButton>
            </div>
          </form>
          <div className="social-icons-wrapper m_t_20">
            <div className="signup-text-wraper">
              <span className="signup-line-left"></span>
              <span className="signup-text">or sign up with</span>
              <span className="signup-line-right"></span>
            </div>
          </div>

          <div className="social-icons m_t_20 m_b_20">
            <Icon icon="logos:google-icon" height="24" />
            <Icon icon="devicon:apple" height="24" />
            <Icon icon="fa-brands:yahoo" height="24" />
            <Icon icon="devicon:facebook" height="24" />
            <Icon icon="devicon:linkedin" height="24" />
            <Icon icon="skill-icons:twitter" height="24" />
          </div>

          <div className="urqa-msg">
            <p>
              Urqa will use your data to enhance your experience and to send you
              information. You can change your communication preferences
              anytime. We may use your data as described in our Privacy Policy.
              By clicking “Continue”, you agree to our{" "}
              <span className="terms-and-service">Terms of Service </span> and
              acknowledge that you have read our{" "}
              <span className="privacy-policy">Privacy Policy</span>.
            </p>
          </div>
        </div>
      </div>
    </>
  );
}
