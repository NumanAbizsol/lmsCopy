import { useState } from "react";
import { useAppSelector } from "./hooks/useTypedSelector";

const usePermission = () => {
  // let { userData, error } = useAppSelector((state: any) => state.user);
  const [user, setUser] = useState<any>({
    // ...userData, // 'admin' etc.
    permissions: [
      "CREATE_ORGANIZATION",
      "CREATE_APP",
      "EDIT_ORGANIZATION",
      "EDIT_APP",
      'ROUTE_CREATE_ORGANIZATION',
      'CREATE_COURSE',
      "EDIT_COURSE",
      "ADD_SECTION",
      "ADD_CHAPTER",
      "ADD_LESSON",
      "ADD_VIDEO-LESSON",
      "ADD_AUDIO_LESSON",
      "ADD_PDF_LESSON",
      "ADD_TEXT_LESSON",
      "ADD_DOCUMENT_LESSON",

      "CREATE_QUIZ",
      "EDIT_QUIZ",
      "QUIZ_TYPE",
      "FEEDBACK_AFTER_EACH_ATTEMPT",
      "FEEDBACK_AFTER_QUIZSETTING",

    ], // User's list of allowed actions

    roles: ["admin", "teacher", "student"],
    
  });

  const setRoleDetails = (role: string) => {
    switch (role) {
      case "admin":
        return {
          slug: "admin",
          description: "Administrator",
          accessLevel: "full-access",
          modificationAccess: "all",
        };
      case "teacher":
        return {
          slug: "teacher",
          description: "regular user",
          accessLevel: "read-write",
          modificationAccess: "limited",
        };
      case "student":
        return {
          slug: "student",
          description: "Student",
          accessLevel: "read-only",
          modificationAccess: "limited",
        };
      default:
        return {
          slug: "user",
          description: "Regular User",
          accessLevel: "read-only",
          modificationAccess: "limited",
        };
    }
  };

  const hasRole = (role: string) => {
    return user.roles.includes(role);
  };

  const hasPermissionForAction = (action: string) => {
    return user.permissions.find((per: string) => per === action);
  };

  return {
    user: {
      ...user,
      ...(hasRole(user.roles[0]) && setRoleDetails(user.roles[0])),
    },
    hasRole,
    hasPermissionForAction,
  };
};

export default usePermission;
