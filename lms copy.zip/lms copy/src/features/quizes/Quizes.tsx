import "./Quizes.scss";
import QuizDashBoard from "./quizTemplates/QuizDashBoard";
export default function Quizes() {
  return (
    <div className="quizes-container">
      <QuizDashBoard/>
    </div>
  );
}
