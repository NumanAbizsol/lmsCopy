export type CourseProps = {
    handlecourseChange: (data: { title: string; description: string }) => void;
    oncancelsave: () => void;
    style?: React.CSSProperties;
    width?:string;
}

export interface Cources{
    id:string;
    title:string;
    tagLine:string;
    url:string;
    description:string;
    thumbnail:string;
    section?:Section[]
}

export interface Section{
    id:string;
    title:string;
    description:string;
    chapter?:Chapter[]
    content?:content[]
}

export interface Chapter{
    id:string;
    title:string;
    tagLine:string;
    slug:string;
    description:string;
    content?:content[]
}

export interface content{
    audio:audio;
    video:string;
    document:string;
    thumbnails:string;
}