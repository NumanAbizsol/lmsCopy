import React, { useState } from "react";
import { Input, Dropdown, Menu, Checkbox } from "antd";
import { FiFilter } from "react-icons/fi";
import { Icon } from "@iconify/react";
import ListingPage from "./quizListing";
import CreateQuiz from "../createQuiz/CreateQuiz";
import Sidebar from "../../../components/shared/headerAndTabs/sidebar/Sidebar";
import HeaderTabsAndNevbar from "../../../components/shared/headerAndTabs/headerTabsAndSidebar";
interface Coursedatatypes {
  title: string;
  thumbnail: string;
  questions: string;
  rating: number;
  enrolledStudents: number;
}
const { Search } = Input;
const QuizDashBoard = () => {
  const filtervalue = [
    { key: "newlycreated", label: "Newly Created" },
    { key: "oldest", label: "Oldest" },
    { key: "toprated", label: "Top Rated" },
    { key: "topseller", label: "Top Seller" },
    { key: "lowestsale", label: "Lowest Sale" },
  ];

  const [searchinput, setSearchInput] = useState<string>("");
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(true);
  const [sortingOption, setSortingOption] = useState();

  const handlesearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchInput(e.target.value);
  };

  const sortingMenu = (
    <Menu
      onClick={({ key }: any) => setSortingOption(key)}
      className="sorting-menu-card"
    >
      {filtervalue.map((option) => (
        <Menu.Item key={option.key}>
          <Checkbox checked={sortingOption === option.key}>
            {option.label}
          </Checkbox>
        </Menu.Item>
      ))}{" "}
    </Menu>
  );
  const tabData: any = [
    { name: "Quiz Listing", page: ListingPage },
    { name: "Add Quiz", page: CreateQuiz },
  ];
  return (
    <div className="wraper" style={{ display: "flex" }}>
      <div style={{ width: !isSidebarCollapsed ? "5%" : "16%" }}>
        <Sidebar
          isSidebarCollapsed={isSidebarCollapsed}
          setIsSidebarCollapsed={setIsSidebarCollapsed}
        />
      </div>
      <div style={{ width: "100%" }}>
        <>
          <div className="course-management-container">
            <div className="course-management-header d-flex">
              <h2>Quiz Management</h2>
              <div className="filter-icons">
                <Dropdown overlay={sortingMenu} trigger={["click"]}>
                  <span
                    className="single-icon"
                    onClick={(e) => e.preventDefault()}
                  >
                    <FiFilter height="24" />
                  </span>
                </Dropdown>
                <span className="multiple-icons">
                  <Icon icon="ph:list-bold" color="#10BAAC" height="24" />
                  <Icon
                    icon="material-symbols:grid-view-rounded"
                    color="#10BAAC"
                    height="24"
                  />
                </span>
              </div>
            </div>
            <div className="course-management-content">
              <div className="search-bar">
                <Search
                  placeholder="Search..."
                  style={{ width: 200 }}
                  onChange={handlesearchChange}
                />{" "}
              </div>
            </div>
            <div className="courses-tab">
              <HeaderTabsAndNevbar
                showTabsOnly={true}
                tabData={tabData}
                className="tabs-"
              />
            </div>
          </div>
        </>
      </div>
    </div>
  );
};

export default QuizDashBoard;
