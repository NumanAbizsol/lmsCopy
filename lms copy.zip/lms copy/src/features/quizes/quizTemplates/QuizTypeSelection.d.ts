export type QuizTypeProps = {
}