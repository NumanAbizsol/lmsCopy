import React, { useState, FormEvent, useRef } from "react";
import ReactQuill from "react-quill";
import CustomButton from "../../../components/shared/button/Button";
import uploadImgIcon from "../../../assets/images/upload.svg";
import { Icon } from "@iconify/react";
import ImageCropper from "../../../components/shared/ImageCropper/ImageCrop";
import { Modal } from "antd";
import { toast } from "react-toastify";
import { useAppDispatch } from "../../../hooks/useTypedSelector";
import { createCourse } from "../../../redux/Slices/CoursesSlice";

import {
  validateTitle,
  validateTagline,
  validateURL,
  validateDescription,
  validateThumbnail,
} from "../../../components/shared/formValidations/validation";

import CustomInput from "../../../components/inputs/input/Input";
import { Navigate, useNavigate } from "react-router-dom";

const Course = ({ setCourses, setActiveTab, setSelectedTab }: any) => {
  const [course, setCourse] = useState<any>({
    title: "",
    tagLine: "",
    url: "",
    description: "",
    thumbnail: "",
  });
  const [cropedImg, setCropedimg] = useState("");
  const [ImgCropModalOpen, setImgCropModalOpen] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [error, setError] = useState<any>({
    title: "",
    tagLine: "",
    url: "",
    description: "",
    thumbnail: "",
  });

  const navigate = useNavigate();
  const fileInputRef = useRef<any>(null);
  const dispatch = useAppDispatch();
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files && e.target.files[0];
    if (file) {
      // Checking file size
      if (file.size > 2 * 1024 * 1024) {
        console.error("File size exceeds 2MB limit");
        return;
      }
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setCourse((prevCourse: any) => ({ ...prevCourse, thumbnail: result }));
        setError((state: any) => ({ ...state, thumbnail: "" }));
      };
      reader.readAsDataURL(file);
    }
    setImgCropModalOpen(true);
  };

  const handleDescriptionChange = (value: string) => {
    setCourse((prevCourse: any) => ({ ...prevCourse, description: value }));
    setError((state: any) => ({ ...state, description: "" }));
  };

  const handleFormSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const newError = {
      title: validateTitle(course?.title) ?? "",
      tagLine: validateTagline(course?.tagLine) ?? "",
      url: validateURL(course?.url) ?? "",
      description: validateDescription(course?.description) ?? "",
      thumbnail: validateThumbnail(course?.thumbnail) ?? "",
    };
    setError(newError);
    if (
      !newError.title &&
      !newError.tagLine &&
      !newError.url &&
      !newError.description &&
      !newError.thumbnail
    ) {
      setCourses(course);
      dispatch(createCourse(course));
      setSelectedTab(1);
      // navigate("/create-course");
    } else {
      toast.error("Please enter valid field data", {
        position: toast.POSITION.TOP_RIGHT,
      });
    }
  };
  const handleCancel = () => {
    setCourse({
      title: "",
      tagLine: "",
      url: "",
      description: "",
      thumbnail: "",
    });
  };
  return (
    <div className="main-wrapper">
      <div className="course-details-container">
        <h2 className="main-heading"> Quiz Creation</h2>
        <form onSubmit={handleFormSubmit} style={{ width: "100%" }}>
          <div className="input-details">
            <div className="m_t_20">
              <label className="input-label">Title:</label>
              <br />
              <CustomInput
                customClass="input-fild"
                type="text"
                placeholder="Text"
                value={course?.title}
                onChange={(e: any) => {
                  setCourse((prevCourse: any) => ({
                    ...prevCourse,
                    title: e.target.value,
                  }));
                  setError((state: any) => ({ ...state, title: "" }));
                }}
              />
              <div className="error-message">
                {error.title ? error.title : " "}
              </div>
            </div>
            <div className="m_t_20">
              <label className="input-label">Quiz Tagline</label>
              <br />
              <CustomInput
                customClass="input-fild"
                type="text"
                placeholder="Tagline"
                value={course?.tagLine}
                onChange={(e: any) => {
                  setCourse((prevCourse: any) => ({
                    ...prevCourse,
                    tagLine: e.target.value,
                  }));
                  setError((state: any) => ({ ...state, tagLine: "" }));
                }}
              />
              <div className="error-message">
                {error.tagLine ? error.tagLine : " "}
              </div>
            </div>
            <div className="m_t_20">
              <label className="input-label">Quiz URL</label>
              <br />
              <CustomInput
                customClass="input-fild"
                type="text"
                placeholder="pespsi.urqa.com/LMS/Courses/Course name"
                value={course?.url}
                onChange={(e: any) => {
                  setCourse((prevCourse: any) => ({
                    ...prevCourse,
                    url: e.target.value,
                  }));
                  setError((state: any) => ({ ...state, url: "" }));
                }}
              />
              <div className="error-message">{error.url ? error.url : " "}</div>
            </div>
            <div className="textarea-wraper">
              <label className="input-label">Description:</label>
              <div style={{ height: "auto" }} className="custom-quill">
                <ReactQuill
                  theme="snow"
                  value={course?.description}
                  onChange={handleDescriptionChange}
                  style={{ border: "none", width: "100%", background: "none" }}
                />
              </div>
              <div className="error-message">
                {error.description ? error.description : " "}
              </div>
            </div>
            <label className="input-label">Thumbnail</label>
            <div className="image-container">
              {cropedImg ? (
                <>
                  <label
                    className="image-upload-label"
                    htmlFor="thumbnailInput"
                  >
                    <div
                      className="cropped-image"
                      onMouseEnter={() => {
                        setIsHovered(true);
                      }}
                      onMouseLeave={() => setIsHovered(false)}
                    >
                      <img
                        src={cropedImg}
                        style={{ opacity: isHovered ? "50%" : "100%" }}
                        alt="not found"
                      />
                      {isHovered && (
                        <div className="pencil">
                          <Icon icon="mdi:pencil-box" height="24" />
                        </div>
                      )}
                    </div>
                  </label>
                  <input
                    type="file"
                    ref={fileInputRef}
                    accept="image/*"
                    id="thumbnailInput"
                    className="course-thumbnail"
                    onChange={handleFileChange}
                    style={{ display: "none" }}
                  />
                </>
              ) : (
                <>
                  <label
                    className="course-thumbnail"
                    htmlFor="thumbnailInput"
                    style={{ textAlign: "center" }}
                  >
                    <span>
                      <img src={uploadImgIcon} alt="" />
                    </span>
                    {course?.thumbnail
                      ? "Change Thumbnail"
                      : "Upload Thumbnail PNG"}
                  </label>
                  <input
                    type="file"
                    ref={fileInputRef}
                    accept="image/*"
                    id="thumbnailInput"
                    className="course-thumbnail"
                    onChange={handleFileChange}
                    style={{ display: "none" }}
                  />
                </>
              )}
              <div className="error-message">
                {error.thumbnail ? error.thumbnail : " "}
              </div>
            </div>

            <Modal
              title="Crop Image"
              open={ImgCropModalOpen}
              onCancel={() => setImgCropModalOpen(false)}
              footer={null}
            >
              <ImageCropper
                setCropedimg={setCropedimg}
                images={course?.thumbnail}
              />
              <CustomButton
                variant="primary"
                onClick={() => {
                  setImgCropModalOpen(false);
                }}
                customStyle={{ marginTop: "15px" }}
              >
                {" "}
                Crop & Save
              </CustomButton>
            </Modal>
          </div>
          <div className="btns">
            <CustomButton
              variant="secondary"
              customStyle={{}}
              childClasses="string"
              className="cancel-btn"
              onClick={handleCancel}
            >
              Cancel
            </CustomButton>
            <CustomButton
              variant="primary"
              type="submit"
              customStyle={{}}
              childClasses="string"
              className="save-btn"
            >
              Save
            </CustomButton>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Course;
