import React, { useEffect, useState } from "react";
import { QuizTypeProps } from "./QuizTypeSelection.d";
import PracticeQuiz from "../../../assets/images/Frame.svg";
import GradedQuiz from "../../../assets/images/quiztype.svg";
import "./QuizTypeSelection.scss";
import { useNavigate } from "react-router-dom";
import CustomButton from "../../../components/shared/button/Button";

const QuizTypeSelection: React.FC<QuizTypeProps> = () => {
  const[selecedType,setSelectedType]=useState('')
  const navigate = useNavigate();
  return (
    <div className="quiz-type-selection">
      <div className="quiz-content-main-wraper">
        <div className="quiz-content-container">
          <h2>First, let's find out what type of course you're making.</h2>
          <div className="quiz-types-container">
            <div className="quiz-card" style={selecedType==='practiceQuiz'?{border:'2px solid #10baac'}:{borderColor:'#EBEAED'}} onClick={()=>setSelectedType('practiceQuiz')}>
              <div className="card-content" >
                <h3>Practice Quiz</h3>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore{" "}
                </p>
              </div>
              <div className="card-img-container">
                <img src={PracticeQuiz} alt="" />
              </div>
            </div>
            <div className="quiz-card" style={selecedType==='gradedQuiz'?{borderColor:'#10baac'}:{border:'2px solid #EBEAED'}} onClick={()=>setSelectedType('gradedQuiz')}>
              {" "}
              <div className="card-content" >
                <h3>Graded Quiz</h3>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore{" "}
                </p>
              </div>
              <div className="card-img-container">
                <img src={GradedQuiz} alt="" />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="continue-btn-wraper">
        <CustomButton
          className="continue-button"
          variant="primary"
          customStyle={
            {
              /* your custom styles here */
            }
          }
          childClasses=""
          onClick={() => {
            navigate('/create-quiz')
            // setSetps(steps + 1);
          }}
        >
          Continue
        </CustomButton>
      </div>
    </div>
  );
};

export default QuizTypeSelection;
