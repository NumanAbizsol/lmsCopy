import React, { useEffect, useState } from "react";
import { ReactComponent as QuizIcon } from "../../../assets/images/Icon.svg";
import { getQuizzes } from "../../../redux/Slices/QuizsesSlice";
import { useNavigate } from "react-router-dom";
import { Pagination } from "antd";
import {
  useAppDispatch,
  useAppSelector,
} from "../../../hooks/useTypedSelector";
import Card from "../../../components/shared/card/Card";
import usePermission from "../../../PermissionHook";
const ListingPage = () => {
  const dispatch = useAppDispatch();
  const [currentpage, setCurrentPage] = useState<number>(1);
  const pagesize: number = 6;
  const startIndex = (currentpage - 1) * pagesize;
  const endIndex = startIndex + pagesize;
  const [quiz, setQuiz] = useState<any>({});
  const {hasRole,hasPermissionForAction}=usePermission();

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        await dispatch(getQuizzes());
      } catch (error) { }
    };
    fetchCourses();
  }, [dispatch]);

  const quizDAta = useAppSelector((state) => state?.quizzes?.quiz);
  useEffect(() => {
    setQuiz(quizDAta);
  }, [quizDAta]);
  //   <Menu
  //     onClick={({ key }) => handleSortingChange(key)}
  //     className="sorting-menu-card"
  //   >
  //     {filtervalue.map((option) => (
  //       <Menu.Item key={option.key}>
  //         <Checkbox checked={sortingOption === option.key}>
  //           {option.label}
  //         </Checkbox>
  //       </Menu.Item>
  //     ))}{" "}
  //   </Menu>
  // );
  const navigate = useNavigate();

  return (
    <>
      <h1>My Quizzes</h1>
      <div className="courses-cards">
        {quiz?.length && quiz?.length > 0 ? (
          <>
            {quiz?.map((quiz: any, index: any) => (
              <div onClick={() => { if (hasRole("student") && hasPermissionForAction("EDIT_QUIZ")) { navigate(`${quiz.id}`) } }} >
                <Card
                  title={quiz.title}
                  imageSrc={quiz.thumbnail}
                  key={index}
                  enrolledCount={32}
                  questionCount={3}
                  review={2}
                  style={{ width: "328px", height: "auto" }}
                />
                {hasRole("student") && hasPermissionForAction("EDIT_QUIZ")? null:"No Permissions to edit!"}
              </div>
            ))}
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                marginTop: "20px",
                width: "100%",
              }}
            >
              <Pagination
                style={{ display: "flex", justifyContent: "center" }}
                total={quiz?.length}
                current={currentpage}
                pageSize={pagesize}
                onChange={(page) => setCurrentPage(page)}
              />
            </div>
          </>
        ) : (
          <div className="mrgn">
            <div
              style={{ marginTop: "20px" }}
              className="d-flex justify-center"
            >
              <div className="quiz-hero-section">
                <div className="d-flex justify-center">
                  <QuizIcon />
                </div>
                <div className="text-center create-quiz-card-content">
                  <h2>No Quiz Created Yet</h2>
                  <span className="p1 light-text">
                    Write something here that’ll make your reader excited! You
                    can write anything in here. Get started.
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
};
export default ListingPage;
