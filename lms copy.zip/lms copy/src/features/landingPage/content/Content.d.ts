export type CourseData = {
    title: string;
    category: string;
    price: string;
    lessons: string;
    rating: number;
  };