export type CourseData = {
    title: string;
    description: string;
  }