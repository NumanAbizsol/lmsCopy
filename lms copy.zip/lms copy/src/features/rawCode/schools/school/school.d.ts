export type FormData = {
  yourIdentity: string;
  currentlyWorkingPeople: string;
  industryName: string;
  isAlreadyHaveBusiness: string;
  isAlreadyHavemail: string;
}