import React from 'react'
import Sidebar from '../sidebar/Sidebar'
import SchoolSetup from '../schoolCreationForm/SchoolCreationForm'

import SelectYourSchoolTemplete from "../selectYourSchoolTemplete/SelectYourSchoolTemplete"

const SchoolDashboard = () => {
  return (
    <>
    <Sidebar/>
    {/* <SchoolSetup/> */}
    {/* <SelectYourSchoolTemplete/> */}
    
   
    
    </>
  )
}

export default SchoolDashboard