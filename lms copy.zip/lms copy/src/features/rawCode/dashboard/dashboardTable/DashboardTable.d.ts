
export type DashboardTableProps = {};