export type MainContentProps ={
    isExpanded: boolean;
    selectedItem: string;
  }