
export type CreatedCoursesProps = {
    // courseTitle: string;
    // courseImage: string; // Assuming you pass the image source as a string
    // courseDescription: string;
    onAddSectionClick: () => void;
    courses: CourseData[];
    img:string;
  }