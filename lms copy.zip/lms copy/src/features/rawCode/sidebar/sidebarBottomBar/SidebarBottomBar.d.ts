export type SidebarBottomProps = {
    isExpanded: boolean;
    onMouseEnter: () => void;
    onMouseLeave: () => void;
}