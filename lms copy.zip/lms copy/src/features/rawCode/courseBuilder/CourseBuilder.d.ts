
export type CustomButtonProps = {
    children: React.ReactNode;
    onClick: () => void;
  }
  