import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getQuizzes } from '../../../redux/Slices/QuizsesSlice';
// import { fetchData } from './dataActions';
// import QuizsesSlice from '../../../redux/Slices/QuizsesSlice';

const TimePoint = () => {
  const quizze = useSelector((state :any) => state?.quizzes);
  const dispatch = useDispatch();
  const firstQuiz = quizze.quizzes[0]; // Accessing the first item in the array
  const timeInMin = firstQuiz.timeInMin;
  console.log(timeInMin, "quizezzzzzz"); 
  // useEffect(() => {
  //   dispatch(getQuizzes());
  // }, [dispatch])
  return (
    <>
      <div
        style={{
          width: "100%",
          backgroundColor: "white",
          height: "125px",
          borderRadius: "6px",
          marginBottom: "10px",
          marginTop: "10px",
          display: "flex",
          flexDirection: "column",
          alignItems: "flex-end",
          border: "1px solid #F7F7F7",
        }}
      >
        <div style={{ display: "flex", marginTop: "6px", marginLeft: "6px" }}>
          <span style={{ paddingRight: "20px"  ,fontSize:"20px"}}>Set Time:</span>{" "}
          <div
            style={{
              backgroundColor: "#F7F7F7",
              height: "25px",
              borderRadius: "17px",
              marginRight:"61px",
              paddingRight: "8px",
              display: "flex",
            }}
          >
            <div
              style={{
                paddingRight: "15px",
                paddingLeft: "10px",
                backgroundColor: "white",
                marginTop: "3px",
                marginLeft: "7px",
                borderRadius: "15px",
                height: "18px",
              }}
            >
              Sec
            </div>
            <span
              style={{
                marginTop: "5px",
                height: "16px",
                paddingLeft: "11px",
                backgroundColor: "white",
                marginLeft: "6px",
                borderRadius: "19px",
                width: "33px",
              }}
            >
              {timeInMin}
            </span>
            
          </div>
          <span style={{ paddingRight: "20px" ,fontSize:"20px" }}>Set Point:</span>{" "}
          <div
            style={{
              backgroundColor: "#F7F7F7",
              height: "25px",
              borderRadius: "17px",
              paddingRight: "8px",
              display: "flex",
              marginRight:"10px"
            }}
          >
            <div
              style={{
                paddingRight: "15px",
                paddingLeft: "10px",
                backgroundColor: "white",
                marginTop: "3px",
                marginLeft: "7px",
                borderRadius: "15px",
                height: "16px",
              }}
            >
              Pt
            </div>
            <span
              style={{
                marginTop: "5px",
                height: "16px",
                paddingLeft: "11px",
                backgroundColor: "white",
                marginLeft: "6px",
                borderRadius: "19px",
                width: "33px",
              }}
            >
              30
            </span>
          </div>
        </div>
        <div></div>
      </div>
    </>
  );
};
export default TimePoint;
