export type Question = {
    text: string;
  }