export type Choice = {
    text: string;
  }