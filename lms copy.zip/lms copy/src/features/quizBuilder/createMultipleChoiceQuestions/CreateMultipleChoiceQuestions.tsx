import React, { useEffect, useState, useRef } from "react";
import CustomButton from "../../../components/shared/button/Button";
import CustomSelect from "../../../components/inputs/select/Select";
import { ReactComponent as CrossIcon } from "../../../assets/images/cross-white.svg";
import QuillEditor from "react-quill";
import CustomInput from "../../../components/inputs/input/Input";

const CreateMultipleChoiceQuestions = ({
  index,
  question,
  setQuestions,
}: any) => {
  const [multiSelect, setMultiSelect] = useState(false);
  const [showEditor, setShowEditor] = useState(false);
  const forceUpdate = useRef();

  useEffect(() => {
    setQuestions((prevQuestions: any) => {
      const updatedQuestions = prevQuestions.map((q: any, qIndex: number) => {
        if (qIndex === index) {
          const updatedOptions = q.option.map((o: any) => {
            return { ...o, correct: o.selected };
          });

          return {
            ...q,
            selectType: multiSelect ? "multi-select" : "single-select",
            option: updatedOptions,
          };
        } else {
          return q;
        }
      });

      return updatedQuestions;
    });
  }, [multiSelect, index]);

  const handleAddOptions = () => {
    setQuestions((prevquestion: any) => {
      const updatedQuestion = { ...prevquestion[index] };

      updatedQuestion.option = [
        ...updatedQuestion.option,
        {
          opt: "",
          correct: false,
          feedbackSinglq: "",
        },
      ];

      const updatedQuestions = [...prevquestion];
      updatedQuestions[index] = updatedQuestion;

      return updatedQuestions;
    });
  };

  const removeItemAtIndex = (i: number) => {
    setQuestions((prevquestion: any) => {
      const updatedQuestion = { ...prevquestion[index] };

      updatedQuestion.option = updatedQuestion.option.filter(
        (_: any, j: number) => i !== j
      );

      const updatedQuestions = [...prevquestion];
      updatedQuestions[index] = updatedQuestion;

      return updatedQuestions;
    });
  };

  const handleButtonClick = () => {
    setShowEditor(!showEditor);
  };

  const questionOptions = [
    {
      label: "Correct",
      value: "correct",
    },
    {
      label: "Incorrect",
      value: "incorrect",
    },
  ];

  return (
    <>
      <div>
        <div>
          <div style={{ margin: "20px 0px" }}>Write Your Statement</div>
          <QuillEditor
            value={question.description}
            onChange={(value: string) => {
              setQuestions((prevQuestions: any) => {
                const updatedQuestions = prevQuestions.map(
                  (q: any, i: number) => {
                    if (i === index) {
                      return { ...q, description: value };
                    } else {
                      return q;
                    }
                  }
                );
                return updatedQuestions;
              });
            }}
          />
        </div>
        <div style={{ margin: "20px 0px" }}>Options</div>
        <button
          onClick={() => setMultiSelect(false)}
          className={`select-button ${
            !multiSelect && "selected-select-button"
          }`}
        >
          <h4>Single Select</h4>
        </button>
        <button
          onClick={() => setMultiSelect(true)}
          className={`select-button ${multiSelect && "selected-select-button"}`}
        >
          <h4>Multi Select</h4>
        </button>
        <div
          style={{ marginTop: "32px" }}
          className="d-flex flex-column gap-10"
        >
          {Array.isArray(question?.option) &&
            question?.option?.map((opt: any, i: number) => (
              <div style={{ display: "flex", flexDirection: "column" }}>
                <div
                  key={i}
                  className="d-flex gap-5 "
                >
                  <div
                    style={{
                      padding: "10px",
                      backgroundColor: "#10BAAC",
                      color: "white",
                      borderRadius: "4px",
                    }}
                  >
                    <h3 style={{ margin: "0" }}>{i + 1}.</h3>
                  </div>
                  {/* input field statment */}
                  <div
                    style={{
                      flexBasis: "70%",
                      backgroundColor: "#EBEAED",
                      padding: "11px 12px 11px 12px",
                      height: "34px",
                    }}
                  >
                    <h4 style={{ margin: "0" }}>
                      <CustomInput
                        value={opt.opt && opt.opt}
                        onChange={(e: any) => {
                          setQuestions((prevQuestions: any) => {
                            const updatedQuestions = prevQuestions.map(
                              (q: any, qIndex: number) => {
                                if (qIndex === index) {
                                  const updatedOptions = q.option.map(
                                    (o: any, oIndex: number) => {
                                      if (oIndex === i) {
                                        return { ...o, opt: e.target.value };
                                      } else {
                                        return o;
                                      }
                                    }
                                  );
                                  return { ...q, option: updatedOptions };
                                } else {
                                  return q;
                                }
                              }
                            );
                            return updatedQuestions;
                          });
                        }}
                      />
                    </h4>
                  </div>

                  <div style={{ flexBasis: "20%" }}>
                    <CustomSelect
                      options={questionOptions}
                      handleChange={(e: any) => {
                        setQuestions((prevQuestions: any) => {
                          const updatedQuestions = prevQuestions.map(
                            (q: any, qIndex: number) => {
                              if (qIndex === index) {
                                const updatedOptions = q.option.map(
                                  (o: any, oIndex: number) => {
                                    if (oIndex === i) {
                                      return { ...o, correct: e === "correct" };
                                    } else {
                                      if (q.selectType === "single-select") {
                                        return { ...o, correct: false };
                                      } else {
                                        return o;
                                      }
                                    }
                                  }
                                );
                                return { ...q, option: updatedOptions };
                              } else {
                                return q;
                              }
                            }
                          );
                          return updatedQuestions;
                        });
                      }}
                      selected={opt.correct === true ? "correct" : "incorrect"}
                      variant={"single-select"}
                    />
                  </div>
                  <CustomButton
                    onClick={() => removeItemAtIndex(i)}
                    customStyle={{
                      padding: "10px",
                      backgroundColor: "#F04B61",
                      borderRadius: "6px",
                    }}
                    variant="default"
                    className="d-flex align-center"
                  >
                    <CrossIcon />
                  </CustomButton>
                </div>
                <div>
                  <CustomInput
                    customStyles={{
                      maxWidth:'200px',
                      backgroundColor: "#FEF6E5",
                      color: "#D97706",
                      display: "inline-flex",
                      padding: "8px 12px",
                      alignItems: "center",
                      marginBottom: "20px",
                      borderRadius: "4px",
                      border: "1px solid  #EBEAED",
                      marginLeft:'40px'
                    }}
                    placeholder="feedback"
                    value={opt.feedbackSinglq && opt?.feedbackSinglq}
                    onChange={(e: any) => {
                      setQuestions((prevQuestions: any) => {
                        const updatedQuestions = prevQuestions.map(
                          (q: any, qIndex: number) => {
                            if (qIndex === index) {
                              const updatedOptions = q.option.map(
                                (o: any, oIndex: number) => {
                                  if (oIndex === i) {
                                    return {
                                      ...o,
                                      feedbackSinglq: e.target.value,
                                    };
                                  } else {
                                    return o;
                                  }
                                }
                              );
                              return { ...q, option: updatedOptions };
                            } else {
                              return q;
                            }
                          }
                        );
                        return updatedQuestions;
                      });
                    }}
                  />
                </div>
              </div>
            ))}
          <CustomButton
            onClick={handleAddOptions}
            variant="primary"
            className="d-flex align-center gap-10 pointer"
            customStyle={{ margin: "20px 0px", padding: "10px 0px" }}
          >
            + More Options
          </CustomButton>
          <div>
            {question?.feedback?.length < 12 && showEditor === false ? (
              <CustomButton
                onClick={handleButtonClick}
                variant="secondary"
                customStyle={{
                  height: "44px",
                  backgroundColor: "white",
                  border: "2px dashed #10BAAC",
                  borderRadius: "6px",
                  color: "#10BAAC",
                  fontSize: "15px",
                  fontWeight: "40px",
                  width: "-webkit-fill-available",
                }}
              >
                + General Feedback
              </CustomButton>
            ) : null}
            {((question?.feedback && question?.feedback?.length > 11) ||
              showEditor === true) && (
              <QuillEditor
                value={question.feedback}
                onChange={(value: string) => {
                  setQuestions((prevQuestions: any) => {
                    const updatedQuestions = prevQuestions.map(
                      (q: any, i: number) => {
                        if (i === index) {
                          return { ...q, feedback: value };
                        } else {
                          return q;
                        }
                      }
                    );
                    return updatedQuestions;
                  });
                }}
              />
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default CreateMultipleChoiceQuestions;
