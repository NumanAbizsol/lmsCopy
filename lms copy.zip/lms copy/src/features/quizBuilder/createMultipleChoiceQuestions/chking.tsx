
import React, { useEffect, useState, useRef } from "react";
import CustomButton from "../../../components/shared/button/Button";
import CustomSelect from "../../../components/inputs/select/Select";
import { ReactComponent as CrossIcon } from "../../../assets/images/cross-white.svg";
import { ReactComponent as PlusIcon } from "../../../assets/images/plus.svg";
import { Choice } from "./CreateMultipleChoiceQuestions.d";
import QuillEditor from "react-quill";
import{validateDescription} from "../../../components/shared/formValidations/validation"

import TimePoint from "../setTimePoint/TimePoint";
import CustomInput from "../../../components/inputs/input/Input";
import "./createMultipleAnswers.scss"

const CreateMultipleChoiceQuestions = ({
  index,
  question,
  setQuestions,
}: any) => {
  const [multiSelect, setMultiSelect] = useState(false);
  const [showEditor, setShowEditor] = useState(false);
  const forceUpdate = useRef();

  useEffect(() => {
    setQuestions((prequestion: any) => {
      const preqst = [...prequestion];
      const selectedqst = preqst[index];
      if (!multiSelect) {
        const firstCorrectIndex = selectedqst.option.findIndex(
          (opt: any) => opt.correct
        );

        if (firstCorrectIndex !== -1) {
          selectedqst.option[firstCorrectIndex].correct = false;
        }
      }
      selectedqst.selectType =
        multiSelect === true ? "multi-select" : "single-select";
      preqst[index] = selectedqst;
      return [...preqst];
    });
  }, [multiSelect, index]);

  const handleAddOptions = () => {
    ///jugarr
    // const opId=question.length+1;
    // const opNewId={id:opId};
    // //
    setQuestions((prequestion: any) => {
      const preqst = [...prequestion];
      const selectedqst = preqst[index];
      selectedqst.option = [
        ...selectedqst.option,
        {
          opt: "",
          correct: false,
          feedbackSinglq:""
        },
      ];
      preqst[index] = selectedqst;
      return [...preqst];
      // return [...preqst,opNewId];
    });
  };
  const removeItemAtIndex = (i: number) => {
    setQuestions((prevOptions: any) => {
      let optDelete = [...prevOptions];
      console.log(i,optDelete)
      optDelete[index].option = optDelete[index].option.filter(
        (_: any, j: number) => i !== j
      );
      return optDelete;
    });
  };

  useEffect(()=>{
    console.log(question)
  },[question])
  /////show editor/////
  const handleButtonClick = () => {
    setShowEditor(!showEditor);
  };

  const questionOptions = [
    {
      label: "Correct",
      value: "correct",
    },
    {
      label: "Incorrect",
      value: "incorrect",
    },
  ];

  return (
    <>
      <div>
        <div >
          {/* <TimePoint/> */}
          <label>Write Your Statement Here</label>
          <QuillEditor
            value={question.description} // Pass the current description value
            onChange={(value: string) => {
              setQuestions((prequestion: any) => {
                const preqst = [...prequestion];
                const selectedqst = preqst[index];
                selectedqst.description = value;
                preqst[index] = selectedqst;
                return [...preqst];
              });
            }}
          />
          {/* <Input
          type="text"
          onChange={(e: any) => {
            setQuestions((prequestion: any) => {
              const preqst = [...prequestion];
              const selectedqst = preqst[index];
              selectedqst.description = e.target.value;
              preqst[index] = selectedqst;
              return [...preqst];
            });
          }}
        /> */}
        </div>
        <button
          onClick={() => setMultiSelect(false)}
          className={`select-button ${
            !multiSelect && "selected-select-button"
          }`}
        >
          <h4>Single Select</h4>
        </button>
        <button
          onClick={() => setMultiSelect(true)}
          className={`select-button ${multiSelect && "selected-select-button"}`}
        >
          <h4>Multi Select</h4>
        </button>
        <div
          style={{ marginTop: "32px" }}
          className="d-flex flex-column "//here i am removing gap=10px
        
        >
          {Array.isArray(question?.option) &&
            question?.option?.map((opt:any, i: number) => {
              return (
                <>
                <div key={i} className="d-flex gap-5">
                  <div
                    style={{
                      padding: "10px",
                      backgroundColor: "#10BAAC",
                      color: "white",
                      borderRadius: "4px",
                    }}
                  >
                    <h3 style={{ margin: "0" }}>{i + 1}.</h3>
                  </div>
                  <div
                    style={{
                      flexBasis: "70%",
                      backgroundColor: "#EBEAED",
                      padding: "11px 12px 11px 12px",
                      height:"34px"
                    }}
                  >
                    <h4 style={{ margin: "0"}}>
                      <CustomInput
                        value={opt.opt && opt?.opt}
                        onChange={(e: any) => {
                          setQuestions((prevQuiz: any) => {
                            const preq = [...prevQuiz];
                            preq[index].option[i].opt = e.target.value;
                            return preq;
                          });
                        }}
                      />

                    </h4>
         
                 
                  </div>
                  
                  <div style={{ flexBasis: "20%" }}>
                    <CustomSelect
                      options={questionOptions}
                      handleChange={(e: any) => {
                        setQuestions((prevQuestions: any) => {
                          const preq = [...prevQuestions];
                          preq[index].option[i].correct = e === "correct";
                          if (!multiSelect && e === "correct") {
                            preq[index].option.forEach((o: any, j: number) => {
                              if (j !== i) {
                                o.correct = false;
                              }
                            });
                          }
                          return preq;
                        });
                      }}
                      selected={
                        opt.correct === true
                          ? "correct"
                          : "incorrect"
                      }
                      variant={"single-select"}
                    />
                  </div>
                  
                  <CustomButton
                    onClick={() => removeItemAtIndex(i)}
                    customStyle={{
                      padding: "10px",
                      backgroundColor: "#F04B61",
                      borderRadius: "6px",
                    }}
                    variant="default"
                    className="d-flex align-center"
                  >
                    <CrossIcon />
                    
                  </CustomButton>
            
              
                </div>
    <h4 style={{  width:"150px" ,marginLeft:"41px"}}>
    <CustomInput
    customStyles={{backgroundColor:'#FEF6E5',color:"#D97706" ,display: "inline-flex"
     ,padding: "8px 12px",alignItems: "center",gap: "10px",marginBottom:"20px",
    borderRadius: "4px",
    border: '1px solid  #EBEAED',
  
  
  }}
  
    placeholder="Add Feedback"
      value={opt.feedbackSinglq && opt?.feedbackSinglq}
      onChange={(e: any) => {
        setQuestions((prevQuiz: any) => {
          const preq = [...prevQuiz];
          preq[index].option[i].feedbackSinglq = e.target.value;
          return preq;
        });
      }}
    />
  </h4>
  </> 
                
              );
            })}
          <CustomButton
            onClick={handleAddOptions}
            variant="primary"
            className="d-flex align-center gap-10 pointer"
          >
            {/* <PlusIcon
             customStyles={{paddingLeft:"300px"}}
            
            />{" "} */}
            <span
              style={{ fontSize: "20px", fontWeight: "500", color: "#08496D" ,paddingLeft:"300px" }}
            >
             + More Options
            </span>
          </CustomButton>
          <div   style={{border:"2px dashed #10BAAC" ,borderRadius:"8px" ,marginTop: "10px"}}>
         

          <button className="generalFeedbackDashed"
            onClick={handleButtonClick}
            style={{
              height: "44px",
              backgroundColor: "white",
              paddingLeft:"300px",
              borderRadius: "6px",
              border: "2px solid white",
              color: "#10BAAC",
              fontSize: "15px",
              fontWeight: "40px",
              alignItems: "center",
              textAlign:"center",
            }}
          >
            + General Feedback
          </button>
          {showEditor && (
            
            <QuillEditor
              value={question.feedback}
              onChange={(value: string) => {
                setQuestions((prequestion: any) => {
                  const preqst = [...prequestion];
                  const selectedqst = preqst[index];
                  selectedqst.feedback = value;
                  preqst[index] = selectedqst;
                  return [...preqst];
                });
              }}
            />
         )}
          </div>
        </div>
      </div>
    </>
  );
};

export default CreateMultipleChoiceQuestions;
