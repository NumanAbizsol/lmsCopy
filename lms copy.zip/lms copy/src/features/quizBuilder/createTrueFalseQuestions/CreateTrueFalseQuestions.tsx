import CustomInput from "../../../components/inputs/input/Input";
export default function CreateTrueFalseQuestions({
  index,
  question,
  setQuestions,
}: any) {
  return (
    <div>
      <div style={{ margin: "20px 0px" }}>Write Your Statement</div>
      <CustomInput
        customStyles={{ height: "88px" }}
        value={question.description}
        onChange={(e) => {
          setQuestions((prevQuestions: any) => {
            const newQuestions = prevQuestions.map((q: any, idx: number) =>
              idx === index ? { ...q, description: e.target.value } : q
            );
            return newQuestions;
          });
        }}
      />
      <div className="d-flex align-center gap-10" style={{ margin: "20px 0px" }} >
        <h4>Set As</h4>
        <button
          style={{ margin: "0px", width: "56px" }}
          onClick={() => {
            setQuestions((prevQuestions: any) => {
              const newQuestions = prevQuestions.map((q: any, idx: number) =>
                idx === index ? { ...q, answer: true } : q
              );
              return newQuestions;
            });
          }}
          className={`select-button ${
            question.answer ? "selected-select-button" : ""
          }`}
        >
          <h4>True</h4>
        </button>
        <button
          style={{ margin: "0px", width: "56px" }}
          onClick={() => {
            setQuestions((prevQuestions: any) => {
              const newQuestions = prevQuestions.map((q: any, idx: number) =>
                idx === index ? { ...q, answer: false } : q
              );
              return newQuestions;
            });
          }}
          className={`select-button ${
            !question.answer ? "selected-select-button" : ""
          }`}
        >
          <h4>False</h4>
        </button>
      </div>
    </div>
  );
}
