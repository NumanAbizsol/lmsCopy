import React, { useEffect, useState } from "react";
import { ReactComponent as ViewIcon } from "../../../assets/images/open-modal.svg";
import ModalWrapper from "../../../modals/ModalWraper";
import Input from "../../../components/inputs/input/Input";
import { FillBlankGeneratorProps } from "./FillBlankGenerator.d";
import "./FillBlankGenerator.scss";
import CustomButton from "../../../components/shared/button/Button";

const FillBlankGenerator = ({ index, question, setQuestions }: any) => {
  const [selectedIndexes, setSelectedIndexes] = useState<number[]>([]);
  const [openModal, setOpenModal] = useState(false);
  const [chunks, createChunks] = useState(false);

  useEffect(() => {
    console.log("questionsquestions", question);
  }, [question]);

  return (
    <div className="d-flex flex-column gap-10">
      <ModalWrapper
        title="Your Modal Title"
        visible={openModal}
        onCancel={() => setOpenModal(false)}
        onOk={() => {}}
        size="large"
      >
        <div className="d-flex flex-column gap-10">
          <div className="d-flex gap-5 align-end">
            {selectedIndexes.length > 0 && (
              <div>
                <h4>Selected Chunks:</h4>
                {selectedIndexes.map((index) => (
                  <span key={index}>Chunk {index}</span>
                ))}
              </div>
            )}
          </div>
        </div>
      </ModalWrapper>
      <div style={{ margin: "20px 0px" }}>Write Your Statement</div>
      <Input
        value={question.description}
        onChange={(e) => {
          setQuestions((prevQuestions: any) => {
            const newQuestions = prevQuestions.map((q: any, idx: number) =>
              idx === index ? { ...q, description: e.target.value } : q
            );
            return newQuestions;
          });
        }}
        customStyles={{ height: "88px" }}
      />
      <CustomButton
        onClick={() => {
          createChunks(true);
        }}
        variant="primary"
        customStyle={{ margin: "0px", width: "286px" }}
        className={`select-button selected-select-button`}
      >
        <h4>Generate Fill In The Blank Chunks</h4>
      </CustomButton>
      {question?.description && chunks && (
        <>
          <div className="select-blanks-container">
            <div className="d-flex align-center gap-10">
              <h4>Click to Add </h4>
              <div className="d-flex">
                {question?.description
                  .split(" ")
                  .map((word: string, inn: number) => {
                    const isSelected = question?.selectedIndex?.includes(inn);
                    return (
                      <span
                        key={inn}
                        onClick={() => {
                          setQuestions((prevQuestions: any) => {
                            const newQuestions = [...prevQuestions];
                            const questionToUpdate = newQuestions[index];
                            const updatedSelectedIndex = isSelected
                              ? questionToUpdate.selectedIndex.filter((i: any) => i !== inn)
                              : [...questionToUpdate.selectedIndex, inn];
                            const updatedQuestion = {
                              ...questionToUpdate,
                              selectedIndex: updatedSelectedIndex,
                            };
                            newQuestions[index] = updatedQuestion;
                            return newQuestions;
                          });

                          setSelectedIndexes((prevIndexes) =>
                            isSelected
                              ? prevIndexes.filter((i) => i !== inn)
                              : [...prevIndexes, inn]
                          );
                        }}
                        className={`token token-text text-center ${
                          isSelected && "selected-token"
                        }`}
                      >
                        {isSelected ? " ______ " : word}
                      </span>
                    );
                  })}
              </div>
              <div className="d-flex justify-end">
                <ViewIcon onClick={() => setOpenModal(true)} />
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
export default FillBlankGenerator;
