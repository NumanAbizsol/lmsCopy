// Questions.jsx

import React, { useEffect, useState } from "react";
import CustomButton from "../../../components/shared/button/Button";
import { useDrag, useDrop, DndProvider } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
import imglist from "../../../assets/images/Frame 1686557237.png";

import imgswap from "../../../assets/images/swap.png";
import {
  useAppDispatch,
  useAppSelector,
} from "../../../hooks/useTypedSelector";
import imagempty from "../quizBuilderQuestion/imagequestion/Frame 1686557282.png";
import {
  createQuizQuestion,
  getQuizQuestions,
} from "../../../redux/Slices/QuizsesSlice";
import { Icon } from "@iconify/react";
import CreateQuestions from "../createQuestions/CreateQuestions"; // Import CreateQuestions

// my code
import "./question.scss";
import OverlayConfirmationModal from "../../organizations/OrgProduct/OverlayConfirmationModal";

import { ExclamationCircleOutlined, DeleteOutlined } from "@ant-design/icons";
import { Button } from "antd";

export default function Questions() {
  const [questions, setQuestions] = useState<any[]>([]);
  const [selectedQuestion, setSelectedQuestion] = useState<any>(0);

  const [isModalVisible, setIsModalVisible] = useState(false);

  const handleDeleteConfirm = () => {
    setIsModalVisible(true);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
  };

  // handle delete sobia
  const handleDelete = (index: any) => {
    console.log("index in handledelete", index);
    setTimeout(() => {
      if (selectedQuestion === questions.length - 1) {
        setSelectedQuestion((pre: any) => pre - 1);
      }
    }, 1);
    const updatedQuestions = questions.filter((_, id) => id !== index);
    setQuestions(updatedQuestions);
    setSelectedQuestion(null);
    setIsModalVisible(false);
  };

  const addQuestion = () => {
    const newQuestion = {
      id: questions.length + 1,
      type: "",
    };
    setQuestions((prevQuestions) => [...prevQuestions, newQuestion]);
    setSelectedQuestion(questions.length);
  };

  const DraggableItem = ({
    id,
    index,
    isSelected,
    setSelectedQuestion,
    handleDelete,
    type,
  }: any) => {
    const [, drag] = useDrag({
      type: "ITEM",
      item: { id, index },
    });

    return (
      <div ref={drag}>
        <div
          style={{
            marginBottom: "30px",
            color: isSelected ? "#fff" : "",
            backgroundColor: isSelected ? "#10baac" : "",
            marginTop: "8px",
            // border: "1px solid black",
            borderRadius: "8px",
            display: "flex",
            alignItems: "center",
            padding: "5px",
          }}
          onClick={() => {
            setSelectedQuestion(index);
          }}
        >
          <Icon style={{ fontSize: "35px" }} icon={"ph:dots-six-vertical"} />
          <div
            style={{
              fontSize: "22px",
              paddingRight: "10px",
              paddingLeft: "10px",
            }}
          >
            {index + 1}
          </div>
          <img src={imglist} alt="img" style={{ marginRight: "8px" }} />
          <div
            style={{
              paddingLeft: "10px",
              fontWeight: "normal",
              textOverflow: "ellipsis",
              overflow: "hidden",
              width: "30%",
            }}
          >
            {type ? type : "Choose Type"}
          </div>
          {/* <CustomButton
          // yhn pr confirm call krana haiii
            // onClick={() => handleDelete(index)}
            onClick={handleDeleteConfirm}
            // icon={<DeleteOutlined />}
            variant="secondary"
            type="button"
            customStyle={
              isSelected
                ? {
                    marginLeft: "10px",
                    borderRadius: "4px",
                    color: "white",
                    backgroundColor: "red",
                    border: "1px solid 10BAAC0D",
                    boxShadow: "0px 6px 20px rgba(0, 0, 10, 0.2)",
                  }
                : { visibility: "hidden" }
            }
          >
            Delete
          </CustomButton> */}
          <Button
            icon={<DeleteOutlined />}
            danger
            onClick={handleDeleteConfirm}
            style={{
              ...(isSelected
                ? {
                    marginLeft: "10px",
                    borderRadius: "4px",
                    border: "1px solid #10BAAC0D",
                    boxShadow: "0px 6px 20px rgba(0, 0, 10, 0.2)",
                  }
                : { visibility: "hidden" }),
            }}
          />

          <OverlayConfirmationModal
            heading={"Delete"}
            description={"Are you sure you want to delete?"}
            visible={isModalVisible}
            onCancel={handleCancel}
            onConfirm={() => handleDelete(index)}
            IconComponent={DeleteOutlined}
            customStyle={{color:"red", fontSize: "100px"}}
          />
        </div>
      </div>
    );
  };

  const [, drop] = useDrop({
    accept: "ITEM",
    hover: (draggedItem: { index: number }) => {
      const { index: draggedIndex } = draggedItem;
      const hoverIndex = questions.findIndex((q) => q.id === selectedQuestion);

      const newQuestions = [...questions];
      const [draggedQuestion] = newQuestions.splice(draggedIndex, 1);
      newQuestions.splice(hoverIndex, 0, draggedQuestion);

      setQuestions(newQuestions);
    },
  });

  const dispatch = useAppDispatch();

  useEffect(() => {
    dispatch(getQuizQuestions());
  }, [dispatch]);

  const { quizQuestions } = useAppSelector((state) => state.quizzes);

  useEffect(() => {
    setQuestions(quizQuestions ?? []);
  }, [quizQuestions]);

  const handleSave = () => {
    dispatch(createQuizQuestion(questions));
  };

  return (
    <div style={{ display: "flex", flexDirection: "row" }}>
      <div className="sidebarBody">
        <div style={{ display: "flex", flexDirection: "column" }}>
          <h4 className="quizquestionBody quizquestionText">
            {/* style={{ display: "flex", justifyContent: "center" }} */}
            Quiz Questions
          </h4>
          <div
            style={{
              gap: "10px",
              marginTop: "15px",
              paddingBottom: "15px",
            }}
            ref={drop}
          >
            {questions?.map((q: any, index) => (
              <DraggableItem
                key={index}
                index={index}
                isSelected={selectedQuestion === index}
                setSelectedQuestion={setSelectedQuestion}
                handleDelete={handleDelete}
                //  onClick={() => handleDelete(index)}
                type={q?.type?.toUpperCase()}
              />
            ))}
          </div>
          <div className="imageStyling">
            {questions.length > 0 ? null : (
              <img
                // className="emptyimageTextBody"
                src={imagempty}
                style={{ width: "150px" }}
                alt="not found"
              />
            )}
          </div>
        </div>

        <CustomButton
          onClick={addQuestion}
          customStyle={{
            height: "44px",
            padding: "10px",
            marginTop: "20px",
            marginBottom: "200px",
            width: "90%",
          }}
          // className="w-100"
          childClasses={"d-flex align-center justify-center gap-5"}
          variant="primary"
          showPlusButton={true}
        >
          New Question
        </CustomButton>
      </div>

      <div style={{ width: "79%" }}>
        <div className="d-flex flex-column gap-10">
          {questions?.map((question: any, index: any) => {
            if (index === selectedQuestion) {
              return (
                <CreateQuestions
                  key={index}
                  index={index}
                  question={question}
                  setQuestions={setQuestions}
                />
              );
            }
          })}
        </div>

        {questions[0] &&
        questions[0]?.type &&
        questions[0]?.type?.length &&
        questions[0]?.type?.length > 0 ? (
          <div
            style={{ marginTop: "32px" }}
            className="d-flex justify-end gap-10"
          >
            <button
              style={{ backgroundColor: "white" }}
              className="reset-button"
            >
              Cancel
            </button>
            <button className="draft-btn">Save As draft</button>
            <button
              className="save-btn"
              onClick={() => {
                handleSave();
              }}
            >
              Save & Publish
            </button>
          </div>
        ) : null}
        <div style={{ display: "flex", gap: "6px", marginTop: "10px" }}></div>
      </div>
    </div>
  );
}
