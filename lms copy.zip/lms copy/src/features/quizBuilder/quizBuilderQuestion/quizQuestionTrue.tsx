import {useState} from "react"
import { useNavigate } from "react-router-dom"

const QuizQuestionTrue=()=>{
    const navgate=useNavigate()
  const handleBack=()=>{
    navgate("/selectType")
  }  

return(<>
<h1>TrueFalse</h1>
<button>save</button>
<button>cancel</button>
<button onClick={handleBack}>back</button>
</>)

}
export default  QuizQuestionTrue