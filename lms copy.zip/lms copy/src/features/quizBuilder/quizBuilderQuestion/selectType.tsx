import { useState } from "react";
import CreateTrueFalseQuestions from "../createTrueFalseQuestions/CreateTrueFalseQuestions";

function SelectType({ question, setQuestions, index }: any) {
  const [selectedType, setSelectedType] = useState("");

  const handleSelect = (newType: string) => {
    setSelectedType(newType);
  };

  return (
    <>
      <select
        onChange={(e) => handleSelect(e.target.value)}
        style={{
          width: "92%",
          paddingTop: "10px",
          marginLeft: "30px",
          marginTop: "20px",
          backgroundColor: "#F7F7F7",
          borderRadius: "4px",
          border: "2px red",
        }}
      >
        <option value="">Select Type</option>
        <option value="trueFalse">True/False</option>
        <option value="mcq">MCQ</option>
      </select>
      {selectedType === "trueFalse" && (
        <CreateTrueFalseQuestions
          setQuestions={setQuestions}
          questions={question}
          index={index}
        />
      )}
    </>
  );
}
export default SelectType;
