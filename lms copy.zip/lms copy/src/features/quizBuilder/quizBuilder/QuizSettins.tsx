import { Collapse, Select } from "antd";
import CustomRadio from "../../../components/inputs/radio/Radio";
import CustomInput from "../../../components/inputs/input/Input";
import { useEffect, useState } from "react";
import {
  useAppDispatch,
  useAppSelector,
} from "../../../hooks/useTypedSelector";
import {
  createQuizSettings,
  getQuizsettings,
} from "../../../redux/Slices/QuizsesSlice";
import CustomCheckbox from "../../../components/inputs/checkbox/Checkbox";
import { DatePicker } from "antd";
import SwitchButton from "../../../components/shared/switchButton/SwitchButton";
import { useParams } from "react-router-dom";
import usePermission from "../../../PermissionHook";
const { Panel } = Collapse;

const { Option } = Select;
const QuizSettings = ({ setSelectedTab }: any) => {
  const dispatch = useAppDispatch();
  const { id } = useParams();
  const { hasRole, hasPermissionForAction } = usePermission();
  const [quizSettings, setQuizSetting] = useState<any>({
    quizId: id,
    setting: "",
    hideAnswersAt: null,
    showAnswersAt: null,
    saveAsNewSetting: false,
    isQiuzTime: false,
    isQuestionTime: false,
    lockQuestionAftershow: false,
    allowedAttemptsCount: 0,
    quizType: "practiceQuiz",
    shuffleAnswers: false,
    shaffleQuestions: false,
    afterquiz: false,
    afterOneAttempt: false,
    showAnswers: false,
    allowMultipleAttempts: false,
    seeResponses: false,
    showOneQuestionAtATime: false,
    perQuestionTime: 0,
    totelQuizTime: 0,
    allowedAttemptsType: "Lowest",
    sameTimeForAllQuestion: false,
    shareThrough: "accessCode",
    restriction: "assignToEveryone",
    showCalculator: false,
    showBookMark: false,
  });
  const quizzz = useAppSelector((state) => state.quizzes.quizSettings);
  useEffect(() => {
    if (quizzz?.length > 0) setQuizSetting(quizzz[0]);
  }, [quizzz]);
  const [settings, setSettings] = useState<any>([]);
  const handleAssignmentGroupChange = (option: any) => {
    setQuizSetting((prevOptions: any) => ({
      ...prevOptions,
      [option]: !prevOptions[option],
    }));
    if (
      option === "allowMultipleAttempts" &&
      !quizSettings.allowMultipleAttempts === false
    ) {
      setQuizSetting((prevOptions: any) => ({
        ...prevOptions,
        allowedAttemptsType: "Lowest",
        allowedAttemptsCount: 0,
      }));
    }
    if (option === "isQuestionTime") {
      setQuizSetting((prevOptions: any) => ({
        ...prevOptions,
        isQiuzTime: false,
        sameTimeForAllQuestion: false,
        perQuestionTime: 0,
        showOneQuestionAtATime: false,
        lockQuestionAftershow: false,
        totelQuizTime: 0,
      }));
    }
    if (option === "sameTimeForAllQuestion") {
      setQuizSetting((prevOptions: any) => ({
        ...prevOptions,
        perQuestionTime: 0,
      }));
    }
    if (option === "isQiuzTime") {
      setQuizSetting((prevOptions: any) => ({
        ...prevOptions,
        isQuestionTime: false,
      }));
    }
  };
  useEffect(() => {
    const storedData = localStorage.getItem("settings");
    const parsedData = JSON.parse(storedData as any);
    if (parsedData) {
      setSettings(parsedData);
    }
  }, []);
  useEffect(() => {
    dispatch(getQuizsettings());
  }, [dispatch]);

  const handleSaveClick = () => {
    dispatch(createQuizSettings(quizSettings));
    localStorage.setItem(
      "settings",
      JSON.stringify([
        ...settings,
        { name: quizSettings.setting, setting: { ...quizSettings } },
      ])
    );
    setSettings(
      (pre: any) =>
        [
          ...pre,
          { name: quizSettings.setting, setting: { ...quizSettings } },
        ] as any
    );
    //On Save and continue move to add question
    setSelectedTab(1);
  };
  const handleAdd = (v: any) => {
    setQuizSetting((prevQuiz: any) => ({
      ...prevQuiz,
      allowedAttemptsCount: prevQuiz.allowedAttemptsCount + 1,
    }));
  };
  const handleRemov = () => {
    setQuizSetting((prevQuiz: any) => ({
      ...prevQuiz,
      allowedAttemptsCount:
        prevQuiz.allowedAttemptsCount > 0
          ? prevQuiz.allowedAttemptsCount - 1
          : 0,
    }));
  };

  const handleSelectChange = (e: any) => {
    setQuizSetting((prevQuiz: any) => ({
      ...prevQuiz,

      allowedAttemptsType: e,
    }));
  };

  useEffect(() => {
    console.log(quizSettings);
  }, [quizSettings]);
  return (
    <div
      className="d-flex flex-column"
      style={{
        gap: "10px",
        padding: "20px",
        paddingTop: "10px",
        marginTop: "10px",
      }}
    >
      <Collapse
        size="large"
        expandIconPosition="end"
        style={{ backgroundColor: "white" }}
        className="test"
        bordered={false}
      >
        <Panel header={<h4 style={{ margin: "0" }}>Quiz Setting</h4>} key="1">
          <Select
            style={{
              width: "100%",
              height: "34px",
              borderRadius: "4px",
              border: "2px solid #0000001A",
              gap: "4PX",
            }}
            value={quizSettings.setting}
            onChange={(value) => {
              const arr = settings.find((pre: any) => {
                if (pre.name === value) return pre.setting;
              });
              console.log({ ...arr.setting });
              setQuizSetting({
                ...arr.setting,
              });
            }}
          >
            <option value={""}>Choose an option</option>
            {settings.map((setting: any, index: any) => (
              <option key={index} value={setting.name}>
                {setting.name}
              </option>
            ))}
          </Select>
        </Panel>
      </Collapse>
      <Collapse
        size="large"
        expandIconPosition="end"
        style={{ backgroundColor: "white" }}
        className="test"
        bordered={false}
      >
        <Panel header={<h4 style={{ margin: "0" }}>Quiz Type</h4>} key="1">
          <div style={{ gap: "10px" }}>
            <span
              className="d-flex align-start gap-5"
              style={{ paddingRight: "10px" }}
            >
              <CustomRadio
                value={"practiceQuiz"}
                checked={quizSettings?.quizType == "practiceQuiz"}
                onChange={(e: any) =>
                  setQuizSetting((state: any) => ({
                    ...state,
                    quizType: e.target.value,
                  }))
                }
                disabled={hasRole("Assistant") && hasPermissionForAction("QUIZ_TYPE")}
              />
              <span style={{ paddingLeft: "6px", fontSize: "14px" }}>
                Practical Quiz
              </span>
            </span>
            <span
              className="d-flex align-start gap-5"
              style={{ marginTop: "12px" }}
            >
              <CustomRadio
                value={"gradedQuiz"}
                checked={quizSettings?.quizType == "gradedQuiz"}
                onChange={(e: any) =>
                  setQuizSetting((state: any) => ({
                    ...state,
                    quizType: e.target.value,
                  }))
                }
              />
              <span style={{ paddingLeft: "6px", fontSize: "14px" }}>
                {" "}
                Grade Quiz
              </span>
            </span>
          </div>
        </Panel>
      </Collapse>
      <Collapse
        size="large"
        expandIconPosition="end"
        style={{ backgroundColor: "white" }}
        className="test"
        bordered={false}
      >
        <Panel
          header={<h4 style={{ margin: "0" }}>Shuffle Settings</h4>}
          key="1"
        >
          <div style={{ gap: "10px", fontSize: "14px" }}>
            <span className="d-flex align-start gap-5">
              <CustomCheckbox
                checked={quizSettings.shuffleAnswers}
                onChange={() => handleAssignmentGroupChange("shuffleAnswers")}
              />
              Shuffle Answers
            </span>
            <span
              className="d-flex align-start gap-5"
              style={{ marginTop: "12px" }}
            >
              <CustomCheckbox
                checked={quizSettings.shaffleQuestions}
                onChange={(e) =>
                  handleAssignmentGroupChange("shaffleQuestions")
                }
              />

              <span style={{ fontSize: "14px" }}> Shuffle Questions</span>
            </span>
          </div>
        </Panel>
      </Collapse>
      <Collapse
        size="large"
        expandIconPosition="end"
        style={{ backgroundColor: "white" }}
        className="test"
        bordered={false}
      >
        <Panel
          header={<h4 style={{ margin: "0" }}>Feedback Settings</h4>}
          key="1"
        >
          <div style={{ gap: "20px" }}>
            <span
              className="d-flex align-center gap-5"
              style={{ marginLeft: "10px" }}
            >
              <CustomCheckbox
                disabled={quizSettings.showAnswers === true || hasRole("Assistant") && hasPermissionForAction("FEEDBACK_AFTER_EACH_ATTEMPT")}
                checked={quizSettings.afterOneAttempt}
                onChange={() => handleAssignmentGroupChange("afterOneAttempt")}
              />
              <span style={{ fontSize: "14px" }}>
                {" "}
                Only once after each attempt
              </span>
            </span>
            <span
              className="d-flex align-center gap-5"
              style={{ marginLeft: "10px" }}
            >
              <CustomCheckbox
                style={{ marginTop: "10px" }}
                disabled={quizSettings.showAnswers === true || hasRole("Assistant") && hasPermissionForAction("FEEDBACK_AFTER_QUIZSETTING")}
                checked={quizSettings.afterquiz}
                onChange={() => handleAssignmentGroupChange("afterquiz")}
              />
              <span style={{ fontSize: "14px" }}> After quizSettings</span>
            </span>
            <span
              className="d-flex align-center gap-5"
              style={{ marginLeft: "10px" }}
            >
              <CustomCheckbox
                style={{ marginTop: "10px" }}
                disabled={
                  quizSettings.afterquiz === true ||
                  quizSettings.afterOneAttempt === true
                }
                labelStyle={
                  quizSettings.afterquiz === true ||
                    quizSettings.afterOneAttempt === true
                    ? { color: "red", fontSize: "14px" }
                    : { fontSize: "14px" }
                }
                checked={quizSettings.showAnswers}
                onChange={() => handleAssignmentGroupChange("showAnswers")}
                label="Let students see their responses"
              />
            </span>
            <div
              style={{
                // width: "100%",
                backgroundColor: "",
                // border: "4px solid #F7F7F7 ",
                // marginLeft:"50px",
                margin: "10px",
                // marginLeft:"50px",

                // display: "flex",
                // justifyContent: "space-between",
              }}
            >
              <span
                style={{
                  marginRight: "20px",
                  width: "-webkit-fill-available",
                  paddingTop: "10px",

                  borderRadius: "2px",
                  paddingLeft: "10px",
                }}
              >
                {" "}
                <span style={{ fontSize: "14px" }}> Show Correct Ans at</span>
              </span>
              <DatePicker
                // value={quizSettings.showAnswersAt}

                showTime
                format="YYYY-MM-DD HH:mm:ss"
                onChange={(dates, dateStrings) => {
                  setQuizSetting((state: any) => ({
                    ...state,
                    showAnswersAt: dates,
                  }));
                }}
              // disabledDate={(current)=>current && current < moment().startOf('day')}
              />
            </div>
            <div
              style={{
                // width: "100%",
                // backgroundColor: "",
                // border: "1px solid #F7F7F7 ",
                margin: "10px",
                // marginLeft:"50px",
              }}
            >
              <span
                style={{
                  marginRight: "20px",
                  width: "-webkit-fill-available",
                  paddingTop: "10px",
                  borderRadius: "2px",
                  paddingLeft: "11px",
                }}
              >
                <span style={{ fontSize: "14px" }}> Hide Correct Ans at</span>
              </span>
              <DatePicker
                style={{ marginLeft: "4px" }}
                showTime
                format="YYYY-MM-DD HH:mm:ss"
                // value={quizSettings.hideAnswersAt &&  quizSettings?.hideAnswersAt?.format("YYYY-MM-DD HH:mm:ss")}
                onChange={(dates, dateStrings) => {
                  setQuizSetting((state: any) => ({
                    ...state,
                    hideAnswersAt: dates,
                  }));
                }}
                disabledDate={(current) => {
                  if (
                    !quizSettings.showAnswersAt ||
                    quizSettings.showAnswersAt.length === 0
                  ) {
                    return false;
                  }
                  const tooLate =
                    quizSettings.showAnswersAt &&
                    // current.diff(quizSettings.showAnswersAt, "month") <= 1; // start date to one month
                    current.diff(quizSettings.showAnswersAt, "seconds") <= 60; // For example, within a minute

                  // const tooEarly = current.isSameOrAfter(moment()); // untill today
                  return tooLate;
                }}
              />
            </div>
          </div>
          {/* <FeedBackSetting quizSettings={quizSettings}/> */}
        </Panel>
      </Collapse>
      <Collapse
        size="large"
        expandIconPosition="end"
        style={{ backgroundColor: "white" }}
        className="test"
        bordered={false}
      >
        <Panel
          header={<h4 style={{ margin: "0" }}>Attempt Settings </h4>}
          key="1"
        >
          <div style={{ gap: "20px" }}>
            <div>
              {/* style={{ display: "flex", justifyContent: "space-between" }} */}
              <div style={{ display: "flex", flexDirection: "column" }}>
                {/* <span style={{ fontSize: "14px", marginBottom: "17px" }}>
                  Quiz score to keep
                </span> */}
                <span className="d-flex align-center gap-20">
                  <CustomCheckbox
                    style={{ marginTop: "10px" }}
                    checked={quizSettings.allowMultipleAttempts}
                    onChange={() =>
                      handleAssignmentGroupChange("allowMultipleAttempts")
                    }
                    label="Allow Multiple Attempts"
                    labelStyle={{ fontSize: "14px", marginLeft: "10px" }}
                  />
                </span>
              </div>
              {quizSettings.allowMultipleAttempts === true ? (
                <div>
                  <span style={{ fontSize: "14px", marginBottom: "17px" }}>
                    Quiz score to keep
                  </span>

                  <Select
                    style={{
                      width: "150px",
                      borderRadius: "4px",
                      marginLeft: "200px",
                    }}
                    value={quizSettings.allowedAttemptsType}
                    onChange={(value) => handleSelectChange(value)} // Pass the selected value directly
                  >
                    <Option value="Lowest">Lowest</Option>
                    <Option value="Average">Average</Option>
                    <Option value="Highest">Highest</Option>
                    <Option value="Matching">Matching</Option>
                    <Option value="EssayQuestion">Essay Question</Option>
                  </Select>

                  <div
                    style={{
                      marginTop: "20px",
                      display: "flex",
                      flexDirection: "row",
                      // justifyContent: "center",
                      marginLeft: "340px",
                    }}
                  >
                    <span
                      onClick={handleRemov}
                      style={{
                        display: "flex",
                        height: "13px",
                        padding: "10px",
                        justifyContent: "center",
                        alignItems: "center",
                        marginRight: "12px",
                        gap: "8px",
                        borderRadius: "58px",
                        background: "#F1F5F9",
                      }}
                    >
                      -
                    </span>
                    <div
                      style={{
                        border: "2px solid #F7F7F7",
                        borderRadius: "6px",
                        color: "grey",
                        fontSize: "15px",
                        height: "30px",
                        width: "30px",
                        display: "flex",
                        padding: "1px",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      {quizSettings.allowedAttemptsCount}
                    </div>
                    <span
                      onClick={handleAdd}
                      style={{
                        display: "flex",
                        height: "13px",
                        padding: "10px",
                        justifyContent: "center",
                        alignItems: "center",
                        marginLeft: "12px",
                        gap: "8px",
                        borderRadius: "58px",
                        background: "#F1F5F9",
                      }}
                    >
                      +
                    </span>
                  </div>
                </div>
              ) : null}
            </div>
          </div>
        </Panel>
      </Collapse>
      <Collapse
        size="large"
        expandIconPosition="end"
        style={{ backgroundColor: "white" }}
        className="test"
        bordered={false}
      >
        <Panel header={<h4 style={{ margin: "0" }}>Time Settings</h4>} key="1">
          <div className="d-flex flex-column gap-10">
            <div style={{ gap: "20px" }}>
              <div
                style={{
                  display: "flex",
                  // justifyContent: "space-between",
                  width: "97%",
                }}
              >
                <span
                  className="d-flex align-center gap-5"
                  style={{ marginRight: "12px" }}
                >
                  <CustomRadio
                    checked={quizSettings?.isQiuzTime}
                    onChange={() => handleAssignmentGroupChange("isQiuzTime")}
                  />

                  <span style={{ fontSize: "14px" }}> Total Quiz Time</span>
                </span>
                <button className="d-flex align-center minutes-button p2 gap-5">
                  Minutes
                  <input
                    type="number"
                    className="text-center"
                    style={{
                      height: "24px",
                      width: "31px",
                      fontSize: "16px",
                      fontWeight: 100,
                    }}
                    value={quizSettings.totelQuizTime}
                    disabled={quizSettings.isQiuzTime === false}
                    onChange={(e) => {
                      setQuizSetting((state: any) => ({
                        ...state,
                        totelQuizTime: e.target.value,
                      }));
                    }}
                  />
                </button>
              </div>

              {quizSettings.isQiuzTime === true ? (
                <>
                  <span
                    className="d-flex align-center gap-5"
                    style={{ marginLeft: "6px" }}
                  >
                    <CustomCheckbox
                      checked={quizSettings.showOneQuestionAtATime}
                      onChange={() =>
                        handleAssignmentGroupChange("showOneQuestionAtATime")
                      }
                    />
                    <span style={{ fontSize: "14px" }}>
                      {" "}
                      Show one question at a time
                    </span>
                  </span>
                  <span
                    className="d-flex align-center gap-5"
                    style={{ marginLeft: "6px" }}
                  >
                    <CustomCheckbox
                      checked={quizSettings.lockQuestionAftershow}
                      onChange={() =>
                        handleAssignmentGroupChange("lockQuestionAftershow")
                      }
                    />
                    Lock answer after showing
                  </span>
                </>
              ) : null}
              <span
                className="d-flex align-center gap-5"
                style={{ marginTop: "15px" }}
              >
                <CustomRadio
                  checked={quizSettings.isQuestionTime}
                  onChange={() => handleAssignmentGroupChange("isQuestionTime")}
                />

                <span style={{ fontSize: "14px" }}> Per Question Time</span>
              </span>
            </div>
            {quizSettings.isQuestionTime === true ? (
              <div className="d-flex" style={{ gap: "20px" }}>
                <span
                  className="d-flex align-center gap-5"
                  style={{ marginLeft: "6px" }}
                >
                  <CustomCheckbox
                    checked={quizSettings.sameTimeForAllQuestion}
                    onChange={() =>
                      handleAssignmentGroupChange("sameTimeForAllQuestion")
                    }
                  />
                  Do you want to set this time for all question
                </span>
                <button className="d-flex align-center minutes-button p2 gap-5">
                  Minutes
                  <input
                    type="number"
                    className="text-center"
                    style={{
                      height: "24px",
                      width: "70px",
                      fontSize: "16px",
                      fontWeight: 600,
                    }}
                    value={quizSettings.perQuestionTime}
                    disabled={quizSettings.sameTimeForAllQuestion === false}
                    onChange={(e) => {
                      setQuizSetting((state: any) => ({
                        ...state,
                        perQuestionTime: e.target.value,
                      }));
                    }}
                  />
                </button>
              </div>
            ) : null}
          </div>
        </Panel>
      </Collapse>
      <Collapse
        size="large"
        expandIconPosition="end"
        style={{ backgroundColor: "white" }}
        className="test"
        bordered={false}
      >
        <Panel header={<h4 style={{ margin: "0" }}>Quiz Tools</h4>} key="1">
          <div style={{ display: "flex", flexDirection: "column" }}>
            <div style={{ marginBottom: "20px" }}>
              <SwitchButton
                value={quizSettings.showCalculator}
                onChange={(isChecked: any) => {
                  setQuizSetting((state: any) => ({
                    ...state,
                    showCalculator: isChecked,
                  }));
                }}
              />
              <span style={{ marginLeft: "10px", fontSize: "14px" }}>
                Calculator
              </span>
            </div>
            <div>
              {" "}
              <SwitchButton
                value={quizSettings.showBookMark}
                onChange={(isChecked: any) => {
                  setQuizSetting((state: any) => ({
                    ...state,
                    showBookMark: isChecked,
                  }));
                }}
              />
              <span style={{ marginLeft: "10px", fontSize: "14px" }}>
                BookMark
              </span>
            </div>
          </div>
        </Panel>
      </Collapse>
      <Collapse
        size="large"
        expandIconPosition="end"
        style={{ backgroundColor: "white" }}
        className="test"
        bordered={false}
      >
        <Panel header={<h4 style={{ margin: "0" }}>Save Settings</h4>} key="1">
          <div className="d-flex flex-column gap-10">
            <div>
              <span style={{ marginRight: "10px", fontSize: "14px" }}>
                Do you want to save these setting as new settings
              </span>
              <SwitchButton
                value={quizSettings.saveAsNewSetting}
                onChange={(isChecked: any) => {
                  setQuizSetting((state: any) => ({
                    ...state,
                    saveAsNewSetting: isChecked,
                  }));
                  if (isChecked === false) {
                    setQuizSetting((state: any) => ({
                      ...state,
                      setting: "",
                    }));
                  }
                }}
              />
            </div>
            <span className="d-flex align-center gap-5">
              <CustomInput
                placeholder="Enter Setting Name"
                disabled={quizSettings.saveAsNewSetting === false}
                value={quizSettings.setting}
                onChange={(e) => {
                  setQuizSetting((state: any) => ({
                    ...state,
                    setting: e.target.value,
                  }));
                  console.log(quizSettings.setting, "setting");
                }}
              />
            </span>
          </div>
        </Panel>
      </Collapse>
      <div className="d-flex justify-end gap-10">
        <button className="reset-button">Reset All</button>
        <button className="save-btn" onClick={handleSaveClick}>
          Save & Continue
        </button>
      </div>
    </div>
  );
};
export default QuizSettings;
function moment(showAnswersAt: any) {
  throw new Error("Function not implemented.");
}
