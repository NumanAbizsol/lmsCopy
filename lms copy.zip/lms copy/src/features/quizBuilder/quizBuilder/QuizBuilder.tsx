import Questions from "../question/Question";
import HeaderTabsAndNevbar from "../../../components/shared/headerAndTabs/headerTabsAndSidebar";
import QuizSettings from "./QuizSettins";
import { useEffect, useState } from "react";
import { useAppSelector } from "../../../hooks/useTypedSelector";
import { TabData } from "./QuizBuilder.d";

const tabData: TabData[] = [
  { name: "Quiz Settings", page: QuizSettings },
  { name: "Add Questions", page: Questions },
  { name: "Publish", page: null },
];
export default function QuizBuilder() {
  const { quiz } = useAppSelector((state: any) => state.quizzes);
  console.log("QUIZ ",quiz)

  const [header, setHrader] = useState<any>([[
    { name: "Back to Dashboard", route: "/quiz" },
    { name: "New Quiz", route: "" },
    { name: "Landing Page", route: "" },
  ]]);
  useEffect(() => {
    if (quiz) {
      setHrader([
        { name: "Back to Dashboard", route: "/quiz" },
        { name: quiz[0]?.title??"New Quiz", route: "" }, 
        { name: "Landing Page", route: "" },
      ]);
    }
  }, [quiz]);
  return (
    <div className="quizes-container">
      {header[0]?.name ? (
        <HeaderTabsAndNevbar header={header} tabData={tabData} />
      ) : null}
    </div>
  );
}
