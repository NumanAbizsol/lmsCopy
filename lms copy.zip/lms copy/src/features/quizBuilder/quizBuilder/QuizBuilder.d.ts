export interface TabData {
    name: string;
    page: React.ComponentType<any> | null;
  }