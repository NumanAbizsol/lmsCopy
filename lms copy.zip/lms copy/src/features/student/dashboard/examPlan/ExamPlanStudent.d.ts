export interface ExamDataItem {
  icon: string; 
  date: string;
  description: string;
  color: string;
  backgroundColor: string;
}

export interface ExamData {
  day: string;
  isChecked: boolean;
  rangeValue: number;
  age: number;
}