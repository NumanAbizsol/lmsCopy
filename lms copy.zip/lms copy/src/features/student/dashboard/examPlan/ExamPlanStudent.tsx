import React, { useEffect, useState } from "react";
import "./examplan-style.scss";
import { DatePicker, Space } from "antd";
import AnalogClock from "../../../../assets/images/clockDarkBlue.png";
import CustomSelect from "../../../../components/inputs/select/Select";
import CustomCheckbox from "../../../../components/inputs/checkbox/Checkbox";
import {ExamData} from "./ExamPlanStudent.d"
import { examData1,examScheduleData } from "../../../../constants/Constants";

const ExamPlanStudent: React.FC  = () => {
    const [totalAge, setTotalAge] = useState<number>(0);
  const min = 0;
  const max = 24;
  const [examData, setExamData] = useState<ExamData[]>(
    examScheduleData,
  );
  useEffect(() => {
    updateBackgroundColor();
    updateTotalAge();
  }, [examData]);

  function updateBackgroundColor(): void {
    examData.forEach((dayData: ExamData, index: number) => {
      const container = document.getElementById(`myRange${index}`);
  
      if (container) {
        const percentage = ((dayData.rangeValue - min) / (max - min)) * 100;
        container.style.background = `linear-gradient(to right, cadetblue 0%, cadetblue ${percentage}%, #ddd ${percentage}%, #ddd 100%)`;
      }
    });
  }

  const handleChange = (e: any, index: number): void => {
    let value = e.target.value.replace(/\D/g, "");
    value = Math.min(Math.max(parseInt(value, 10), 0), 24);
  
    const updatedExamData = [...examData];
    const currentDay = updatedExamData[index];
  
    currentDay.age = value;
    currentDay.rangeValue = value;
    setExamData(updatedExamData);
  };

  const handleCheckboxClick = (index: number): void => {
    const updatedExamData = [...examData];
    updatedExamData[index].isChecked = !updatedExamData[index].isChecked;
    setExamData(updatedExamData);
  };

  const updateTotalAge = (): void => {
    const sum: number = examData.reduce((acc: number, day: { age: number }) => acc + day.age, 0);
    setTotalAge(sum);
  };
  
  
  const onChange = (date: any, dateString: any): void => {
    console.log(date, dateString);
  };

  return (
    <div className="exam-plan-container">
      <div className="exam-plan-content">
        <div className="exam-heading-content">Data Selection</div>
        <div className="exam-date-container">
          <div className="exam-start-date">
            <div style={{ paddingBottom: "20px" }}>
              When do you want to start studying?
            </div>
            <div className="date-picker-container">
              <Space direction="vertical" style={{ width: "100%" }}>
                <DatePicker
                  onChange={onChange}
                  picker="date"
                  placeholder="MM / DD / YYYY"
                  className="date-picker"
                />
              </Space>
            </div>
          </div>
          <div className="exam-start-date">
            <div style={{ paddingBottom: "20px" }}>
              When Are you sitting for the Exam?
            </div>
            <div className="date-picker-container">
              <Space direction="vertical" style={{ width: "100%" }}>
                <DatePicker
                  onChange={onChange}
                  picker="date"
                  placeholder="MM / DD / YYYY"
                  className="date-picker"
                />
              </Space>
            </div>
          </div>
        </div>
      </div>
      <div className="Schedule-container">
        <div className="inner-schedule-container">
          <div className="hour-content-heading">
            <span>How Many Hours a week do you want to study?</span>
          </div>
          <div className="schedule-container-split">
            {examData.map((day:any, index:number) => (
              <div key={index} className="checkbox-container">
                <div>
                  <CustomCheckbox
                    checked={day.isChecked}
                    onChange={() => handleCheckboxClick(index)}
                  />
                </div>
                <div style={{ width: "9%" }}>
                  <span className="days-heading-content">{day.day}</span>
                </div>
                <div className="progress-bar-container">
                  <div className="range-container">
                    <input
                      style={{ backgroundColor: "cadetblue" }}
                      type="range"
                      min={min}
                      max={max}
                      value={day.rangeValue}
                      className="range-input"
                      id={`myRange${index}`}
                      onChange={(e:any) => handleChange(e, index)}
                      onMouseUp={(e:any) => updateBackgroundColor()}
                    />
                  </div>
                </div>
                <div>
                  <CustomSelect
                    options={Array.from({ length: 24 }, (_, i) => i + 1).map(
                      (value) => ({
                        label: value.toString(),
                        value: value.toString(),
                      })
                    )}
                    variant={"single-select"}
                    handleChange={(e:any) =>
                      handleChange({ target: { value: e } }, index)
                    }
                    selected={day.age.toString()}
                    customStyle={{ height: "25px", width: "59px" }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="exam-clock-main-div">
          <div className="exam-div-img">
            <img src={AnalogClock} alt="Ananlog-Clock" />
          </div>
          <div style={{ color: " #08496D" }}>
            <p className="exam-date-div-container">{totalAge}</p>
            <span className="exam-container-description">Week Hours</span>
          </div>
        </div>
      </div>

      <div className="exam-content-main-container">
        {examData1.map((item, index) => (
          <div
            key={index}
            className="exam-content-main-div"
            style={{ backgroundColor: item.backgroundColor }}
          >
            <div className="exam-div-img">
              <img src={item.icon} alt={item.description} />
            </div>
            <div style={{ color: item.color }}>
              <p className="exam-date-div-container">{item.date}</p>
              <span className="exam-container-description">
                {item.description}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ExamPlanStudent;
