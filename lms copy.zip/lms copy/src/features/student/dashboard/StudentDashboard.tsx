import React from "react";
import "./studentDashboard.scss";
import undraw from "../../../assets/images/undraw_hello.png";
import CustomPieChart from "../../../components/shared/piechart/CustomPieChart";
import CustomCalender from "../../../components/inputs/calender/Calender";

export default function StudentDashboard() {
  const data = [
    { title: "Completed", value: 10, color: "#697AE2" },
    { title: "Overdue", value: 10, color: "#45B177" },
    { title: "Skipped", value: 1, color: "#FF6161" },
    { title: "Inprogress", value: 62, color: "#565666" },
    { title: "Unattempt", value: 59, color: "#A5AFEE" },
  ];
  const progressdata = [{ title: "Completed", value: 90, color: "#2CCA75" }];
  const completeddata = [{ title: "Completed", value: 50, color: "#8C4AF2  " }];
  const daysremainings = [{ title: "Completed", value: 14, color: "#FF2A2A" }];

  const overallprogress = progressdata.reduce( (sum, item) => sum + item.value, 0);
  const overallcompletion = completeddata.reduce( (sum, item) => sum + item.value, 0);
  const totaldays = daysremainings.reduce( (sum, item) => sum + item.value, 0);
  const totalValue = data.reduce((sum, item) => sum + item.value, 0);

  return (
    <div className="std-main-wrapper">
  <p>Dashboard</p>
  <div className="std-dashboard-wrapper">
    <div className="dashboard-data">
      <img src={undraw} alt="undraw" />
      <div className="statistic">
        <h2 className="text-heading">You're on Track</h2>
        <pre className="text-styling">We will show you some statistics<br />related to your course here..</pre>
      </div>
    </div>
    <div className="std-chart">
      <div style={{ display: "flex", flexDirection: "column" }} className="checkboxs">
        <h2>Course Completion</h2>
        {data.map((item, index) => (
          <div key={index} style={{ display: "flex", alignItems: "center" }}>
            <div style={{ marginTop: "5px", width: "20px", height: "20px", backgroundColor: item.color, marginRight: "8px" }}></div>
            <span className="titles">{item.title}</span>
            <span>({item.value})</span>
          </div>
        ))}
      </div>
      <div className="pie-chart"><CustomPieChart data={data} totalValue={totalValue}></CustomPieChart></div>
    </div>
  </div>
  <div className="progress-bar">
    <div className="progress-overall">
      <div>
        <h4 className="progress-heading">Your Overall Progress</h4>
        <h1>{overallprogress}%</h1>
      </div>
      <div className="chart"><CustomPieChart data={progressdata} totalValue={100} labelPosition={52} lineWidth={20}></CustomPieChart></div>
    </div>
    <div className="progress-overall">
      <div>
        <h4 className="progress-heading">Days Remaining</h4>
        <h1>{totaldays}</h1>
      </div>
      <div className="chart"><CustomPieChart data={daysremainings} totalValue={100} labelPosition={52} lineWidth={20}></CustomPieChart></div>
    </div>
    <div className="progress-overall">
      <div>
        <h4 className="progress-heading">You've Completed</h4>
        <h1>{overallcompletion}%</h1>
      </div>
      <div className="chart"><CustomPieChart data={completeddata} totalValue={100} labelPosition={52} lineWidth={20}></CustomPieChart></div>
    </div>
  </div>
  <div className="exam-plan">
    <CustomCalender
   ></CustomCalender>
  </div>
</div>

  );
}
