import React, { useState } from 'react'
import './StudentDashboard.scss'
import { StudentCourseCardProps } from '../../components/shared/studentCourseCard/studentCourseCard/StudentCourseCard.d';
import bannerImage from '../../assets/images/Path.svg'
import CardsList from '../../components/shared/studentCourseCard/cardsList/CardsList';
import { TabData } from '../../components/shared/headerAndTabs/Tabs.d'
import HeaderTabsAndNevbar from '../../components/shared/headerAndTabs/headerTabsAndSidebar';

const mockCourses: StudentCourseCardProps[] = [
  {
    thumbnail: 'url1',
    title: 'Course 1',
    description: 'Description for Course 1',
    instructor: { name: 'Instructor 1', image: 'url_instructor1' },
    price: 10,
    isFavourite: false,
    isHidden: false,
    progress: 30,
  },
  {
    thumbnail: 'url1',
    title: 'Course 1',
    description: 'Description for Course 1',
    instructor: { name: 'Instructor 1', image: 'url_instructor1' },
    price: 10,
    isFavourite: false,
    isHidden: false,
    progress: 90,
  },
  {
    thumbnail: 'url1',
    title: 'Course 1',
    description: 'Description for Course 1',
    instructor: { name: 'Instructor 1', image: 'url_instructor1' },
    price: 10,
    isFavourite: false,
    isHidden: false,
    progress: 30,
  },
  {
    thumbnail: 'url1',
    title: 'Course 1',
    description: 'Description for Course 1',
    instructor: { name: 'Instructor 1', image: 'url_instructor1' },
    price: 10,
    isFavourite: false,
    isHidden: false,
    progress: 80,
  },
  {
    thumbnail: 'url1',
    title: 'Course 1',
    description: 'Description for Course 1',
    instructor: { name: 'Instructor 1', image: 'url_instructor1' },
    price: 10,
    isFavourite: false,
    isHidden: false,
    progress: 50,
  },
  
];
const tabData: TabData[] = [
  { name: "Courses", page:CardsList},
  { name: "FlashCards", page:null },
  { name: "Whishlist", page: null },
  { name: "Archived", page: null },
];

const StudentDashboard: React.FC<any> = ({ heading, text }) => {
  const [selectedTab, setSelectedTab] = useState(0);

  return (
    <>
      <div className="studen-dashboard">
        <div className="student-content">
          <h1 className="banner-heading">Good Afternoon, Nouman</h1>
          <p className="banner-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Adipisci assumenda cupiditate eum dolor exercitationem iure nesciunt maxime odit laboriosam illum, aspernatur optio? Nostrum, tenetur eligendi. Ab ea nulla corporis fugiat?</p>
        </div>
        <div className="student-dashboard-img">
          <img src={bannerImage} alt="" />
        </div>
      </div>
      <div className="tabs">
        <HeaderTabsAndNevbar showTabsOnly={true} tabData={tabData} selectedTab={selectedTab} setSelectedTab={setSelectedTab} courses={mockCourses}/>
      </div>
    </>
  );
};

export default StudentDashboard;
