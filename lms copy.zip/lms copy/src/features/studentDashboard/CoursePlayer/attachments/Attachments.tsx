import React from "react";
import './Attachments.scss'
import pdfIcon from "../../../../assets/images/pdfupload.png"
import download from "../../../../assets/images/download.png"

interface Attachment {
  name: string;
  url: string;
  fileSize: string;
}
interface AttachmentsProps {
  attachments: Attachment[];
}
const getIconForFileType = (fileName: string): string => {
  const extension = fileName.split('.').pop()?.toLowerCase() || '';
  if (extension === 'pdf') {
    return pdfIcon;
  } else if (extension === 'doc' || extension === 'docx') {
    return pdfIcon; //Temporary
  } else {
    return pdfIcon;  //Temporary
  }
};


const Attachments: React.FC<AttachmentsProps> = ({ attachments }) => {
  return (
    <div className="files-div">
      <div className="label-div">
        <p className="label-style">AVAILABLE FOR DOWNLOADS</p>
        <a className="label-downloadAll">Download All</a>
      </div>
      <ul>
        {attachments.map((attachment:any, index:any) => (
          <li key={index}>
            <div className="file-details">
              <div className="img-name-div">
                <img src={getIconForFileType(attachment.name)} alt="File Icon" className="file-icon" />
                <div>
                  <p><strong>{attachment.name}</strong></p>
                  <p>{attachment.fileSize}</p>
                </div>
              </div>
              <a href={attachment.url} download={attachment.name}>
                <img src={download} alt="Download Icon"></img>
                Download
              </a>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};
export default Attachments;