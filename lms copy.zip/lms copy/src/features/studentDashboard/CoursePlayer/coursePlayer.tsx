import { useEffect, useState } from "react";
import Sidebar from "../../../components/shared/headerAndTabs/sidebar/Sidebar"
import CoursePlayerScreen from "./coursePlayerScreen/CoursePlayerScreen";
import CoursePlayerDropDown from "./courseDropDown/CoursePlayerDropDown";

import Video from "../../../assets/dummyvideo/Dummyanimation.mp4"
import { useAppDispatch, useAppSelector } from "../../../hooks/useTypedSelector";
import { getSections } from "../../../redux/Slices/CoursesSlice";

const CoursePlayer: React.FC<any> = () => {
    // FOR screen side bars and drop down 
    const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(true)
    const [isTransitioning, setIsTransitioning] = useState(false);

    const [selectedCourse,setSelectedCourse] =useState(null);
    
    const handleSelectItem = (item:any) => {
        setSelectedCourse(item);
      };

      const dispatch = useAppDispatch();
      useEffect(() => {
          dispatch(getSections());
      }, [dispatch]);
      const sectionsData = useAppSelector((state: any) => {
        return state.course.sections;
        // return state.course.sections && state.course.sections[0]?.section;
    })
    return (
        <div style={{ display: "flex", flexDirection: "row" }}>
            <div className={`sidebar-wrapper ${isTransitioning ? "transitioning" : ""}`}>
                <Sidebar
                    isSidebarCollapsed={isSidebarCollapsed}
                    setIsSidebarCollapsed={setIsSidebarCollapsed}
                    isForCoursePlayer={true}
                />
            </div>
            <div>
            <CoursePlayerScreen selectedCourse={selectedCourse}></CoursePlayerScreen>
            </div>
            <div>

            <CoursePlayerDropDown sectionsData={sectionsData} onSelectItem={handleSelectItem}></CoursePlayerDropDown>
            </div>
        </div>
    )
}
export default CoursePlayer;