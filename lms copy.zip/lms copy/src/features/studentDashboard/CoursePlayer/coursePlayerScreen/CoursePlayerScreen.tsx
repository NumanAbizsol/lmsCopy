import React, { useState } from 'react';
import './CoursePlayerScreen.scss'
import Video from "../../../../assets/dummyvideo/Dummyanimation.mp4"
import CustomButton from '../../../../components/shared/button/Button';
import Tab from '../../../../components/shared/headerAndTabs/Tabs';
import Comments from '../comments/Comments';
import Attachments from '../../CoursePlayer/attachments/Attachments';
import teacherImg from '../../../../assets/images/avatarIconcircle.png'

interface TabData {
   name: string;
   page: React.ComponentType<any> | null;
}

const tabData: TabData[] = [
   { name: "Attachments", page: Attachments },
   { name: "Comments", page: Comments },
   { name: "Reviews", page: null },
];
const attachments = [
   { name: 'Document 1', url: 'file:///home/frontend/Downloads/next-gen-js-summary.pdf', fileSize: '2.3KB' },
   { name: 'Document 2', url: 'file:///home/frontend/Downloads/next-gen-js-summary.pdf ', fileSize: '5.0KB' },
];

const CoursePlayerScreen: React.FC<any> = ({ selectedCourse }) => {

   const [selectedTab, setSelectedTab] = useState(0)
   return ( 
      <div className='courseplayer-maindiv'>

         <div className='video-div'>
            <video height="400" width="100%" controls>
               <source src={Video} type='video/mp4'></source>
            </video>
         </div>
      <div className='belowVideo-div'>
         <div className='teacher-div'>
            <img src={teacherImg} alt="Teachers Image"></img>
            <div >
               <label className='teacher-name'>Author: </label>
               <span><strong>teacher's Name</strong></span>
            </div>
         </div>
         <CustomButton className="container-btn" variant='primary'>Next Lesson</CustomButton>
      </div>
      <div className='section-detaildiv'>
         <h4>Section Title</h4>
         <p className='section-descr'>description</p>
      </div>
      <div className='tabs-div'>
         <Tab tabData={tabData} setSelectedTab={setSelectedTab} selectedTab={selectedTab} />
         <div>
            {tabData[selectedTab].page &&
               React.createElement(
                  tabData[selectedTab].page as React.ComponentType<any>,
                  { setSelectedTab: setSelectedTab, attachments }
               )}
         </div>
      </div>
   </div>
   )
}
export default CoursePlayerScreen;