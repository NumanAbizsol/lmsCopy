import "../courseDropDown/CoursePlayerDropDown.scss";
import React, { useEffect, useState } from "react";
import { Collapse, Select } from "antd";
import { useAppDispatch, useAppSelector, } from "../../../../hooks/useTypedSelector";
import { getCourse, getSections } from "../../../../redux/Slices/CoursesSlice";
const { Panel } = Collapse;

const CoursePlayerDropDown: React.FC<any> = ({ sectionsData,onSelectItem }) => {
    const [selected, setSelected] = useState(false);
    // const handleSelect = (index: any) => {
    //     setSelected(index);
    // };
    //var storedData = localStorage.getItem("sections");

    // const coursedata=useAppSelector((state)=>state.course.course)
    // const coursePlayers = useAppSelector(
    //   (state: any) => state.course.sections[0].section
    // );

    console.log("sectiondata", sectionsData);
    // console.log("Section title: ", sectionsData[0].section[0].title)
    // console.log("Section Description: ", sectionsData[0].section[0].description)
    // console.log("Section chpater: ", sectionsData[0].section[0].chapter)
    //  console.log("Section content: ", sectionsData[0].section[0].content)
    //  console.log("Section content desc: ", sectionsData[0].section[0].content[0].description)
    //  const htmlContent = sectionsData[0].section[0].content[0].description;
                      
    //  const section = sectionsData.map((section:any, index:any) => {
    //     console.log("section: ",section.section[index].content[index].pdf);
    //   });
    return (
        <div>
            DropDown
            {/* <div dangerouslySetInnerHTML={{ __html: htmlContent }} /> */}
            <ul>
                {sectionsData?.map((section:any, index:any) => (
                    <li key={index} onClick={() => onSelectItem(section)}>
                        <h1>{section.section[index].title}</h1>
                        <h4>{section.section[index].content[index].title}</h4>
                        <h3>{section.section[index].chapter[index].title}</h3>
                        <h6>{section.section[index].chapter[index].description}</h6>
                        <h6>{section.section[index].chapter[index].content}</h6>
                    </li>
                ))}
            </ul>
        </div>
        //         <div
        //             className="divide-screen-column align-end "
        //             style={{ borderRadius: "4px" }}
        //         >
        //             {coursePlayers?.length &&
        //                 coursePlayers?.map((course: any, index: any) => {
        //                     return (
        //                         <div
        //                             key={index}
        //                             style={{
        //                                 display: "flex",
        //                                 flexDirection: "column",
        //                                 justifyContent: "flex-end",
        //                                 borderRadius: "4px",
        //                             }}
        //                         >
        //                             <div className="coursePlayerMain">
        //                                 <div>{/* <h3 >{course.title} </h3> */}</div>
        //                                 <div className="coursePlayermain d-flex align-center   ">
        //                                     <div className="align-center d-flex ">
        //                                         <div>
        //                                             {/* <img src={imgPlayer} alt="no img" />{" "} */}
        //                                         </div>
        //                                         <span>{course.description}</span>
        //                                     </div>
        //                                     <div>
        //                                         <Collapse
        //                                             size="large"
        //                                             expandIconPosition="end"
        //                                             className="test"
        //                                             bordered={false}
        //                                         >
        //                                             <Panel
        //                                                 header={
        //                                                     <h4 style={{ margin: "0" }}>{course.title}</h4>
        //                                                 }
        //                                                 key="1"
        //                                             >
        //                                                 {course.content.map((con: any) => (
        //                                                     <>
        //                                                         {/* <div dangerouslySetInnerHTML={{ __html: sanitizedHTML }} /> */}
        //                                                         <div>{con.description}</div>
        //                                                         <div>{con.title}</div>
        //                                                         <div>
        //                                                             <video height="100" width="100%" controls>
        //                                                                 <source src={con.videoUrl} type="video/mp4" />
        //                                                             </video>
        //                                                         </div>
        //                                                     </>
        //                                                 ))}
        //                                                 {course.chapter.map(
        //                                                     (chap: any, chapterIndex: any) => (
        //                                                         <Collapse
        //                                                             key={chapterIndex}
        //                                                             expandIconPosition="end"
        //                                                             bordered={false}
        //                                                         >
        //                                                             <Panel
        //                                                                 header={
        //                                                                     <h4 style={{ margin: "0" }}>
        //                                                                         {chap.title}
        //                                                                     </h4>
        //                                                                 }
        //                                                                 key="1"
        //                                                             >
        //                                                                 <div
        //                                                                     style={{
        //                                                                         backgroundColor: "#ddd",
        //                                                                         width: "174%",
        //                                                                         marginLeft: "-54px",
        //                                                                         display: "flex",
        //                                                                         alignItems: "center",
        //                                                                         flexDirection: "column",
        //                                                                         justifyContent: "center",
        //                                                                         border: "2px solid grey",
        //                                                                         borderRadius: "4px",
        //                                                                     }}
        //                                                                 >
        //                                                                     {/*
        //   <div dangerouslySetInnerHTML={{ __html: sanitizedHTML.replace(/<\/?p>/g, '') }} /> */}
        //                                                                     {chap.description} <div>{chap.Slug}</div>
        //                                                                     {chap.tagline}
        //                                                                 </div>
        //                                                                 {/* <div>{chap}</div> */}
        //                                                                 {chap.content.map(
        //                                                                     (con: any, contentIndex: any) => (
        //                                                                         <Collapse
        //                                                                             key={contentIndex}
        //                                                                             expandIconPosition="end"
        //                                                                             bordered={false}
        //                                                                         >
        //                                                                             <Panel
        //                                                                                 header={
        //                                                                                     <h4 style={{ margin: "0" }}>
        //                                                                                         {con.title}
        //                                                                                     </h4>
        //                                                                                 }
        //                                                                                 key="1"
        //                                                                             >
        //                                                                                 {/* <div dangerouslySetInnerHTML={{ __html: sanitizedHTML }} /> */}
        //                                                                                 <div>{con.description}</div>
        //                                                                             </Panel>
        //                                                                         </Collapse>
        //                                                                     )
        //                                                                 )}
        //                                                             </Panel>
        //                                                         </Collapse>
        //                                                     )
        //                                                 )}
        //                                             </Panel>
        //                                         </Collapse>
        //                                     </div>
        //                                 </div>
        //                             </div>
        //                         </div>
        //                     );
        //                 })}
        //         </div>
    );
}
export default CoursePlayerDropDown;