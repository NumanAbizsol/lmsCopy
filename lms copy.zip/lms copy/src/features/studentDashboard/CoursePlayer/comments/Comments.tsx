const Comments: React.FC<any> = () =>{
     return(
        <div>Comments</div>
     )
}
export default Comments;