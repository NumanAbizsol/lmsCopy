import "../studentCoursePlayer/studentCoursePlayer.scss";
import imgPlayer from "../studentCoursePlayer/Icon.png";
import fruits from "../studentCoursePlayer/fruits.mp4"
// import { Flex } from "antd";
import React, { useState } from "react";
import { Collapse, Select } from "antd";
const { Panel } = Collapse;
export default function StudentCoursePlayer() {
  const [selectedChapter, setSelectedChapter] = useState(null);
    const [selected, setSelected] = useState(false);
    const handleSelect = (index :any) => {
        setSelected(index);
      };
    const coursePlayers =[
      {
          "title": "Section12",
          "description": "",
          "chapter": [
              {
                  "title": "cheptr1",
                  "tagline": "asdfghjk",
                  "Slug": "adss",
                  "description": "qwerty",
                  "content": [
                      {
                          "title": "sdasd",
                          "audio": null,
                          "description": "sdaaddd"
                      },
                      {
                        "title": "sdasd",
                        "audio": null,
                        "description": "sdaaddd"
                    }
                  ]
              }
          ],
          "content": [

              {
                "videoUrl": fruits,
                "title": "szxty",
                  "url": "asads",
                  "description": "saaaaaaaad"
              }
          ]
      }
  ]
  return (
    <div className="divide-screen-column align-end  "
    style={{borderRadius:"4px"}}>
    {coursePlayers.map((course,index)=>(
        <div style={{display:"flex",  flexDirection:"column" ,justifyContent:"flex-end", borderRadius:"4px"}}>
           <div className="coursePlayerMain">
           <div>
             {/* <h3 >{course.title} </h3> */}
           </div>
        <div className="coursePlayermain d-flex align-center   " >
             <div className="align-center d-flex ">
               <div>
                 {/* <img src={imgPlayer} alt="no img" />{" "} */}
               </div>
               <span>{course.description}</span>
             </div>
             <div>
             <Collapse
      size="large"
      expandIconPosition="end"
      className="test"
      bordered={false}
    >
      <Panel header={<h4 style={{ margin: "0" }}>{course.title}</h4>} key="1">
      {course.content.map((con,conindex)=>(<>
        <div>{con.description}</div>
        <div>{con.title}</div>
        <div>
  <video height="100" width="100%" controls>
    <source src={con.videoUrl} type="video/mp4" />
  </video>
</div>
      </>
      ))}
        {course.chapter.map((chap, chapterIndex) => (
          <Collapse key={chapterIndex}  expandIconPosition="end" bordered={false}>
            <Panel
              header={
                <h4 style={{ margin: "0" }}>
                  {chap.title}
                </h4>
              }
              key="1"
            >
              <div style={{backgroundColor:"#ddd",width:"174%",marginLeft:"-54px",
              display:"flex",alignItems:"center", flexDirection:"column",
              justifyContent:"center"
             , border:"2px solid grey" ,borderRadius:"4px"}}>{chap.description} <div>{chap.Slug}</div>
             {chap.tagline}
             </div>
              {/* <div>{chap}</div> */}
              {chap.content.map((con, contentIndex) => (
                <Collapse key={contentIndex}  expandIconPosition="end" bordered={false}>
                  <Panel
                    header={
                      <h4 style={{ margin: "0" }}>{con.title}</h4>
                    }
                    key="1"
                  >
                    <div>{con.description}</div>
                  </Panel>
                </Collapse>
              ))}
            </Panel>
          </Collapse>
        ))}
      </Panel>
    </Collapse>
             </div>
           </div>
         </div>
         </div>
    ))}
    </div>
  );
}