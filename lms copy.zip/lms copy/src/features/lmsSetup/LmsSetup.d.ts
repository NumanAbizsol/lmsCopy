export interface FormData {
    IdentifyYourSelf: string;
    WorkInYourBusiness: string;
    BusinessIn: string;
    LearingBusiness: string;
    EmailList: string;
  }