import React, { useState } from "react";
import "./FlashCard.scss";
import Sidebar from "../../../components/shared/headerAndTabs/sidebar/Sidebar";
import FlashcardMain from "../../../assets/images/Flashcardmain.png";
import CustomButton from "../../../components/shared/button/Button";
import BlankPage from "../../../assets/images/BlankPages.png";


const FlashCard: React.FC = () => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(true);
  const handleAddFlashCard = () => {
     
  }

  return (
 
    <div className="wraper" style={{ display: 'flex' }}>
      < div style={{ width: !isSidebarCollapsed ? "5%" : "16%" }}>
        <Sidebar isSidebarCollapsed={isSidebarCollapsed}
          setIsSidebarCollapsed={setIsSidebarCollapsed}
        />
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', width: "100%", margin: "20px", gap: "20px" }}>
        <div className="helloDiv">
          <div className="helloDiv-text">
            <p className="flashcard-h">Help students to gain the confidence.</p>
            <p className="flashcard-p">Make a flash card and help your students to gain the confidence and get succeed.</p>
          </div>
          <div >
            <img src={FlashcardMain} alt="Hello Student Image"></img>
          </div>
        </div>

        <div className="addFlashCard-div">
          <div className="blankpage-imagediv"><img src={BlankPage} alt="BlankPages"></img></div>
          <div className="addFlashCard-txt">
            <h3 className="flashcard-h">No Flashcard Created Yet</h3>
            <p className="flashcard-p addFlashCard-p">Write something here that will make your reader excited! You can write anything in here. Get started.</p>
          </div>
          <CustomButton onClick={handleAddFlashCard} className="btn-container" childClasses="btn-txt" showPlusButton={true} variant="primary">Add FlashCard</CustomButton>
        </div>
      </div>

    </div>
  )

}
export default FlashCard;