import { Collapse, Select } from "antd";
import CustomRadio from "../../../../components/inputs/radio/Radio";
import { useState } from "react";
const { Panel } = Collapse;
const { Option } = Select;

const TextSetting: React.FC = () => {
  const [textSettings, setTextSetting] = useState({
    quizType: "practiceQuiz",
    allowedAttemptsType: false,
    allowedFontType: false,
  });

  const handleSelectChange = (e:any) => {
    setTextSetting((prevQuiz) => ({
      ...prevQuiz,

      allowedAttemptsType: e,
    }));
  };

  const handleSelectChangeFamily = (e:any) => {
    setTextSetting((prevQuiz) => ({
      ...prevQuiz,

      allowedFontType: e,
    }));
  };
  return (
    <div>
      <Collapse
        size="large"
        expandIconPosition="end"
        style={{ backgroundColor: "white" }}
        className="test"
        bordered={false}
      >
        <Panel header={<h4 style={{ margin: "0" }}>Deck Type</h4>} key="1">
          <div style={{ gap: "10px" }}>
            <span
              className="d-flex align-start gap-5"
              style={{ paddingRight: "10px" }}
            >
              <CustomRadio
                value={"practiceQuiz"}
                checked={textSettings?.quizType === "practiceQuiz"}
                onChange={(e:any) =>
                  setTextSetting((state) => ({
                    ...state,
                    quizType: e.target.value,
                  }))
                }
              />
              <span style={{ paddingLeft: "6px", fontSize: "14px" }}>H1</span>
            </span>
            <span
              className="d-flex align-start gap-5"
              style={{ marginTop: "12px" }}
            >
              <CustomRadio
                value={"gradedQuiz"}
                checked={textSettings?.quizType === "gradedQuiz"}
                onChange={(e:any) =>
                  setTextSetting((state) => ({
                    ...state,
                    quizType: e.target.value,
                  }))
                }
              />
              <span style={{ paddingLeft: "6px", fontSize: "14px" }}> H2</span>
            </span>
            <span
              className="d-flex align-start gap-5"
              style={{ marginTop: "12px" }}
            >
              <CustomRadio
                value={"heading3"}
                checked={textSettings?.quizType === "heading3"}
                onChange={(e:any) =>
                  setTextSetting((state) => ({
                    ...state,
                    quizType: e.target.value,
                  }))
                }
              />
              <span style={{ paddingLeft: "6px", fontSize: "14px" }}> H3</span>
            </span>
          </div>
          <div style={{ paddingTop: "20px" }}>
            <span style={{ fontSize: "14px", marginBottom: "17px" }}>
              Text Size
            </span>

            <Select
              style={{
                width: "150px",
                borderRadius: "4px",
                marginLeft: "40px",
              }}
              placeholder="Choose Size"
              value={textSettings.allowedAttemptsType}
              onChange={(value) => handleSelectChange(value)}
            >
              <Option value="h4">h4</Option>
              <Option value="h5">h5</Option>
              <Option value="h6">h6</Option>
            </Select>
          </div>
          <div style={{ paddingTop: "20px" }}>
            <span style={{ fontSize: "14px", marginBottom: "17px" }}>
              Font Family
            </span>

            <Select
              style={{
                width: "150px",
                borderRadius: "4px",
                marginLeft: "20px",
              }}
              placeholder="Choose Size"
              value={textSettings.allowedFontType}
              onChange={(value) => handleSelectChangeFamily(value)} // Pass the selected value directly
            >
              <Option value="Lowest">Serif Fonts</Option>
              <Option value="Average">Sans-serif Fonts</Option>
              <Option value="Highest">Monospaced</Option>
              <Option value="Matching">Script Fonts</Option>
              <Option value="EssayQuestion">Modern Fonts</Option>
            </Select>
          </div>
        </Panel>
      </Collapse>
    </div>
  );
};

export default TextSetting;
