import { Collapse, Modal } from "antd";
import React, { ChangeEvent, useRef, useState } from "react";
import CustomCheckbox from "../../../../components/inputs/checkbox/Checkbox";
import { Icon } from "@iconify/react";
import uploadImgIcon from "../../../../assets/images/upload.svg";
import {
  validateDescription,
  validateTitle,
  validateThumbnail
} from "../../../../components/shared/formValidations/validation";
import CustomButton from "../../../../components/shared/button/Button";
import ImageCropper from "../../../../components/shared/ImageCropper/ImageCrop";
import './Layout-style.css'

const { Panel } = Collapse;

interface QuizSettings {
  shuffleQuestions: boolean;
}

interface ErrorState {
  title: string;
  description: string;
  thumbnail: string;
}

interface Quiz {
  title: string;
  description: string;
  thumbnail: string;
}

const Background: React.FC = () => {
  const [quizSettings, setQuizSetting] = useState<QuizSettings>({
    shuffleQuestions: false,
  });
  const [quiz, setQuiz] = useState<Quiz>({
    title: "",
    description: "",
    thumbnail:"",
  });
  const [isBlue, setIsBlue] = useState<boolean>(false);
  const [cropedImg, setCropedimg] = useState<string>("");
  const [isHovered, setIsHovered] = useState<boolean>(false);
  const [ImgCropModalOpen, setImgCropModalOpen] = useState<boolean>(false);

  const handleToggle = (): void => {
    setIsBlue(!isBlue);
  };

  const fileInputRef = useRef<HTMLInputElement>(null);

  const [selectedColor, setSelectedColor] = useState<string>("#ff0000");

  const handleColorChange = (color: any): void => {
    setSelectedColor(color.hex);
  };

  const [error, setError] = useState<ErrorState>({
    title: "",
    description: "",
    thumbnail:"",
  });

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>): void => {
    const file = e.target.files && e.target.files[0];
    if (file) {
      // Checking file size
      if (file.size > 2 * 1024 * 1024) {
        console.error("File size exceeds 2MB limit");
        return;
      }
      const reader = new FileReader();
      reader.onload = (event: ProgressEvent<FileReader>): void => {
        const result = event.target?.result as string;
        setQuiz((preQuiz: Quiz) => ({ ...preQuiz, thumbnail: result }));
        setError((state) => ({ ...state, thumbnail: "" }));
      };
      reader.readAsDataURL(file);
    }
    setImgCropModalOpen(true);
  };

  const handleFormSubmit = (event:any) => {
    event.preventDefault();
    const newError = {
      title: validateTitle(quiz?.title) ?? "",
      description: validateDescription(quiz?.description) ?? "",
      thumbnail: validateThumbnail(quiz?.thumbnail) ?? ""
    };
    setError(newError);
  };

  const handleAssignmentGroupChange = (option:any) => {
    setQuizSetting((prevOptions:any) => ({
      ...prevOptions,
      [option]: !prevOptions[option],
    }));
  };
  return (
    <Collapse
      size="large"
      expandIconPosition="end"
      style={{ backgroundColor: "white" }}
      className="test"
      bordered={false}
    >
      <Panel header={<h4 style={{ margin: "0" }}>Background Color</h4>} key="1">
        <div style={{ gap: "10px", fontSize: "14px" }}>
          <span className="d-flex align-start gap-5">
            Green
            <CustomCheckbox
              checked={quizSettings.shuffleQuestions}
              onChange={() => handleAssignmentGroupChange("shuffleQuestions")}
            />
          </span>
        </div>
        <div style={{ gap: "10px", fontSize: "14px", marginTop: "10px" }}>
          <span className="d-flex align-start gap-5">
            <span style={{ marginRight: "10px" }}>Blue</span>
            <div
              className={`yourComponentContainer ${isBlue ? 'blue' : ''}`}
              onClick={handleToggle}
            ></div>
          </span>
        </div>
        <div style={{ padding: "15px 0px" }}>
          <h4>Custom Color</h4>
        </div>

        <div style={{ display: "flex", gap: "15px" }}>
          <span>Choose Color</span>
          <div
            className="colorPicker"
            style={{
              backgroundColor: selectedColor,
            }}
          />
          {/* we need to install react-color library-- 1st discuss with Ali Bhai then i will work on it */}
          <input
            type="color"
            id="favcolor"
            name="favcolor"
            value={selectedColor}
            onChange={handleColorChange}
            style={{ display: "none" }}
          />
        </div>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "10px",
            paddingTop: "10px",
          }}
        >
          <span
            style={{
              cursor: "pointer",
              width: "10%",
            }}
          >
            Water Mark
          </span>
          <p>FlashCard Branding</p>
        </div>
        <div className="course-details-container">
          <form onSubmit={handleFormSubmit} style={{ width: "100%" }}>
            <div className="input-details">
              <div
                className="main-wrapper"
                style={{ padding: "0px", gap: "0px" }}
              >
                <div
                  className="course-details-container"
                  style={{
                    padding: "0px",
                    gap: "0px",
                    display: "flex",
                    alignItems: "center",
                  }}
                >
                  <div className="image-container" style={{ width: "20%" }}>
                    {cropedImg ? (
                      <>
                        <label
                          className="image-upload-label"
                          htmlFor="thumbnailInput"
                        >
                          <div
                            className="cropped-image"
                            onMouseEnter={() => {
                              setIsHovered(true);
                            }}
                            onMouseLeave={() => setIsHovered(false)}
                          >
                            <img
                              src={cropedImg}
                              style={{
                                opacity: isHovered ? "50%" : "100%",
                              }}
                              alt="not found"
                            />
                            {isHovered && (
                              <div className="pencil">
                                <Icon icon="mdi:pencil-box" height="24" />
                              </div>
                            )}
                          </div>
                        </label>
                        <input
                          type="file"
                          // ref={fileInputRef}
                          accept="image/*"
                          id="thumbnailInput"
                          className="course-thumbnail"
                          onChange={handleFileChange}
                          style={{ display: "none" }}
                        />
                      </>
                    ) : (
                      <>
                        <label
                          className="course-thumbnail"
                          htmlFor="thumbnailInput"
                          style={{ textAlign: "center" }}
                        >
                          <span>
                            <img src={uploadImgIcon} alt="" />
                          </span>
                          {quiz?.thumbnail
                            ? "Change Thumbnail"
                            : "Upload Thumbnail PNG"}
                        </label>
                        <input
                          type="file"
                          ref={fileInputRef}
                          accept="image/*"
                          id="thumbnailInput"
                          className="course-thumbnail"
                          onChange={handleFileChange}
                          style={{ display: "none" }}
                        />
                      </>
                    )}
                    <div className="error-message">
                      {error.thumbnail ? error.thumbnail : " "}
                    </div>
                  </div>

                  <Modal
                    title="Crop Image"
                    open={ImgCropModalOpen}
                    onCancel={() => setImgCropModalOpen(false)}
                    footer={null}
                  >
                    <ImageCropper
                      setCropedimg={setCropedimg}
                      images={quiz?.thumbnail}
                    />
                    <CustomButton
                      variant="primary"
                      onClick={() => {
                        setImgCropModalOpen(false);
                      }}
                      customStyle={{ marginTop: "15px" }}
                    >
                      Crop & Save
                    </CustomButton>
                  </Modal>
                </div>
              </div>
            </div>
          </form>
        </div>
      </Panel>
    </Collapse>
  );
};

export default Background;
