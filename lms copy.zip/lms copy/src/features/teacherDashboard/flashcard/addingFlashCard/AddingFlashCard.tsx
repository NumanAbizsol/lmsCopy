// import { useState } from "react";
// import CustomButton from "../../../../components/shared/button/Button";
// import FlashCardUploader from "./flashCardUpload/FlashCardUploader";

// const AddingFlashCard: React.FC = () => {
// const [isFlashCardUploader,setisFlashCardUploader ] =useState<boolean>(false);
// const handleAddFlashCard=()=>{
//     setisFlashCardUploader(true);
// }
// return(
//     <>
//     <h3>Adding Flash Card</h3>
//     <div style={{marginBottom:"20px"}}>
//     {
//         (isFlashCardUploader) && <FlashCardUploader/>
//     } 
//     </div>
//     <CustomButton showPlusButton={true} variant="secondary" onClick={handleAddFlashCard}>Flash Card</CustomButton>
//     </>
// )
// }
// export default AddingFlashCard;

import React, { FormEvent, useEffect, useRef, useState } from "react";
import CustomButton from "../../../../components/shared/button/Button";
import "./AddingFlashCard.scss";
import trashIcon from "../../../../assets/images/trash.png";
import CustomInput from "../../../../components/inputs/input/Input";
import uploadImgIcon from "../../../../assets/images/upload.svg";



const FlashCardUploader = () => {
    const [flashcards, setFlashcards] = useState<any>([]);
    // console.log("flashcard", flashcards)
    const handleAddCard = () => {
        setFlashcards([...flashcards, { sideA: { term: "", imageUrl: "" }, sideB: { term: "", imageUrl: "" } }]);
    };
    // useEffect(()=>{

    // },[])
    const handleDeleteCard = (index: any) => {
        const updatedFlashcards = [...flashcards];
        updatedFlashcards.splice(index, 1);
        setFlashcards(updatedFlashcards);
    };

    const handleImageUpload = (index: any, side: string, event: any) => {
        const updatedFlashcards = [...flashcards];
        const file = event.target.files[0];

        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                if (e.target && e.target.result) {
                    updatedFlashcards[index][side].imageUrl = e.target.result;
                    setFlashcards(updatedFlashcards);
                }
            };
            reader.readAsDataURL(file);
        }
    };
    const handleInputChange = (index: any, side: string, key: string, value: any) => {
        const updatedFlashcards = [...flashcards];
        updatedFlashcards[index][side][key] = value;
        setFlashcards(updatedFlashcards);
    };
    const resetImage = (index: number, side: string) => {
        const updatedFlashcards = [...flashcards];
        updatedFlashcards[index][side].imageUrl = "";
        setFlashcards(updatedFlashcards);
    };

    return (
        <div className="flashcard-uploader">
            {flashcards.map((flashcard: any, index: any) => (
                <div key={index} className="flashcard">
                    <div style={{ justifyContent: 'space-between', display: 'flex', flexDirection: 'row' }}>
                        <span>{index + 1}</span>
                        <CustomButton className="trash-btn" onClick={() => handleDeleteCard(index)}>
                            <img src={trashIcon} alt="trash-btn"></img>
                        </CustomButton>
                    </div>
                    
                    <div className="divide-screen" style={{ justifyContent: 'space-between', gap: "20px" }}>
                    <div style={{width:"50%"}}>
                        <label className="sideName-txt">Side A</label>
                        {/* <div className="flashcard-inputs">
                            <CustomInput
                                type="text"
                                placeholder="Add Term here..."
                                value={flashcard.sideA.term}
                                onChange={(e) => handleInputChange(index, "sideA", "term", e.target.value)}
                            />
                            <div>
                                {flashcard.sideB.imageUrl ? (
                                    <div className="uploaded-image-container">
                                        <img src={flashcard.sideA.imageUrl} alt="Uploaded" style={{ maxWidth: "100px", maxHeight: "100px" }} onClick={() => resetImage(index, "sideB")} />
                                    </div>
                                ) : (
                                    <CustomButton className="uploadImg">
                                        <label htmlFor={`fileInput-${index}-sideA`} className="custom-file-input-button">
                                            <img src={uploadImgIcon}></img>
                                        </label>
                                        <input
                                            id={`fileInput-${index}-sideA`}
                                            type="file"
                                            accept="image/*"
                                            onChange={(e) => handleImageUpload(index, "sideA", e)}
                                            style={{ display: "none" }}
                                        />
                                    </CustomButton>
                                )}
                            </div>
                        </div> */}
                    </div>
                    <div className="vertical-separator"></div>
                    <div style={{width:"50%"}}>
                        <label className="sideName-txt">Side B</label>
                        <div className="flashcard-inputs">
                            <CustomInput
                                type="text"
                                placeholder="Add Term here..."
                                value={flashcard.sideB.term}
                                onChange={(e) => handleInputChange(index, "sideB", "term", e.target.value)}
                            />
                            <div>
                                {flashcard.sideB.imageUrl ? (
                                    <div className="uploaded-image-container">
                                        <img src={flashcard.sideB.imageUrl} alt="Uploaded" style={{ maxWidth: "100px", maxHeight: "100px" }} onClick={() => resetImage(index, "sideB")} />
                                    </div>
                                ) : (
                                    <CustomButton className="uploadImg">
                                        <label htmlFor={`fileInput-${index}-sideB`} className="custom-file-input-button">
                                            <img src={uploadImgIcon}></img>
                                        </label>
                                        <input
                                            id={`fileInput-${index}-sideB`}
                                            type="file"
                                            accept="image/*"
                                            onChange={(e) => handleImageUpload(index, "sideB", e)}
                                            style={{ display: "none" }}
                                        />
                                    </CustomButton>
                                )}
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            ))}
            <CustomButton showPlusButton={true} className="container-btn" variant="primary" onClick={handleAddCard}>
                Flashcard
            </CustomButton>

        </div>
    );
};

export default FlashCardUploader;