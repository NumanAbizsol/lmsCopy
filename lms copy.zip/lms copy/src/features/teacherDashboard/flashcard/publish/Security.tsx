import { useState } from "react";
import CustomRadio from "../../../../components/inputs/radio/Radio";
import { Collapse } from "antd";
const { Panel } = Collapse;


const quizTypeOptions = [
  { value: "practiceQuiz", label: "Public on the web (Open access)" },
  { value: "gradedQuiz", label: "Private access with a link ( Upgrade required )" },
  { value: "heading3", label: "Private access with a link ( Upgrade required )" },
];
const Security: React.FC = () => {
  const [textSettings, setTextSetting] = useState({
    quizType: "practiceQuiz",
    allowMultipleAttempts: false,
  });

  const handleRadioChange = (value: string): void => {
    setTextSetting((state) => ({
      ...state,
      quizType: value,
    }));
  };

 
  return (
    <div>
      <Collapse
        size="large"
        expandIconPosition="end"
        style={{ backgroundColor: "white" }}
        className="test"
        bordered={false}
      >
        <Panel header={<h4 style={{ margin: "0" }}>Security</h4>} key="1">
          <div style={{ gap: "10px" }}>
          {quizTypeOptions.map((option) => (
        <span
          key={option.value}
          className="d-flex align-start gap-5"
          style={{ marginTop: "12px" }}
        >
          <CustomRadio
            value={option.value}
            checked={textSettings?.quizType === option.value}
            onChange={() => handleRadioChange(option.value)}
          />
          <span style={{ paddingLeft: "6px", fontSize: "14px" }}>{option.label}</span>
        </span>
      ))}
          </div>
        </Panel>
      </Collapse>
    </div>
  );
};

export default Security;
