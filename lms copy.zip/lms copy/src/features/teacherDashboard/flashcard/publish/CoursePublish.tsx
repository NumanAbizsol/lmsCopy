import { Collapse } from "antd";
import React, { useState } from "react";
import CustomRadio from "../../../../components/inputs/radio/Radio";
const { Panel } = Collapse;

const quizOptions = [
  { value: "practiceQuiz", label: "Draft", description: "      Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus, quia quibusdam repellat quidem deleniti earum qui suscipit, nostrum atque, libero sit similique odit amet esse debitis adipisci blanditiis enim? Nihil saepe nisi earum assumenda quos, molestias iste beatae sed autem modi maxime a error nam, pariatur deleniti repellat et aut." },
  { value: "gradedQuiz", label: "Publish", description: "      Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus, quia quibusdam repellat quidem deleniti earum qui suscipit, nostrum atque, libero sit similique odit amet esse debitis adipisci blanditiis enim? Nihil saepe nisi earum assumenda quos, molestias iste beatae sed autem modi maxime a error nam, pariatur deleniti repellat et aut." },
  { value: "heading3", label: "Coming Soon", description: "      Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus, quia quibusdam repellat quidem deleniti earum qui suscipit, nostrum atque, libero sit similique odit amet esse debitis adipisci blanditiis enim? Nihil saepe nisi earum assumenda quos, molestias iste beatae sed autem modi maxime a error nam, pariatur deleniti repellat et aut." },
];

const CoursePublish: React.FC = () => {
  const [textSettings, setTextSetting] = useState({
    quizType: "practiceQuiz",
    allowMultipleAttempts: false,
  });


  const handleRadioChange = (value: string): void => {
    setTextSetting((state) => ({
      ...state,
      quizType: value,
    }));
  };
  return (
    <div>
      <Collapse
        size="large"
        expandIconPosition="end"
        style={{ backgroundColor: "white" }}
        className="test"
        bordered={false}
      >
        <Panel header={<h4 style={{ margin: "0" }}>Course Publish</h4>} key="1">
        <div style={{ gap: "10px" }}>
      {quizOptions.map((option) => (
        <React.Fragment key={option.value}>
          <span className="d-flex align-start gap-5" style={{ paddingRight: "10px" }}>
            <CustomRadio
              value={option.value}
              checked={textSettings?.quizType === option.value}
              onChange={() => handleRadioChange(option.value)}
            />
            <span style={{ paddingLeft: "6px", fontSize: "14px" }}>
              <b>{option.label}</b>
            </span>
          </span>
          <div style={{ width: "100%", padding: "10px 30px" }}>
            <p>{option.description}</p>
          </div>
        </React.Fragment>
      ))}
    </div>
        </Panel>
      </Collapse>
    </div>
  );
};

export default CoursePublish;
