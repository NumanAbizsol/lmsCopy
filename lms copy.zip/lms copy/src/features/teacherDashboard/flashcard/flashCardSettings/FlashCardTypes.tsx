import { Collapse } from "antd";
import React, { useState } from "react";
import CustomCheckbox from "../../../../components/inputs/checkbox/Checkbox";
const { Panel } = Collapse;


interface QuizSettings {
  shuffleAnswers: boolean;
  shaffleQuestions: boolean;
}

  const FlashCardTypes: React.FC = () => {

  const [quizSettings, setQuizSetting] = useState<QuizSettings>({
    shuffleAnswers: false,
    shaffleQuestions: false,
  });

  const handleAssignmentGroupChange = (option: keyof QuizSettings): void => {
    setQuizSetting((prevOptions: QuizSettings) => ({
      ...prevOptions,
      [option]: !prevOptions[option],
    }));
  };
  
  return (
    <Collapse
      size="large"
      expandIconPosition="end"
      style={{ backgroundColor: "white" }}
      className="test"
      bordered={false}
    >
      <Panel header={<h4 style={{ margin: "0" }}>FlashCard Types</h4>} key="1">
        <div style={{ gap: "10px", fontSize: "14px" }}>
          <span className="d-flex align-start gap-5">
            <CustomCheckbox
              checked={quizSettings.shuffleAnswers}
              onChange={() => handleAssignmentGroupChange("shuffleAnswers")}
            />
            Memories
          </span>
          <span
            className="d-flex align-start gap-5"
            style={{ marginTop: "12px" }}
          >
            <CustomCheckbox
              checked={quizSettings.shaffleQuestions}
              onChange={(e) => handleAssignmentGroupChange("shaffleQuestions")}
            />

            <span style={{ fontSize: "14px" }}> Quiz</span>
          </span>
        </div>
      </Panel>
    </Collapse>
  );
};

export default FlashCardTypes;
