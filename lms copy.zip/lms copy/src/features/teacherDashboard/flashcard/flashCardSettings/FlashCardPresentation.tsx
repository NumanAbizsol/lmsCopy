import { Collapse } from "antd";
import React, { useState } from "react";
import TextArea from "antd/es/input/TextArea";
import CustomCheckbox from "../../../../components/inputs/checkbox/Checkbox";
import { ChangeEvent } from "react";
import './flashCard-style.css'

const { Panel } = Collapse;

interface QuizSettings {
  customizeEndMessage: boolean;
  comments: boolean;
}

const FlashcardPresentation: React.FC = () => {
  const [quizSettings, setQuizSetting] = useState<QuizSettings>({
    customizeEndMessage: false,
    comments: false,
  });

  const [endMessage, setEndMessage] = useState<string>("");

  const handleAssignmentGroupChange = (option: keyof QuizSettings): void => {
    setQuizSetting((prevOptions: QuizSettings) => ({
      ...prevOptions,
      [option]: !prevOptions[option],
    }));
  };

  const handleEndMessageChange = (e: ChangeEvent<HTMLTextAreaElement>): void => {
    setEndMessage(e.target.value);
  };

  return (
    <Collapse
      size="large"
      expandIconPosition="end"
      style={{ backgroundColor: "white" }}
      className="test"
      bordered={false}
    >
      <Panel header={<h4 style={{ margin: "0" }}>Presentation</h4>} key="1">
        <div style={{ gap: "10px", fontSize: "14px" }}>
          <span className="d-flex align-start gap-5">
            <CustomCheckbox
              checked={quizSettings.customizeEndMessage}
              onChange={() =>
                handleAssignmentGroupChange("customizeEndMessage")
              }
            />
            customize End Message
          </span>
          <div
          className={`flashcard-presentation-container ${quizSettings.customizeEndMessage ? "" : "hidden"}`}
          >
            <TextArea
              value={endMessage}
              onChange={handleEndMessageChange}
              placeholder="PlaceHolder"
              autoSize={{ minRows: 6, maxRows: 10 }}
              style={{
                width: "15%",
                height: "20vh",
              }}
            />
          </div>
          <span
            className="d-flex align-start gap-5"
          >
            <CustomCheckbox
              checked={quizSettings.comments}
              onChange={() => handleAssignmentGroupChange("comments")}
            />
            <span style={{ fontSize: "14px" }}>comments</span>
          </span>
        </div>
      </Panel>
    </Collapse>
  );
};

export default FlashcardPresentation;
