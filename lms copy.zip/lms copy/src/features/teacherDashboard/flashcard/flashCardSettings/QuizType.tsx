import { Collapse, Select } from "antd";
import './flashCard-style.css'

const { Panel } = Collapse;
const QuizType: React.FC = () => {
  return (
    <Collapse
      size="large"
      expandIconPosition="end"
      style={{ backgroundColor: "white" }}
      className="test"
      bordered={false}
    >
      <Panel header={<h4 style={{ margin: "0" }}>Deck Setting</h4>} key="1">
        <Select
         className="selectContainer"
          value="Default setting"
        >
          <option value={"default Setting"}>Choose an option</option>
        </Select>
      </Panel>
    </Collapse>
  );
};

export default QuizType;
