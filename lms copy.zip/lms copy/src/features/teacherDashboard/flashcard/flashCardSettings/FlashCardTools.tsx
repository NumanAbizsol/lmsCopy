import { Collapse } from "antd";
import React, { useState } from "react";
import CustomCheckbox from "../../../../components/inputs/checkbox/Checkbox";

const { Panel } = Collapse;

interface SettingsItem {
  key: keyof QuizSettings;
  label: string;
}


interface QuizSettings {
  bookmark: boolean;
  ownFlashcard: boolean;
  flashCardSpeech: boolean;
}

const FlashcardTool: React.FC = () => {
  const [quizSettings, setQuizSetting] = useState<QuizSettings>({
    bookmark: false,
    ownFlashcard: false,
    flashCardSpeech: false,
  });

  const handleAssignmentGroupChange = (option: keyof QuizSettings):void => {
    setQuizSetting((prevOptions: QuizSettings) => ({
      ...prevOptions,
      [option]: !prevOptions[option],
    }));
  };

  const settingsData:SettingsItem[] = [
    { key: "bookmark", label: "BookMark" },
    { key: "ownFlashcard", label: "Students can add their own flashcards" },
    { key: "flashCardSpeech", label: "Flash Cards Text to speech" },
  ];
  return (
    <Collapse
      size="large"
      expandIconPosition="end"
      style={{ backgroundColor: "white" }}
      className="test"
      bordered={false}
    >
      <Panel header={<h4 style={{ margin: "0" }}>FlashCard Tools</h4>} key="1">
        <div style={{ gap: "10px", fontSize: "14px" }}>
        {settingsData.map((setting) => (
    <span
      key={setting.key}
      className="d-flex align-start gap-5"
      style={{ marginTop: "12px" }}
    >
      <CustomCheckbox
        checked={quizSettings[setting.key]}
        onChange={() => handleAssignmentGroupChange(setting.key)}
      />
      <span style={{ fontSize: "14px" }}>{setting.label}</span>
    </span>
  ))}
        </div>
      </Panel>
    </Collapse>
  );
};

export default FlashcardTool;
