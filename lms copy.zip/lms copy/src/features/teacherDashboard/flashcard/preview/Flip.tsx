import React, { useState } from "react";
import landingpageImage from "../../../../assets/images/LandingPage1.png";
import ArrowLeft from "../../../../assets/images/arrowleft.png";
import ArrowRight from "../../../../assets/images/arrowright.png";
import "./flip-style.scss";
import CustomButton from "../../../../components/shared/button/Button";

const Flip: React.FC = () => {
  const [isFlipped, setFlipped] = useState(false);

  const handleFlip = () => {
    setFlipped(!isFlipped);
  };

  return (
    <>
      <div style={{ minWidth: "79%" }}>
        <div className="flip-main-container">
          <div className={`flip-box ${isFlipped ? "flipped" : ""} ${isFlipped ? "no-hover" : ""}`}>
            <div className="flip-box-inner">
              <div className="flip-box-front">
                <img
                  src={landingpageImage}
                  alt="Paris"
                  className="flip-image-tag"
                />
              </div>
              <div
                className="flip-box-back"
              >
                <div>
                  <h2>Red</h2>
                </div>
                <div>
                  <p>An apple a day keeps the doctor away</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div
         className="flip-side-description"
        >
          <h2>What's the color of an apple?</h2>
        </div>
        <div style={{display:"flex",justifyContent:"end"}}>
        <div
          className="main-div-numbering"
        >
          <div style={{display:"flex",justifyContent:"center",alignItems:"center",gap:"10px"}}>
          <div>
          <CustomButton customStyle={{ width: "100%", height: "32px", margin: "0px" }}  className="container-btn" variant="primary" onClick={handleFlip}>Flip</CustomButton>
          </div>
          <div className="numbering-div-container">
          <span style={{ padding: "5px 17px", backgroundColor: "white", width: "fit-content", borderRadius: "6px" }}>1</span>

          <span>/</span>
          <span>5</span>

          </div>
          </div>
          <div style={{display:"flex",gap:"20px"}}>
          <div >
          <img src={ArrowLeft} alt="arrow left" className="Arrow-class-tag" />
          </div>
          <div>
          <img src={ArrowRight} alt="arrow right" className="Arrow-class-tag"/>
          </div>
          </div>
        </div>
        </div>
      </div>
    </>
  );
};

export default Flip;
