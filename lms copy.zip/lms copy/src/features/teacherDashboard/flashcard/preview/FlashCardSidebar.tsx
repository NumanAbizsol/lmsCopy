import React, { useState } from "react";
import SwitchButton from "../../../../components/shared/switchButton/SwitchButton";
import CustomButton from "../../../../components/shared/button/Button";
import Tab from "../../../../components/shared/headerAndTabs/Tabs";
import './flip-style.scss'
import CustomSelect from "../../../../components/inputs/select/Select";


interface TabData {
  name: string;
  page: React.ComponentType<any> | null;
}

interface QuizSettings {
  saveTableView: boolean;
  saveShuffle: boolean;
  saveAudio: boolean;
  [key: string]: boolean;
}

interface Setting {
  key: string;
  label: string;
}

const FlashCardSidebar: React.FC = () => {
  const [quizSettings, setQuizSetting] = useState<QuizSettings>({
    saveTableView: false,
    saveShuffle: false,
    saveAudio: false,
  });


  const settings:Setting[] = [
    { key: "saveAsNewSetting", label: "Table View" },
    { key: "saveShuffle", label: "Shuffle" },
    { key: "saveAudio", label: "Audio" },
  ];

  const [selectedTab, setSelectedTab] = useState<number>(0)


  const tabData:TabData[] = [
    { name: "Front", page: null },
    { name: "Back", page: null },
    { name: "Both", page: null }
];
  return (
    <div
      className="main-Container"
    >
      <div>
        <div
         className="main-heading"
        >
          <h4>Quiz Questions</h4>
        </div>
        <div>
          {settings.map((setting:any) => (
            <div
              key={setting.key}
             className="table-content-container"
            >
              <span className="label-container">{setting.label}</span>
              <SwitchButton
                // value={setting.key}
                value={quizSettings[setting.key]} 
                onChange={(isChecked:any) => {
                  setQuizSetting((state:any) => ({
                    ...state,
                    [setting.key]: isChecked,
                  }));
                  if (isChecked === false) {
                    setQuizSetting((state:any) => ({
                      ...state,
                      setting: "",
                    }));
                  }
                }}
              />
              
            </div>
          ))}
          <div style={{padding:"10px"}}>
                <div style={{ backgroundClip: "white" }}>
                    <Tab
                        tabData={tabData}
                        setSelectedTab={setSelectedTab}
                        selectedTab={selectedTab}
                    />
                </div>
                <div>
                    {tabData[selectedTab].page &&
                        React.createElement(
                            tabData[selectedTab].page as React.ComponentType<any>,
                            { setSelectedTab: setSelectedTab }
                        )}
                </div>
            </div>
            <div  className="table-content-container">
              <span className="label-container" style={{display:"flex",alignItems:"center"}}>Card Range</span>
              <CustomSelect variant={"single-select"} 
              options={[]}
              value="All"
              customStyle={{width:"auto",fontSize:"14px",height:"30px"}}/>
              </div>
        </div>
      </div>
      <div className="flip-container-main-div">
      <CustomButton customStyle={{width:"200px",marginBottom:"10px"}}  className="container-btn" variant="primary" showPlusButton={true}>New Question</CustomButton>
      </div>
    </div>
  );
};

export default FlashCardSidebar;
