
import React, { useState } from "react";
import AddingFlashCard from "../../teacherDashboard/flashcard/addingFlashCard/AddingFlashCard";
import Tab from "../../../components/shared/headerAndTabs/Tabs";
import GeneralForm from "../flashcard/generalInfo/GeneralForm";
import FlashCardSetting from "../flashcard/flashCardSettings/FlashCardSetting";
import Layout from "../flashcard/flashCardLayout/Layout";
import Publish from "../flashcard/publish/Publish";
import Preview from "../flashcard/preview/Preview";

interface HeaderItem {
    name: string;
    route: string;
  }

  interface TabData {
    name: string;
    page: React.ComponentType<{ setSelectedTab: React.Dispatch<React.SetStateAction<number>> }>;
  }



const tabData:TabData[] = [
    { name: "Deck Info", page: GeneralForm },
    { name: "Flashcard Settings", page: FlashCardSetting },
    { name: "Layout", page: Layout },
    { name: "Adding Flashcard", page: AddingFlashCard },
    { name: "Publish", page: Publish },
    { name: "Preview", page: Preview}
];
const FlashCardBuilder: React.FC = () => {
   const [header, setHeader] = useState<HeaderItem[][]>([
  [
    { name: "Back to Dashboard", route: "/flashCard" },
    { name: "New Quiz", route: "" },
    { name: "Landing Page", route: "" }
  ]
]);

const [selectedTab, setSelectedTab] = useState<number>(0);
    return (
            <div >
                <div style={{ backgroundClip: "white" }}>
                    <Tab
                        tabData={tabData}
                        setSelectedTab={setSelectedTab}
                        selectedTab={selectedTab}
                    />
                </div>
                <div>
                    {tabData[selectedTab].page &&
                        React.createElement(
                            tabData[selectedTab].page as React.ComponentType<any>,
                            { setSelectedTab: setSelectedTab }
                        )}
                </div>
            </div>
    );
}

export default FlashCardBuilder;

