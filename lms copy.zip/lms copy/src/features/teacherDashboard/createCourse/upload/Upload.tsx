import React, { useRef, ChangeEvent } from "react";
import { ReactComponent as Videoicon } from "../../../../assets/images/video.svg";
import { ReactComponent as Audioicon } from "../../../../assets/images/audio.svg";
import { ReactComponent as PDF } from "../../../../assets/images/Pdf.svg";
import { ReactComponent as Text } from "../../../../assets/images/Text.svg";
import { ReactComponent as Documents } from "../../../../assets/images/documents.svg";
import "./Upload.scss";
import UpdatedOrganizationDashoard from "../../../organizations/updatedOrganizationDashoard/UpdatedOrganizationDashoard";
import usePermission from "../../../../PermissionHook";

interface UploadDataProps {
  onFileSelect: (selectedFiles: FileList | null) => void;
}
const UploadData = ({ setContentType, setShowContentModel }: any) => {
  const { hasRole, hasPermissionForAction } = usePermission();

  const handleUpload = (value: string) => {
    // if(hasRole("student") && hasPermissionForAction("ADD_LESSON")){
    setContentType(value)
    setShowContentModel(false)
    // }
  }
  return (
    <div className="upload-container">
      <div className="upload-icon-wraper">
        <div className="upload-icon" onClick={() => { if (hasRole("student") && hasPermissionForAction("ADD_VIDEO-LESSON")) { handleUpload('video') } }}>
          <div className="icon">
            <Videoicon />
          </div>
          <div className="text">
            <p>Video</p>
          </div>
          {hasRole("student") && hasPermissionForAction("ADD_VIDEO-LESSON") ?
            null : <div>No Permissions!</div>}
        </div>

        <div className="upload-icon" onClick={() =>  { if (hasRole("student") && hasPermissionForAction("ADD_AUDIO_LESSON")) { handleUpload('audio') } }}>
          <div className="icon">
            <Audioicon />
          </div>
          <div className="text">
            <p>Audio</p>
          </div>
          {hasRole("student") && hasPermissionForAction("ADD_AUDIO_LESSON") ?
            null : <div>No Permissions!</div>}
        </div>
        <div className="upload-icon" onClick={() =>  { if (hasRole("student") && hasPermissionForAction("ADD_PDF_LESSON")) { handleUpload('pdf') } }}>
          <div className="icon">
            <PDF />
          </div>
          <div className="text">
            <p>pdf</p>
          </div>
          {hasRole("student") && hasPermissionForAction("ADD_PDF_LESSON") ?
            null : <div>No Permissions!</div>}
        </div>
        <div className="upload-icon" onClick={() => { if (hasRole("student") && hasPermissionForAction("ADD_TEXT_LESSON")) { handleUpload('text') } }}>
          <div className="icon">
            <Text />
          </div>
          <div className="text">
            <p>Text</p>
          </div>
          {hasRole("student") && hasPermissionForAction("ADD_TEXT_LESSON") ?
            null : <div>No Permissions!</div>}
        </div>
        <div className="upload-icon" onClick={() => { if (hasRole("student") && hasPermissionForAction("ADD_DOCUMENT_LESSON")) { handleUpload('document') } }}>
          <div className="icon">
            <Documents />
          </div>
          <div className="text">
            <p>documents</p>
          </div>
          {hasRole("student") && hasPermissionForAction("ADD_DOCUMENT_LESSON") ?
            null : <div>No Permissions!</div>}
        </div>
      </div>
    </div>
  );
};

export default UploadData;
