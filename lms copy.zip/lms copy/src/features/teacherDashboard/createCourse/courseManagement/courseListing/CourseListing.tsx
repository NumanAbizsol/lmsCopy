import React, { useEffect, useState } from "react";
import { Input, Dropdown, Menu, Checkbox, Pagination } from "antd";
import { FiFilter } from "react-icons/fi";
 import "../courseManagement.scss";

import { Icon } from "@iconify/react";

import { useDispatch, useSelector } from "react-redux";
import { ThunkDispatch } from "redux-thunk";
import { useNavigate } from "react-router-dom";
import { getCourse } from "../../../../../redux/Slices/CoursesSlice";
import { useAppSelector } from "../../../../../hooks/useTypedSelector";
import CourseCards from "../../../../../components/shared/courseCards/courseCards/CourseCards";
interface Coursedatatypes {
  title: string;
  thumbnail: string;
  section: string;
  rating: number;
  enrolledStudents: number;
}
export default function 
()

{
  const [currentpage, setCurrentPage] = useState<number>(1);
  const pagesize: number = 6;
  const startIndex = (currentpage - 1) * pagesize;
  const endIndex = startIndex + pagesize;
  const [searchinput, setSearchInput] = useState<string>("");
  const [courses, setCourses] = useState<Coursedatatypes[]>([]);
  const [sortingOption, setSortingOption] = useState("");
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(true);
  const [selectedTab, setSelectedTab] = useState(0);
  const dispatch: ThunkDispatch<any, any, any> = useDispatch();

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        await dispatch(getCourse());
      } catch (error) { }
    };
    fetchCourses();
  }, [dispatch]);
  const oureData = useAppSelector((state) => state?.course?.course)
  useEffect(() => {
    setCourses(oureData);
  }, [oureData]);
 
  return (
    <div>
            <div className="courses-cards">
              {courses[0]?.title?.length > 0 ? (
                <>
                  {courses?.map((course: any, index: any) => (
                    <CourseCards
                      course={course}
                      key={index}
                      style={{ width: "328px", height: "auto" }}
                    />
                  ))}
                  <div style={{ display: "flex", justifyContent: "center", marginTop: "20px", width: "100%", }}>
                    <Pagination
                      style={{ display: "flex", justifyContent: "center" }}
                      total={courses?.length}
                      current={currentpage}
                      pageSize={pagesize}
                      onChange={(page) => setCurrentPage(page)}
                    />
                  </div>
                </>
              ) : (
                <div className="mrgn">
{/* <CoursesCount onCreateCourseClick={onCreateCourseClick} /> */}
            <h1 className="m_t_20">No content found...</h1>

                </div>
            )}
            </div>
    </div>
  )
}
