import React, { useEffect, useState } from "react";
import { Input, Dropdown, Menu, Checkbox, Pagination } from "antd";
import { FiFilter } from "react-icons/fi";
import "./courseManagement.scss";
import Button from "../../../../components/shared/button/Button";
import CourseCard from "../../../../components/shared/courseCards/courseCards/CourseCards";
import Breadcrumb from "../breadCrumb/BreadCrumb";
import { Icon } from "@iconify/react";
import NoCourse from "./noCourseScreen/NoCourse";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../../../redux/store";
import { ThunkDispatch } from "redux-thunk";
import { getCourse } from "../../../../redux/Slices/CoursesSlice";
import { useAppSelector } from "../../../../hooks/useTypedSelector";
import CoursesCount from "../courseContainer/addNewCourse/CoursesCount";
import { useNavigate } from "react-router-dom";
import Sidebar from "../../../../components/shared/headerAndTabs/sidebar/Sidebar";
import { TabData } from "../../../../components/shared/headerAndTabs/Tabs.d";
import HeaderTabsAndNevbar from "../../../../components/shared/headerAndTabs/headerTabsAndSidebar";
import Course from "../courseContainer/course/Course";
import CourseListing from "./courseListing/CourseListing";
interface Coursedatatypes {
  title: string;
  thumbnail: string;
  section: string;
  rating: number;
  enrolledStudents: number;
}
const { Search } = Input;
const CourseManagement: React.FC = ({ onCreateCourseClick }: any) => {
  const dispatch: ThunkDispatch<any, any, any> = useDispatch();
  const navigate = useNavigate();
  // const { coursesdata, loading, error } = useSelector(
  //   (state: RootState) => state.course
  // );
  const filtervalue = [
    { key: "newlycreated", label: "Newly Created" },
    { key: "oldest", label: "Oldest" },
    { key: "toprated", label: "Top Rated" },
    { key: "topseller", label: "Top Seller" },
    { key: "lowestsale", label: "Lowest Sale" },
  ];
  const [currentpage, setCurrentPage] = useState<number>(1);
  const pagesize: number = 6;
  const startIndex = (currentpage - 1) * pagesize;
  const endIndex = startIndex + pagesize;
  const [searchinput, setSearchInput] = useState<string>("");
  // const [courses, setCourses] = useState<Coursedatatypes[]>([]);
  const [sortingOption, setSortingOption] = useState("");
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(true);
  const [selectedTab, setSelectedTab] = useState(0);
  const [course, setCourse] = useState<any>({
    title: '',
    tagLine: '',
    url: '',
    description: '',
    thumbnail: '',
  });
  // useEffect(() => {
  //   const fetchCourses = async () => {
  //     try {
  //       await dispatch(getCourse());
  //     } catch (error) { }
  //   };
  //   fetchCourses();
  // }, [dispatch]);
  // const oureData = useAppSelector((state) => state?.course?.course)
  // useEffect(() => {
  //   setCourses(oureData);
  // }, [oureData]);
  const handleSortingChange = (option: string) => {
    setSortingOption(option);
    const sortedCourses = course(option);
    console.log(sortedCourses);
    setCourse(sortedCourses);
  };
  const sortingMenu = (
    <Menu onClick={({ key }) => handleSortingChange(key)}
      className="sorting-menu-card" >
      {filtervalue.map((option) => (
        <Menu.Item key={option.key}>
          <Checkbox checked={sortingOption === option.key}>
            {option.label}
          </Checkbox>
        </Menu.Item>))} </Menu>
  );
  // const navigate = useNavigate()
  // const sortCourses = (sortingOption: string) => {
  //   if (sortingOption === "newlycreated") {
  //     return [...courses].sort((a, b) => a?.title.localeCompare(b?.title));
  //   } else if (sortingOption === "oldest") {
  //     return [...courses].sort((a, b) => b?.title.localeCompare(a?.title));
  //   }
  //   // }else if(sortingOption==="toprated"){
  //   //   return[...courses].sort((a,b)=>parseFloat(b.rating)-parseFloat(a.rating))
  //   // }
  //   return courses;
  // };
  const handlesearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchInput(e.target.value);
  };
  // const filteredcourses = courses?.filter((course: any) =>
  //   course?.title?.toLowerCase()?.includes(searchinput?.toLowerCase())
  // );
  // const visibleCourses = filteredcourses.slice(startIndex, endIndex);

  const tabData: TabData[] = [
    { name: "Course Listing", page: CourseListing },
    { name: "Add Course", page: Course },

  ];
  return (
    <div className="wraper" style={{ display: 'flex' }}>
      < div style={{ width: !isSidebarCollapsed ? "5%" : "16%" }}>
        <Sidebar isSidebarCollapsed={isSidebarCollapsed}
          setIsSidebarCollapsed={setIsSidebarCollapsed}
        />
      </div>
      <div style={{ width: "100%" }}>
        <>
          <div className="course-management-container" >
            {/* <Breadcrumb items={["Dashboard", "Courses", "My courses"]} /> */}
            <div className="course-management-header d-flex">
              <h2>Course Management</h2>
              <div className="filter-icons">
                <Dropdown overlay={sortingMenu} trigger={["click"]}>
                  <span
                    className="single-icon"
                    onClick={(e) => e.preventDefault()}>
                    <FiFilter height="24" />
                  </span>
                </Dropdown>
                <span className="multiple-icons">
                  <Icon icon="ph:list-bold" color="#10BAAC" height="24" />
                  <Icon
                    icon="material-symbols:grid-view-rounded"
                    color="#10BAAC"
                    height="24"
                  />
                </span>
              </div>
            </div>
            <div className="course-management-content">
              <div className="search-bar">
                <Search placeholder="Search..." style={{ width: 200 }} onChange={handlesearchChange} />  </div>
            </div>
            <div className="courses-tab">
              <HeaderTabsAndNevbar showTabsOnly={true} tabData={tabData} selectedTab={selectedTab} setSelectedTab={setSelectedTab} course={course} setCourses={setCourse} className="tabs-" />
            </div>

          </div>
        </>

      </div>
    </div>
  );
};

export default CourseManagement;
