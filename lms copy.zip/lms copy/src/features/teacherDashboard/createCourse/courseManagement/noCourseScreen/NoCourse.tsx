import React from 'react';
import {ReactComponent as PlusIcon} from '../../../../../assets/images/plus.svg';
import {ReactComponent as QuizIcon} from '../../../../../assets/images/quiz.svg';
import { Link, useNavigate } from 'react-router-dom';
import './NoCourse.scss';
import CustomButton from '../../../../../components/shared/button/Button';

export default function NoCourse() {
    const navigate=useNavigate()
    return (
        <div className='quizes-container'>
            <div style={{ marginTop: '20px' }} className='d-flex justify-center' >
                <div className='quiz-hero-section'>
                    <div className='d-flex justify-center'>
                        <QuizIcon />
                    </div>
                    <div className='text-center create-quiz-card-content' >
                        <h2>No Course Created Yet</h2>
                        <span className='p1 light-text'>
                            Write something here that’ll make your reader excited! You can write anything in here. Get started.
                        </span>
                        <CustomButton
                            // className='w-100'
                            variant="primary"
                            // childClasses={'d-flex align-center justify-center gap-5'}
                            onClick={() => {navigate('/Create-course')}}
                            customStyle={{ backgroundColor: '#10BAAC', color:'white',width:'100%',marginTop:'20px',justifyContent:'center'}}
                            showPlusButton={true}

                        >Create Course
                        </CustomButton>
                    </div>
                  
                </div>
            </div>
        </div>
    );
}
