import React from 'react'

const QuizSetting = () => {
  return (
    <div>QuizSetting</div>
  )
}

export default QuizSetting