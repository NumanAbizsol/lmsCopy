export type ChapterContentProps = {
    showChapterContentModal: () => void; // Define the type of showChapterContentModal
}