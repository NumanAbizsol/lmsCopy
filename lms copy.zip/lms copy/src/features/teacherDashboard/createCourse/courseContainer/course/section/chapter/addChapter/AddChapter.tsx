import React, { useEffect, FormEvent, useState } from 'react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { AddChapterProps } from './AddChapter.d';
import './AddChapter.scss';
import CustomButton from '../../../../../../../../components/shared/button/Button';
import CustomInput from '../../../../../../../../components/inputs/input/Input';
import { validateTitle, validateTagline, validateDescription } from '../../../../../../../../components/shared/formValidations/validation';
import { toast } from 'react-toastify';
import usePermission from '../../../../../../../../PermissionHook';

function AddChapter({ onsaveclick, setIsChapterModalVisible , oncancelsave}: any) {
  const [chapterTitle, setChapterTitle] = useState('');
  const [chapterDescription, setChapterDescription] = useState('');
  const [chapterTagline, setChapterTagline] = useState('');
  const [chapterSlug, setChapterSlug] = useState('');
  const [error, setError] = useState<any>({
    title: '',
    tagLine: '',
    slug: '',
    description: '',
  })
  const handleCancelBtn = () => {
    setChapterTitle('');
    setChapterDescription('');
    setChapterTagline('');
    setChapterSlug('');
    setIsChapterModalVisible(false);
  };
  const {hasRole, hasPermissionForAction}=usePermission();

  // oncancelsave(handleCancelBtn());
  const handleFormSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const newError = {
      title: validateTitle(chapterTitle) ?? "",
      tagLine: validateTagline(chapterTagline) ?? "",
      slug: validateTitle(chapterSlug) ?? "",
      description: validateDescription(chapterDescription) ?? "",
    }
    setError(newError);

    if (!newError.title && !newError.tagLine && !newError.slug && !newError.description) {
      onsaveclick(chapterTitle, chapterDescription, chapterTagline, chapterSlug);
      setChapterTitle('');
      setChapterDescription('');
      setChapterTagline('');
      setChapterSlug('');
      setIsChapterModalVisible(false);
    } else {
      toast.error("Please enter valid field data", {
        position: toast.POSITION.TOP_RIGHT,
      });
    }
  };

  return (
    <div className="add-chapter-wrapper">
      <div className="input-details">
        <form onSubmit={handleFormSubmit}>
          <div className="m_b_20">
            <label className="input-label">Chapter title</label>
            <span className={`${error.title ? "error-message" : ""}`}>*</span>
            <br />
            <CustomInput type="text" placeholder="Text" value={chapterTitle} onChange={(e) => {
              setChapterTitle(e.target.value);
              setError((prevError: any) => ({
                ...prevError,
                title: validateTitle(e.target.value) ?? "",
              }));
            }} />
            <div className="error-message">
              {error.title ? error.title : " "}
            </div>
          </div>
          <div className="m_b_20">
            <label className="input-label">Tag Line</label>
            <br />
            <CustomInput type="text" placeholder="Text" value={chapterTagline} onChange={(e) => {
              setChapterTagline(e.target.value);
              setError((prevError: any) => ({
                ...prevError,
                tagLine: validateTagline(e.target.value) ?? "",
              }));
            }} />
            <div className="error-message">
              {error.tagLine ? error.tagLine : " "}
            </div>
          </div>
          <div className="m_b_20">
            <label className="input-label">Slug</label>
            <br />
            <CustomInput type="text" placeholder="Text" value={chapterSlug} onChange={(e) => {
              setChapterSlug(e.target.value);
              setError((prevError: any) => ({
                ...prevError,
                slug: validateTitle(e.target.value) ?? "",
              }));
            }} />
            <div className="error-message">
              {error.slug ? error.slug : " "}
            </div>
          </div>
          <div className="textarea-wraper">
            <label className="input-label">Description:</label>
            <div style={{ height: 'auto' }} className="custom-quill">
              <ReactQuill
                theme="snow"
                value={chapterDescription}
                onChange={(value) => {
                  setChapterDescription(value);
                  setError((prevError: any) => ({
                    ...prevError,
                    description: validateDescription(value) ?? "",
                  }));
                }}
                style={{ border: 'none', width: '100%', background: 'none' }}
              />
            </div>
            <div className="error-message">
              {error.description ? error.description : " "}
            </div>
          </div>
          <div className="btns">
            <CustomButton
              variant="primary"
              customStyle={{}}
              childClasses="string"
              className="cancel-btn"
              onClick={handleCancelBtn}
            >
              Cancel
            </CustomButton>
            <CustomButton
              variant="primary"
              type='submit'
              customStyle={{}}
              childClasses="string"
              className="save-btn"
            >
              Save
            </CustomButton>
          </div>
        </form>
      </div>
    </div >
  );
}

export default AddChapter;
