// Section.tsx

import React, { useEffect, useState } from "react";
import { Cources } from "../Course.d";
import { Tabs, Modal } from "antd";
import { AiFillPlusCircle } from "react-icons/ai";
import CustomButton from "../../../../../../components/shared/button/Button";
import { ReactComponent as Swamp } from "../../../../../../assets/images/swap.svg";
import { ReactComponent as Edit } from "../../../../../../assets/images/edit.svg";
import { ReactComponent as DownArrow } from "../../../../../../assets/images/chevron-down.svg";
import ChapterDetail from "./chapter/chapterDetail/ChapterDetail";
import AddChapter from "./chapter/addChapter/AddChapter";
import Video from "../../../uploadedContent/Video";
import Upload from "../../../upload/Upload";
import "./Section.scss";
import "../Course.scss";
import { Icon } from "@iconify/react";
import AddVideo from "../../../../addVideo/AddVideo";
import { useAppDispatch } from "../../../../../../hooks/useTypedSelector";
import { createCourse, createSections } from "../../../../../../redux/Slices/CoursesSlice";
import CustomModal from "../../../../../../components/shared/modal/Modal";
import AddAudio from "../../../../addAudio/AddAudio";
import AddPdf from "../../../../addPdf/AddPdf";
import Tab from "../../../../../../components/shared/headerAndTabs/Tabs";
import { TabData } from "../../../../../../components/shared/headerAndTabs/Tabs.d";
import HeaderTabsAndNevbar from "../../../../../../components/shared/headerAndTabs/headerTabsAndSidebar";
import { useParams } from "react-router-dom";
import usePermission from "../../../../../../PermissionHook";


const Section = ({ course, setCourses }: any) => {
  console.log('course coming from createcourse', course)
  const [sec, setSec] = useState(0);
  const { id } = useParams();
  const [isChapterModalVisible, setIsChapterModalVisible] = useState(false);
  const [expandedSections, setExpandedSections] = useState<
    Record<number, boolean>
  >({});
  const [showTabsContent, setShowTabsContent] = useState(true);
  const [editableSectionIndex, setEditableSectionIndex] = useState<
    number | null
  >(null);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [contentType, setContentType] = useState();
  const [chapterIndex, setChapterIndex] = useState<number | null>(null);
  const [chapterContent, setChapterContent] = useState<any[]>([]);
  const [sectionIndex, setSectionIndex] = useState<number | null>(null);
  const [showContentModel, setShowContentModel] = useState(false);
  const [selectedTab, setSelectedTab] = useState(0);
  const { hasRole, hasPermissionForAction } = usePermission();
  const [isEditing, setIsEditing] = useState(false);
  const [editedTitle, setEditedTitle] = useState("");

  useEffect(() => {
    if (!course?.id) {
      setCourses({ id: id })
    }
  },[course])
  const addSection = () => {
    if (hasPermissionForAction("ADD_SECTION")) {
      console.log("add section");
      setCourses((prev: any) => {
        let predata = { ...prev };
        predata.section = [
          // ...(prev.section ?? []),
          ...(predata?.section ? predata?.section : []),
          {
            title: "Section",
            description: "",
            chapter: [],
            content: [],
          },
        ];
        console.log("section predata",predata);
        return { ...predata };
      });
      setSec(1);
      setEditableSectionIndex(
        course?.section?.length ? course?.section?.length : 0
      );
    }
  };
  useEffect(() => {
    console.log("jdghhsdkfj",course);
    // dispatch(createCourse(course))

  }, [course]);
  const saveTitle = () => {
    setSec(2);
    // dispatch(createCourse(course))

  };

  // const toggleTabsContent = (sectionIndex: number) => {
  //   setExpandedSections({
  //     ...expandedSections,
  //     [sectionIndex]: !expandedSections[sectionIndex],
  //   });
  // };

  const showChapterModal = (sectionIndex: number, chapterIndex: number) => {
    if ((hasRole("admin") || hasRole("teacher")) && hasPermissionForAction("ADD_CHAPTER")) {
      setSectionIndex(sectionIndex);
      setEditableSectionIndex(sectionIndex);
      setIsChapterModalVisible(true);
    }
  };
  const handleCancel = () => {
    setIsChapterModalVisible(false);
    setIsModalVisible(false);
  };

  const handleModal = (index: any) => {
    setSectionIndex(index);
    setShowContentModel(true);
  };
  useEffect(() => {
    console.log(contentType);
  }, [contentType]);

  const handleChapterData = (
    title: any,
    description: any,
    tagline: any,
    Slug: any
  ) => {
    setCourses((prevState: any) => ({
      ...prevState,
      section: prevState?.section?.map((sect: any, sectionIndex: any) => {
        if (sectionIndex === editableSectionIndex) {
          return {
            ...sect,
            chapter: sect?.chapter?.slice(0, editableSectionIndex).concat(
              {
                title,
                tagline,
                Slug,
                description,
                content: [],
              },
              sect?.chapter?.slice(editableSectionIndex)
            ),
          };
        }
        return sect;
      }),
    }));
    setIsChapterModalVisible(false);
    setChapterContent([]);
  };
  useEffect(() => {
    console.log(chapterIndex, sectionIndex);
  }, [chapterIndex]);
  const dispatch = useAppDispatch();
  useEffect(() => {
    // dispatch(createSections(course))
  }, [course])
  const handleSave=()=>{
    dispatch(createSections(course))
  }
  const tabData: TabData[] = [
    { name: "All Content", page: Video },
    { name: "Audio", page: null },
    { name: "Video", page: Video },
    { name: "PDF", page: null },
    { name: "Text", page: null },
    { name: "Downloads", page: null },
  ];
  return (
    <div className="main-section-wrapper">
      {!course?.section && !course?.section?.length  && (
        <>
          <div className="main-container-section row" onClick={addSection}>
            <span className="plus-span">
              <Icon icon="tabler:circle-plus" height="24" />
            </span>
            <span className="create-section">Create Section</span>
          </div>
          <span className="center"> No Section Created Yet</span>
        </>
      )}

      {sec === 1 && course?.section && (
        <div>
          {course?.section?.map(
            (section: any, index: number) =>
              editableSectionIndex === index && (
                <div className="main-container-section" key={index}>
                  <span className="section-title">Section title</span>
                  <div className="row">
                    <Swamp />
                    <input
                      className="section-input"
                      type="text"
                      value={section.title}
                      onChange={(e) =>
                        setCourses((prev: any) => ({
                          ...prev,
                          section: prev.section.map((s: any, i: number) =>
                            i === index
                              ? {
                                ...s,
                                title: e.target.value,
                              }
                              : s
                          ),
                        }))
                      }
                    />
                    <div className="btns">
                      <CustomButton
                        variant="secondary"
                        childClasses="string"
                        className="cancel-btn"
                        onClick={() => {}}
                      >
                        Cancel
                      </CustomButton>
                      <CustomButton
                        variant="primary"
                        childClasses="string"
                        className="save-btn"
                        onClick={saveTitle}
                      >
                        Save & Continue
                      </CustomButton>
                    </div>
                  </div>
                </div>
              )
          )}
        </div>
      )}
      {contentType ? (
        // Render the specific content type component
        contentType === "video" ? (
          <AddVideo
            section={course.section[sectionIndex ?? 0]}
            sectionIndex={sectionIndex}
            setContentType={setContentType}
            chapterIndex={chapterIndex}
            setCourses={setCourses}
            chapterContent={chapterContent}
            setSectionIndex={setSectionIndex}
            setChapterIndex={setChapterIndex}
            contentType={contentType}
          />
        ) : contentType === "audio" ? (
          <AddAudio
            section={course.section[sectionIndex ?? 0]}
            sectionIndex={sectionIndex}
            setContentType={setContentType}
            chapterIndex={chapterIndex}
            setCourses={setCourses}
            chapterContent={chapterContent}
            setSectionIndex={setSectionIndex}
            setChapterIndex={setChapterIndex}
            contentType={contentType}
          />
        ) : contentType === "pdf" ? (
          <AddPdf
            section={course.section[sectionIndex ?? 0]}
            sectionIndex={sectionIndex}
            setContentType={setContentType}
            chapterIndex={chapterIndex}
            setCourses={setCourses}
            chapterContent={chapterContent}
            setSectionIndex={setSectionIndex}
            setChapterIndex={setChapterIndex}
            contentType={contentType}
          />
        ) : null
      ) : (
        course?.section?.length > 0 && (
          <div className="course-section-container">
            <>
              <CustomButton
                className="add-section-btn"
                onClick={addSection}
                variant="primary"
                customStyle={{ display: "flex" }}
                childClasses=""
                buttonIcon="basil:plus-solid"
              >
                {(hasRole("admin") || hasRole("teacher")) && hasPermissionForAction("ADD_SECTION") ? <span>Section</span> : "NO Permisions!"}
              </CustomButton>
            </>
            {course?.section?.map(
              (section: any, index: number, chapterIndex: number) => {
                return (
                  // (sec > 1 || editableSectionIndex !== index) && (
                  <div className="section-wrapper" key={index}>
                    <div className="section-header">
                      <div className="section-title-wraper">
                        <Swamp />
                        <div className="title">
                              <h2 className="main-heading">{section.title}</h2>
                              <Edit style={{ fontSize: "16px" }}/>
                        </div>
                      </div>
                      <div className="section-btns">
                        <CustomButton
                          className="add-content-btn"
                          onClick={() => handleModal(index)}
                          variant="primary"
                          customStyle={{ display: "flex", gap: "5px" }}
                          childClasses=""
                          buttonIcon="basil:plus-solid"
                        >
                          <span>Lesson</span>
                        </CustomButton>
                        <CustomButton
                          className="add-chapter-btn"
                          onClick={() => {
                            showChapterModal(index, chapterIndex);
                            setEditableSectionIndex(index);
                          }}
                          variant="primary"
                          customStyle={{}}
                          childClasses=""
                          buttonIcon="basil:plus-solid"
                        >
                          {(hasRole("admin") || hasRole("teacher")) && hasPermissionForAction("ADD_CHAPTER") ? <span>Chapter</span> : "NO Permissions!"}

                        </CustomButton>
                      </div>
                    </div>
                    <div className="section-tabs">
                      {/* <Tabs defaultActiveKey="0">
                      {Object.keys(tabData).map((tabKey, tabIndex) => (
                        <TabPane tab={`${tabKey} ${tabData[tabKey as keyof typeof tabData]}`} key={tabIndex.toString()}>
                          {showTabsContent && tabIndex === 0 && expandedSections[index] ? <Video data={section.content} chData={section.chapter.content} /> : null}
                        </TabPane>
                      ))}
                    </Tabs> */}
                      {showTabsContent && (
                        <HeaderTabsAndNevbar
                          showTabsOnly={true}
                          tabData={tabData}
                          selectedTab={selectedTab}
                          setSelectedTab={setSelectedTab}
                          data={section.content}
                          chData={section.chapter.content}
                        />
                      )}
                      <span
                        className="down-arrow-icon"
                      // onClick={() => toggleTabsContent(index)}
                      // style={{
                      //   transform: `rotate(${
                      //     expandedSections[index] ? 180 : 0
                      //   }deg)`,
                      // }}
                      >
                        <DownArrow />
                      </span>
                    </div>

                    {section?.chapter &&
                      section?.chapter.map(
                        (chapter: any, chapterIndex: number) => (
                          <>
                            {" "}
                            <div
                              className="add-chapter-icon-wrapper"
                              onClick={() =>
                                showChapterModal(index, chapterIndex)
                              }
                            >
                              <div className="add-chapter-icon">
                                <Icon icon="basil:plus-solid" height="24" />
                              </div>
                            </div>
                            <ChapterDetail
                              key={chapterIndex}
                              chapter={chapter}
                              chapterIndex={chapterIndex}
                              sectionIndex={index}
                              setChapterIndex={setChapterIndex}
                              setSectionIndex={setSectionIndex}
                              handleContentModal={setShowContentModel}
                            />
                          </>
                        )
                      )}
                  </div>
                )
                // );
              }
            )}
          </div>
        )
      )}

      <Modal
        title="Add New Chapter"
        open={isChapterModalVisible}
        onCancel={handleCancel}
        width="900px"
        footer={null}
        maskClosable={false}
      >
        <AddChapter
          onsaveclick={handleChapterData}
          oncancelsave={handleCancel}
          setIsChapterModalVisible={setIsChapterModalVisible}
        />
      </Modal>
      <CustomModal
        title="Add Chapter's Content"
        open={showContentModel}
        onCancel={() => setShowContentModel(false)}
        modalContent={
          <Upload
            setContentType={setContentType}
            handleCancel={handleCancel}
            setShowContentModel={setShowContentModel}
          />
        }
      />
      <CustomButton variant="primary" onClick={() => { handleSave() }} >Save</CustomButton>

    </div>
  );
};

export default Section;
