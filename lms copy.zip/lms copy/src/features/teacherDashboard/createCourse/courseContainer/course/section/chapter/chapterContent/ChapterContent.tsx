import { useState } from 'react';
import Video from '../../../../../uploadedContent/Video';
import { TabData } from '../../../../../../../../components/shared/headerAndTabs/Tabs.d'
import './ChapterContent.scss';
import HeaderTabsAndNevbar from '../../../../../../../../components/shared/headerAndTabs/headerTabsAndSidebar';

const tabData: TabData[] = [
    { name: "Video", page: Video },
    { name: "Audio", page: null },
    { name: "PDF", page: null },
    { name: "Text", page: null },
    { name: "Downloads", page: null },
  ];

function ChapterContent({chapterContent}:any) {
    const [showTabsContent, setShowTabsContent] = useState(true);
    const [selectedTab, setSelectedTab] = useState(0);


    return (
        <div className="chapter-content-section-tabs d-flex">
            {showTabsContent && <HeaderTabsAndNevbar showTabsOnly={true} tabData={tabData} selectedTab={selectedTab} setSelectedTab={setSelectedTab} data={chapterContent}  />}
        </div>
    );
}

export default ChapterContent;
