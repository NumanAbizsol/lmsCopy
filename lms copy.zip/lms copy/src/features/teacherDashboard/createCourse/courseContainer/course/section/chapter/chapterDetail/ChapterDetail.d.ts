export type ChapterDetailProps = {
    title: string;
    description: string;
    showTabsContent: boolean;
}