// Chapter.tsx

import React, { useState, useEffect } from 'react';
import { AiFillPlusCircle } from 'react-icons/ai';
import AddChapter from './addChapter/AddChapter';
import ChapterDetail from './chapterDetail/ChapterDetail';
import { Cources, Section } from '../../../course/Course.d';

const Chapter = ({ course, setCourses }: any) => {
  const handleChapterData = ({ title='ali', description }: any) => {
    setCourses((prevState:any) => ({
      ...prevState,
      sections: prevState.sections.map((section:any, sectionIndex:any) => {
        if (sectionIndex === 0) { // Assuming you want to update the first section
          return {
            ...section,
            chapters: section.chapters.map((chapter:any, chapterIndex:any) => {
              if (chapterIndex === 0) { // Assuming you want to update the first chapter in the first section
                return {
                  ...chapter,
                   title
                };
              }
              return chapter;
            })
          };
        }
        return section;
      })
    }));
  };

  return (
    <div className="main-wrapper">
      <div className="course-details-container">
        <button onClick={()=>handleChapterData}>test</button>
        {/* <AddChapter onsaveclick={handleChapterData} oncancelsave={()=>{}} /> */}
      </div>
    </div>
  );
};

export default Chapter;
