export type AddChapterProps = {
    onsaveclick: (title: string, description: string, chapterTagline:string,chapterSlug:string) => void;
    oncancelsave: () => void;

}