import React, { useState, useEffect, useRef } from "react";
import { Icon } from "@iconify/react";
import "./CourseSetting.scss";
import {
  useAppDispatch,
  useAppSelector,
} from "../../../../../../hooks/useTypedSelector";
import {
  createCourse,
  getCourse,
} from "../../../../../../redux/Slices/CoursesSlice";
import { Checkbox, Modal } from "antd";
import { CheckboxChangeEvent } from "antd/es/checkbox";
import ReactQuill from "react-quill";
import CourseAppearance from "../courseappearance/CourseAppearance";
import UpgradePlan from "../../../../../../components/shared/upgradePlan/UpgradePlan";
import CourseProgress from "../courseprogress/CourseProgress";
import CustomButton from "../../../../../../components/shared/button/Button";
import CustomInput from "../../../../../../components/inputs/input/Input";
import CustomSelect from "../../../../../../components/inputs/select/Select";
import '../../../../../../assets/styles/generalClasses.scss';
import CustomCheckbox from "../../../../../../components/inputs/Customcheckbox/CustomCheckbox";
import ImageCropper from '../../../../../../components/shared/ImageCropper/ImageCrop'

const CourseSetting: React.FC<any> = ({ setActiveTab, setCourses, course }) => {
  console.log(course);
  const userPlan = "premium";
  const [cropedImg, setCropedimg] = useState('');
  const [ImgCropModalOpen, setImgCropModalOpen] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [selectedInstructor, setSelectedInstructor] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null); // Declare fileInputRef

  const dispatch = useAppDispatch();
  const Instructors = [
    {
      label: "Ali",
      value: "Ali",
    },
    {
      label: "Akram",
      value: "akram",
    },
  ];
  useEffect(() => {
    const fetchCourses = async () => {
      try {
        await dispatch(getCourse());
      } catch (error) {}
    };

    fetchCourses();
  }, [dispatch]);

  const courData = useAppSelector((state) => state?.course?.course);
  useEffect(() => {
    console.log(courData);
    if (courData.length > 0) {
      setCourses(...courData);
    }
    if (courData[0]?.instructor) {
      setSelectedInstructor(courData[0]?.instructor);
    }
  }, [courData]);
  console.log(course)
  const onChange = (e: CheckboxChangeEvent) => {
    console.log(`checked = ${e.target.checked}`);
  };
  const handleDescriptionChange = (value: string) => {
    setCourses((prevCourse: any) => ({ ...prevCourse, description: value }));
  };
  const handleAccessChange = (type: string, value: boolean) => {
    console.log(value)
    if (userPlan === "premium") {
      setCourses((prevCourse: any) => ({
        ...prevCourse,
        access: {
          ...prevCourse.access,
          [type]: value,
        },
      }));
    }
  };
  const handleselect=(value:any)=>{
    setSelectedInstructor(value)
    setCourses((prevCourse: any) => ({
      ...prevCourse,
      instructor: value,
    }))
  }
  const handleSavesetting=()=>{
    dispatch(createCourse(course))
    console.log('course with setting data')
  }
  const handleThumbnailChange = () => {

    fileInputRef.current?.click();
  };
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files && e.target.files[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        console.error('File size exceeds 2MB limit');
        return;
      }
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setCourses((prevCourse: any) => ({ ...prevCourse, thumbnail: result }));
      };
      reader.readAsDataURL(file);
    }
    setImgCropModalOpen(true);
  };
  return (
    <div className="main-setting">
      <div className="basic-setting">
        <Icon icon="ep:setting" height="24" />
        <h3>Basic Settings</h3>
      </div>
      <div className= "divide-screen input-section">
        <div style={{width:'100%'}}>
          <label className="input-label">Course Name</label>
          <CustomInput
            type="text"
             customClass="input-field"
            placeholder="Text"
            value={course?.title}
            onChange={(e) =>
              setCourses((prevCourse: any) => ({
                ...prevCourse,
                title: e.target.value,
              }))
            }
          />
        </div>
        <div style={{width:'100%'}}>
          <label className="input-label">Choose your instructor</label>
          <CustomSelect
            handleChange={handleselect}
            variant="single-select"
             options={Instructors}
            value={selectedInstructor}
            customClass="select-class"
          >
          </CustomSelect>
        </div>
      </div>
      <div className="input-urlfield m_t_20">
        <label className="input-label">URL</label>
        <div className="divide-screen input-urlfield">
          <CustomInput
            type="text"
            placeholder="Text"
            value={course?.url}
            onChange={(e) =>
              setCourses((prevCourse: any) => ({
                ...prevCourse,
                url: e.target.value,
              }))
            }
          />
          <Icon icon="tabler:copy" className="right-icon" height="24px" />
        </div>
      </div>
      <div className="divide-screen m_t_20 gap-10  align-center ">
        <h2>Access</h2>
        <CustomButton
          variant="primary"
          customStyle={{ gap: "3px" }}
          disabled={userPlan !== "premium"}
          buttonIcon={"ri:lock-line"}
        >
          Start
        </CustomButton>
      </div>
      <div className="divide-screen-column gap-5">
        <div className="m_t_10">
          <div className="aligin-center d-flex">
            <CustomCheckbox
              onChange={(e) => handleAccessChange("private", e.target.checked)}
              disabled={userPlan !== "premium"}
              label="Private Course"
            />
            <Icon icon="quill:info" className="info-icon" height="24px" />
          </div>
        </div>
        <div className="m_t_10">
          <div className="align-center d-flex">
            <CustomCheckbox
              onChange={(e) => handleAccessChange("hidden", e.target.checked)}
              disabled={userPlan !== "premium"}
              label="Hidden Courses"
            />
            <Icon icon="quill:info" height="24px" className="info-icon" />
          </div>
        </div>
      </div>
      <UpgradePlan planText="  to gain access to hidden and private courses." />
      <div className="d-flex m_t_10 align-center justify-start">
        <h2>Security</h2>
        <div className="d-flex align-center">
          <Checkbox
            onChange={(e) =>
              handleAccessChange("disabletextcopy", e.target.checked)
            }
            className="disable-text-checkbox"
            disabled={userPlan !== "premium"}
          />
          <span className="checkbox-label">Disable Text Copying</span>
          <Icon icon="quill:info" className="info-icon" height="24px" />
          <CustomButton
          variant="default"
          buttonIcon={"teenyicons:arrow-solid"}
          rotateArrowIcon={true}
          className="learn-button"
          >
            LEARN MORE
          </CustomButton>
        </div>
      </div>
      <div className="m_t_10">
        <h2>Delete this Course</h2>
        <p className="courses-paragraphs">
          Make sure this breakup is for real. Because once you delete a course,
          it cannot be <br />
          recovered.
          <br />
          <br />
          Note: a course can only be deleted if it has zero enrollments.
        </p>
      </div>
      <button className="delete-button d-flex align-center gap-10 justify-center m_t_10">
        <Icon
          icon="fluent:delete-24-regular"
          style={{ color: "red" }}
          height="24px"
        />
        Delete this Course
      </button>
      <h2 className="m_t_10">Course image and description</h2>
      <input
        type="file"
        ref={fileInputRef}
        accept="image/*"
        id="thumbnailInput"
        className="course-thumbnail"
        onChange={handleFileChange}
        style={{ display: 'none' }}
      />
      <div className="divide-screen m_t_10 "style={{height:'200px'}}>
        <div className="text-section">
          <h2 className="d-flex align-center justify-start gap-10">
            <Icon icon="quill:info" height="24px" />
            Course image
          </h2>
          <p className="m_t_10">Suggested Dimensions: 760x420px</p>
        </div>
        <div className='divide-screen-column'>
          
          <img src={course?.thumbnail} alt="Course" style={{width:'293px',height:'250px'}} />
          <div className="d-flex align-center justify-space-between">
            <CustomButton  variant="primary"  onClick={handleThumbnailChange} customStyle={{backgroundColor:'#ffff' ,border:'none',color:'#10baac',}} >UPLOAD</CustomButton>
            <Icon
              icon="fluent:delete-24-regular"
              style={{ color: "#10baac" }}
              height="24px"
            />
          </div>
        </div>
      </div>
      <Modal
        title="Crop Image"
        open={ImgCropModalOpen}
        onCancel={() => setImgCropModalOpen(false)}
        footer={null}
        >
        <ImageCropper setCropedimg={setCropedimg} images={course?.thumbnail} />
        <CustomButton variant="primary" onClick={() => { setImgCropModalOpen(false) }} customStyle={{ marginTop: "15px" }}> Crop & Save</CustomButton>
        </Modal>
      <div className="d-flex m_t_20">
        <div className="text-section">
          <div  className="d-flex align-center justify-start gap-10">
            
          <Icon icon="quill:info" height="24px" />
          <h2 className="image-sec">
            Course Description
          </h2>
          </div>
          
          <p className="courses-paragraphs">
            Include a brief description of your course.{" "}
            <span style={{ color: "#10baac" }}>Maximum 250 characters</span>
          </p>
          <div className="textarea-wraper">
            <label className="textarea-title">Description:</label>
            <div style={{ height: "auto" }} className="custom-quill">
              <ReactQuill
                theme="snow"
                value={course?.description}
                style={{ border: "none", width: "100%", background: "none" }}
                onChange={handleDescriptionChange}
              />
            </div>
          </div>
        </div>
      </div>
       <CourseAppearance course={course} setCourses={setCourses} />
      <CourseProgress course={course} setCourses={setCourses} /> 
      <div className="divide-screen save-cancel-btns m_t_10">
      <CustomButton variant="secondary">Reset all</CustomButton>
      <CustomButton variant="primary" onClick={handleSavesetting}>Save & Continue</CustomButton>
      </div>
    

    </div>
  );
};

export default CourseSetting;
