// ChapterDetail.tsx

import { useState } from 'react';
import { ReactComponent as Swamp } from '../../../../../../../../assets/images/swap.svg';
import { ReactComponent as Edit } from '../../../../../../../../assets/images/edit.svg';
import { ReactComponent as DownArrow } from '../../../../../../../../assets/images/chevron-down.svg';
import ChapterContent from '../chapterContent/ChapterContent';
import ReactHtmlParser from 'react-html-parser';
import './ChapterDetail.scss';
import CustomButton from '../../../../../../../../components/shared/button/Button';
const ChapterDetail = ({ chapter, handleContentModal, setChapterIndex, chapterIndex, setSectionIndex, sectionIndex }: any) => {
    const [showTabsContent, setShowTabsContent] = useState(false);
    const [arrowRotation, setArrowRotation] = useState(180);
    const toggleTabsContent = () => {
        setShowTabsContent(!showTabsContent);
        setArrowRotation(arrowRotation === 0 ? 180 : 0);
    };
    return (
        <div className="chapter-detail-wraper">
            <div className="chapter-section-header d-flex align-center justify-space-between">
                <div className="section-title-wraper d-flex align-center">
                    <Swamp />
                    <div className="chaptr-title d-flex align-center justify-space-between">
                        <div>
                            {chapter && (
                                <div className='title-detail d-flex align-center justify-center'>
                                    <h4>{chapter?.title} :</h4>
                                    <p>{ReactHtmlParser(chapter?.description)}</p>
                                </div>
                            )}
                        </div>
                        <Edit style={{ fontSize: '16px' }} />
                    </div>
                </div>
                <div className="section-btns d-flex">
                    <CustomButton
                        variant="primary"
                        customStyle={{ display:"flex", gap:"5px" }}
                        childClasses="string"
                        className="add-content-btn"
                        buttonIcon='basil:plus-solid'
                        onClick={() => { handleContentModal(true); setChapterIndex(chapterIndex); setSectionIndex(sectionIndex) }}
                    >
                         Lesson
                    </CustomButton>
                    <span
                        className="down-arrow-icon"
                        onClick={toggleTabsContent}
                        style={{ transform: `rotate(${arrowRotation}deg)` }}
                    >
                        <DownArrow />
                    </span>
                </div>
            </div>
            {showTabsContent && <ChapterContent chapterContent ={chapter.content}/>}
        </div>

    );
};

export default ChapterDetail;
