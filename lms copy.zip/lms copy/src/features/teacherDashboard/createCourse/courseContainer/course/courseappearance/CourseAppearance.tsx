import React, { useState } from "react";
import "./CourseAppearance.scss";
import { Icon } from "@iconify/react";
import UpgradePlan from "../../../../../../components/shared/upgradePlan/UpgradePlan";
import vidiologo from "../../../../../../../src/assets/images/vediologo.png";
import { Checkbox } from "antd";
import CustomButton from "../../../../../../components/shared/button/Button";
const CourseAppearance: React.FC<any> = ({ course, setCourses }) => {
  const [selectedOption, setSelectedOption] = useState("");
  const [selectedButtonColor, setSelectedButtonColor] = useState("");
  const [selectedFont, setSelectedFont] = useState("");

  console.log(course);
  const handleOptionClick = (option: any) => {
    setSelectedOption(option);
    setCourses((prevCourse: any) => ({
      ...prevCourse,
      theme: option,
    }));
  };
  const Handlebuttoncolor = (color: string) => {
    setSelectedButtonColor(color);
    setCourses((prevCourse: any) => ({
      ...prevCourse,
      buttonsColor: color,
    }));
  };
  const handleFontChange = (font: string) => {
    setSelectedFont(font);
    setCourses((prevCourse: any) => ({
      ...prevCourse,
      font: font,
    }));
  };
  const handleHideLessonType = (value: boolean) => {
    setCourses((prevCourse: any) => ({ ...prevCourse, hidelessontype: value }));
  };
  return (
    <>
      <div className="main-appearance">
        <div>
          <h3>Course Player Appearance</h3>
          <p className="courses-paragraphs">
            Change the look and feel of course player to suit your content.
          </p>
        </div>
        <h3 className="d-flex justify-center">
          -------------Set Colour------------
        </h3>
        <p className="courses-paragraphs justify-center d-flex">
          Chose a colour for buttons, Menu and accents.
        </p>
        <div className="divide-screen align-center gap-10 justify-center">
          <Icon
            icon="fontisto:ellipse"
            style={{ color: "#10baac" }}
            onClick={() => Handlebuttoncolor("#10baac")}
            height="40px"
          ></Icon>
          <Icon
            icon="fontisto:ellipse"
            style={{ color: "#ffff" }}
            onClick={() => Handlebuttoncolor("#ffff")}
            height="40px"
          ></Icon>
          <Icon
            icon="fontisto:ellipse"
            style={{ color: "#08496D" }}
            onClick={() => Handlebuttoncolor("#08496D")}
            height="40px"
          />
          <Icon
            icon="fontisto:ellipse"
            style={{ color: "#1B69E4" }}
            onClick={() => Handlebuttoncolor("#1B69E4")}
            height="40px"
          />
          <Icon
            icon="fontisto:ellipse"
            style={{ color: "#F6C0D1" }}
            height="40px"
          />
          <Icon
            icon="fontisto:ellipse"
            style={{ color: " #C7D2FE" }}
            onClick={() => Handlebuttoncolor("#C7D2FE")}
            height="40px"
          />
        </div>
        <h3 className="d-flex justify-center">
          -------------DAY/NIGHT Theme------------
        </h3>
        <div className="divide-screen-column justify-center align-center">
          <div 
            className={`option ${
              selectedOption === "alwaysLight" ? "selected" : ""
            }`}
            onClick={() => handleOptionClick("alwaysLight")}
          >
            <Icon icon="ep:setting" height="24" />
            <p>Always Light</p>
            {selectedOption === "alwaysLight" && (
              <Icon className="check-icon" icon="bi:check" height="24" />
            )}
          </div>
          <div
            className={`option ${
              selectedOption === "alwaysDark" ? "selected" : ""
            }`}
            onClick={() => handleOptionClick("alwaysDark")}
          >
            <Icon icon="ion:moon-sharp" height="24" />
            <p>Always Dark</p>
            {selectedOption === "alwaysDark" && (
              <Icon className="check-icon" icon="bi:check" height="24" />
            )}
          </div>
          <div
            className={`option ${
              selectedOption === "sameAsOS" ? "selected" : ""
            }`}
            onClick={() => handleOptionClick("sameAsOS")}
          >
            <Icon icon="jam:computer" height="24" />
            <p>Same as OS</p>
            {selectedOption === "sameAsOS" && (
              <Icon className="check-icon" icon="bi:check" height="24" />
            )}
          </div>
        </div>
        <div className="divide-screen gap-10  align-center ">
          <h2>Style</h2>
          <CustomButton
            variant="primary"
            customStyle={{ gap: "3px" }}
            buttonIcon={"ri:lock-line"}
          >
            Start
          </CustomButton>
        </div>
        <p className="courses-paragraphs">
          Changes to your site colour might take up to a minute to appear.
        </p>
        <div className="divide-screen">
          <div className="inner-container">
            <div className="divide-screen gap-10  align-center justify-center">
              <h2>Primary color</h2>
              <CustomButton  variant="primary">Default</CustomButton >
            </div>
            <p className="courses-paragraphs">
              This colour will be set as the background colour for the course
              player sidebar.
            </p>
            <select>
              <option>Color 1</option>
              <option>Color 2</option>
              <option>Color 3</option>
            </select>
          </div>
          <div className="inner-container">
            <div className="divide-screen gap-10  align-center justify-center">
              <h2>Font</h2>
              <CustomButton variant="primary">Default</CustomButton>
            </div>
            <p className="courses-paragraphs">
              This will change the default course player font.
            </p>
            <select
              value={selectedFont}
              onChange={(e) => handleFontChange(e.target.value)}
            >
              <option value="Arial">Arial</option>
              <option value="Helvetica">Helvetica</option>
              <option value="Times New Roman">Times New Roman</option>
            </select>
          </div>
        </div>
        <UpgradePlan planText=" to change background colour and font for each courses." />
        <div className="divide-screen-column">
          <div className="divide-screen justify-center gap-10 align-center">
            <h2>Lesson type icon and label</h2>
            <CustomButton
              variant="primary"
              customStyle={{ gap: "3px" }}
              buttonIcon={"ri:lock-line"}
            >
              Start
            </CustomButton>
          </div>
          <div className="divide-screen-column justify-center align-center" >
            <p className="courses-paragraphs">
              Customize how lessons will appear in the course player sidebar.
            </p>
            <Checkbox onChange={(e) => handleHideLessonType(e.target.checked)}>
             <span style={{color:'black'}}> Hide lesson type icon and label</span>
            </Checkbox>
          </div>
        </div>
        <UpgradePlan planText="to edit lesson type icon and label."></UpgradePlan>
        <div className="divide-screen">
          <div className="video-info">
            <div className="divide-screen gap-10  align-center ">
            <h2>
              Video player logo
            </h2>
            <CustomButton
                variant="primary"
                customStyle={{ gap: "3px" }}
                buttonIcon={"ri:lock-line"}
              >
                Start
              </CustomButton></div>
            <p className="courses-paragraphs">
              Your logo will appear at the center of the top
              <br /> bar. For best results, upload a PNG or JPG file <br />
              under 250kb with dimensions 240x48px (5:1) ratio.
            </p>
          </div>
          <div className="">
            <img src={vidiologo} alt="Video" />
            <div className="d-flex align-center justify-space-between">
            <CustomButton variant="primary" customStyle={{backgroundColor:'#ffff' ,border:'none',color:'#10baac'}}>UPLOAD</CustomButton>
            <Icon
              icon="ion:ellipsis-vertical"
              style={{ color: "#10baac" }}
              height="24px"
            />
          </div>
          </div>
        </div>
        <UpgradePlan planText="to customize course player logo."></UpgradePlan>
      </div>
    </>
  );
};
export default CourseAppearance;
