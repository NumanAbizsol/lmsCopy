import React from "react";
import "./CourseProgress.scss";
import CustomCheckbox from "../../../../../../components/inputs/checkbox/Checkbox";
import { Checkbox } from "antd";
import CustomButton from "../../../../../../components/shared/button/Button";
import UpgradePlan from "../../../../../../components/shared/upgradePlan/UpgradePlan";
import ReactQuill from "react-quill";
import ProgressBar from "../../../../../../components/shared/progressBar/ProgressBar";

const CourseProgress: React.FC<any> = ({ course, setCourses }) => {
  const handlelessonprogress = (value: boolean) => {
    setCourses((prevCourse: any) => ({
      ...prevCourse,
      CourseProgress: value,
    }));
  };
  const handlevideoprogress = (value: boolean) => {
    setCourses((prevCourse: any) => ({
      ...prevCourse,
      vidoProgress: value,
    }));
  };
  const handleChapterprogress = (value: boolean) => {
    setCourses((prevCourse: any) => ({
      ...prevCourse,
      chapterprogress: value,
    }));
  };
  const handleCertificateprogress = (value: boolean) => {
    setCourses((prevCourse: any) => ({
      ...prevCourse,
      courseProgress: value,
    }));
  };
  const handleCustompageCompletion = (value: boolean) => {
    setCourses((prevCourse: any) => ({
      ...prevCourse,
      courseCommpletion: value,
    }));
  };
  return (
    <div className="course-progress-wrapper">
      <div className="divide-screen-column ">
        <div className="divide-screen-column  justify-center align-center m_t_10">
          <h2>Course Progress and Completion</h2>
          <p className="courses-paragraphs">
            Customize how your students progress through and complete your
            course.
          </p>
        </div>
        <div className="divide-screen justify-space-between m_t_20">
          <div className="video-progress ">
            <Checkbox onChange={(e) => handlelessonprogress(e.target.checked)}>
              <span className="box-label"> Video Lesson Progress</span>
            </Checkbox>
            <p className="courses-paragraphs ">
              Video will auto play and also automatically
              <br /> progress to the following lesson upon
              <br />
              completion. learn more
            </p>
          </div>

          <div className="video-completion">
            <div className="divide-screen align-center">
              <Checkbox onChange={(e) => handlevideoprogress(e.target.checked)}>
                <span className="box-label">
                  Video completion (0%) required
                </span>
              </Checkbox>
              <CustomButton
                variant="primary"
                customStyle={{ gap: "3px" }}
                buttonIcon={"ri:lock-line"}
              >
                Start
              </CustomButton>
            </div>
            <p className="courses-paragraphs">
              Video will be marked completely when a<br /> student reaches your
              desired completion
              <br /> percentage. learn more
            </p>
          </div>
        </div>
        <UpgradePlan />
        <div className="divide-screen justify-space-between m_t_10">
          <div className="divide-screen-column m_t_10">
            <h2>Chapter Completion</h2>
            <div className="divide-screen align-center m_t_10">
              <Checkbox
                onChange={(e) => handleChapterprogress(e.target.checked)}
              >
                <span className="box-label">
                  Disable Chapter Completion Message
                </span>
              </Checkbox>
            </div>
            <p className="courses-paragraphs m_t_10" >
              when students complete a chapter they will
              <br /> not see the chapter completion message.
              <br /> this include prompt to review the course(if <br />
              enabled) and social sharing of chapters(if
              <br /> enabled).learn more
            </p>
          </div>
          <div className="divide-screen-column  m_t_10">
            <h2>Course Completion</h2>
            <div className="divide-screen align-center m_t_10">
              <Checkbox
                onChange={(e) => handleCertificateprogress(e.target.checked)}
              >
                {" "}
                <span className="box-label">Completion Certificate</span>
              </Checkbox>
              <CustomButton
                variant="primary"
                customStyle={{ gap: "3px" }}
                buttonIcon={"ri:lock-line"}
              >
                Start
              </CustomButton>
            </div>
            <p className="courses-paragraphs">
              Video will be marked completely when a<br /> student reaches your
              desired completion
              <br /> percentage. learn more
            </p>
          </div>
        </div>
        <UpgradePlan />
        <div className="std-course-progress m_t_20">
          <div>
            <img src={course?.thumbnail} style={{width:'293px',height:'250px'}}/>
            <ProgressBar progress={80}></ProgressBar>
          </div>
          <div>
            <h2>Course Completion</h2>
            <div className="std-completion-content m_t_10">
              <Checkbox
                onChange={(e) => handleCustompageCompletion(e.target.checked)}
              >
                {" "}
                <span className="box-label">Custom Completion Page</span>
              </Checkbox>
              <CustomButton
                variant="primary"
                customStyle={{ gap: "3px" }}
                buttonIcon={"ri:lock-line"}
              >
                Start
              </CustomButton>
            </div>
            <p className="courses-paragraphs">
              Customize the page students see when <br />
              they reach 100% completion of you courses. <br />
              this is a perfect opportunity to show them
              <br /> other courses to take or share some follow
              <br /> up material. learn more
            </p>
          </div>
        </div>
        <div className="social-sharing m_t_20">
          <h2>Social sharing </h2>
          <p className="courses-paragraphs">
            Social sharing allows your students to share a link to course
            landing page with their network.
            <br /> these settings can be changed for all courses at once in your
            learning content settings.
          </p>
          <p className="courses-paragraphs">
            your course will be added to the end of the social sharing text.
          </p>
        </div>
        <div className="social-sharing-wraper m_t_10">
          <div className="chapter-sharing">
            <div className="chapter-completion-content">
              <Checkbox
                onChange={(e) =>
                  setCourses((prevCourses: any) => ({
                    ...prevCourses,
                    enableChapterCompletionShare: e.target.checked,
                  }))
                }
              >
                {" "}
                <span className="box-label">
                  Social Sharing at Chapter Completion
                </span>
              </Checkbox>
              <CustomButton
                variant="primary"
                customStyle={{ gap: "3px" }}
                buttonIcon={"ri:lock-line"}
              >
                Default
              </CustomButton>
            </div>
            <p className="courses-paragraphs" style={{ marginTop: "10px" }}>
              Allow your students to share the course with their <br />
              network at the completion of each chapter.
            </p>
          </div>

          <div className="course-completion-sharing">
            <div className="course-completion-content-sharing">
              <Checkbox
                onChange={(e) =>
                  setCourses((precourses: any) => ({
                    ...precourses,
                    enableCoursesCompletionShare: e.target.checked,
                  }))
                }
              >
                {" "}
                <span className="box-label">
                  Social Sharing at Course Completion
                </span>
              </Checkbox>
              <CustomButton
                variant="primary"
                customStyle={{ gap: "3px" }}
                buttonIcon={"ri:lock-line"}
              >
                Default
              </CustomButton>
            </div>
            <p className="courses-paragraphs" style={{ marginTop: "10px" }}>
              Allow your students to share the course with their <br />
              network when they reach 100% completion of your
              <br /> course.
            </p>
          </div>
        </div>
        <div className="sharing-text m_t_10">
          <div className="divide-screen align-center gap-5">
            <h2>Social Sharing Text</h2>
            <CustomButton
              variant="primary"
              customStyle={{ gap: "3px" }}
              buttonIcon={"ri:lock-line"}
            >
              Default
            </CustomButton>
          </div>
          <div className="quill-lib">
            <ReactQuill
              theme="snow"
              value={course?.description}
              style={{ border: "none", width: "100%", background: "none" }}
            ></ReactQuill>
          </div>
        </div>
      </div>
    </div>
  );
};
export default CourseProgress;
