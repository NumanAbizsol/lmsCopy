import React from 'react';
import Button from '../../../../../components/shared/button/Button';
import BookIcon from '../../../../../assets/images/course.svg';
import {CoursesCountProps} from './CoursesCount.d';
import './CoursesCount.scss';
import { useNavigate } from 'react-router-dom';
const CoursesCount: React.FC<CoursesCountProps> = ({ onCreateCourseClick }) => {
  const navigate=useNavigate()
  return (
    <div className="course-detail">
      <img src={BookIcon} alt="" />
      <div className="no-of-courses">
        <h2>No course Created Yet </h2>
        <p>Write something here that’ll make your reader excited! You can write anything in here. Get started.</p>
      </div>
      <Button variant="primary"
        customStyle={{ /* your custom styles */ }}
        childClasses="string" className='btn-icon' onClick={()=>{navigate('/create-course')}}><span >+</span>Create New Course</Button>
    </div>
  );
}

export default CoursesCount;
