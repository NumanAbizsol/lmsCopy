export type CoursesCountProps = {
    onCreateCourseClick: () => void;
  }