// CourseContainer.tsx

import React, { useEffect, useState } from 'react';
import Course from './course/Course';
import CreatedCourses from '../../../rawCode/createdCourses/CreatedCourses';
import CourseSectionContainer from '../../../rawCode/courseSectionContainer/CourseSectionContainer';
import { Cources } from './course/Course.d';
import Section from './course/section/Section';

const CourseContainer = ({ courses, setCourses, setActiveTab }: any) => {

    const updateParentState = (newValue: any) => {
        console.log(newValue)
        setCourses(newValue);
    };

    return (
        <div>
            {/* <Course setActiveTab={setActiveTab} setCourses={setCourses} courses={courses} /> */}
        </div>
    );
};

export default CourseContainer;
