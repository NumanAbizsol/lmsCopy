import React, { useState, useEffect } from "react";
import "./CreateCourse.scss";
import HeaderTabsSidebar from "../../../../../components/shared/headerAndTabs/headerTabsAndSidebar";
import Section from "../course/section/Section";
import CourseSetting from "../course/setting/CourseSetting";
import {
  getCourse,
  getSections,
} from "../../../../../redux/Slices/CoursesSlice";
import {
  useAppDispatch,
  useAppSelector,
} from "../../../../../hooks/useTypedSelector";
import { useDispatch } from "react-redux";
import { ThunkDispatch } from "redux-thunk";
import { useParams } from "react-router-dom";
import PrimaryPricing from '../../../primaryPricing/PrimaryPricing';
import PublishCourse from '../../../publishCourse/PublishCourse';
import SetDripSchedule from '../../../setDripSchedule/SetDripSchedule';

interface TabData {
  name: string;
  page: React.ComponentType<any> | null;
}

function CreateCourse() {
  const dispatch: ThunkDispatch<any, any, any> = useDispatch();
  const [courseData, setCourseData] = useState<any>();
  const { id } = useParams();
  useEffect(() => {
    try {
      dispatch(getSections());
    } catch (error) {}
  }, [dispatch]);
  const  {sections}  = useAppSelector((state: any) => state.course);
  const  coursetitle  = useAppSelector((state: any) => state.course.course);
  console.log('title',coursetitle)
  const [header, setHeader] = useState([
    { name: "Back to Courses", route: "/my-courses" },
    { name: coursetitle?.title ?? "Course1", route: "" },
    { name: "Landing Page", route: "/" },
  ]);
  useEffect(() => {
    console.log(id,sections[0] )
    if(id && id !==null){
    if (sections[0]?.id === id) {
      setCourseData({ id: id, section: sections[0].section });
    }
  }
  }, [sections,id]);
  useEffect(() => {
    setHeader((prevHeader) => [
      { ...prevHeader[0] },
      { name: coursetitle[0]?.title ?? "Course1", route: "" },
      { ...prevHeader[2] },
    ]);
    console.log("course name header",coursetitle[0]?.title);
  }, [coursetitle[0]?.title]);
  
  
  const tabData: TabData[] = [
    { name: "Curriculum", page: Section },
    { name: "Settings", page: CourseSetting },
    { name: "Drip", page: SetDripSchedule },
    { name: "Pricing", page: PrimaryPricing },
    { name: "Publish", page: PublishCourse },
  ];

  return (
    <div className="create-course-wraper">
      <HeaderTabsSidebar
        header={header}
        setHeader={setHeader}
        tabData={tabData}
        course={courseData}
        setCourse={setCourseData}
      />
    </div>
  );
}

export default CreateCourse;
