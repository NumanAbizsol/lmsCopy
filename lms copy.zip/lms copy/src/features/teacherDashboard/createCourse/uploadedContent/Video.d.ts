export type Video = {
    title: string;
    duration: string;
    watchHours: string;
    thumbnailUrl: string;
};
