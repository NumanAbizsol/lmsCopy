import { useState } from 'react';
import { Carousel } from 'react-responsive-carousel';
import 'react-responsive-carousel/lib/styles/carousel.min.css';
import { ReactComponent as Dots } from '../../../../assets/images/more-vertical.svg';
import { ReactComponent as PlayIcon } from '../../../../assets/images/Play.svg';
import ReactHtmlParser from 'react-html-parser';
import { Icon } from '@iconify/react';
import './Video.scss';
import { cls } from 'react-image-crop';

function AudioVideoSection({ data }: any) {
    const [view, setView] = useState<'list' | 'carousel'>('list'); // State to toggle between list and carousel view


    const toggleView = (newView: 'list' | 'carousel') => {
        setView(newView);
    };
    const getFileName = (url: string) => {
        const parts = url.split("/");
        return parts[parts.length - 1];
    };
    console.log("video data inside video component", data);
    return (
        <div>
            <div className="view-toggle-wraper">
                <div className="view-toggle">
                    <div onClick={() => toggleView('list')}>
                        <Icon icon="humbleicons:view-list" height="24" className={view === 'list' ? 'selectedd' : 'not-selected'} style={{ marginRight: 10 }} />
                    </div>
                    <div onClick={() => toggleView('carousel')}>
                        <Icon icon="ic:round-grid-view" height="24" className={view === 'carousel' ? 'selectedd' : 'not-selected'} />
                    </div>
                </div>
            </div>

            {view === 'carousel' ? (
                <div className="carousel-view">
                    <Carousel>
                        {data?.map((video: any, index: any) => (
                            <div key={index} style={{ backgroundColor: '#FFFFFF' }}>
                                <div className="carousel-item">
                                    <div className="thumbnail-container">
                                        {/* <PlayIcon className='play-icon' />
                                        <video controls width="300px" height="150px" className='video-thumbnail'>
                                            <source src={video.thumbnail} type="video/mp4" />
                                            Your browser does not support the video tag.
                                        </video>                                    </div> */}
                                        <img src={video.thumbnail} alt="" style={{width:"300px", height:"150px"}} />
                                    </div>
                                    <div className="video-details">
                                        <div className="video-title">
                                            <h3>{video.title}</h3>
                                            {/* <Dots className="dots" />  */}
                                            <Icon icon="pepicons-pencil:dots-y" height="24" />
                                        </div>
                                        <div className="video-description">
                                            {video.description && video.description.length > 20 ? (
                                                <p>
                                                    {ReactHtmlParser(`${video.description.substring(0, 20)}...`)}
                                                </p>
                                            ) : (
                                                <p>
                                                    {ReactHtmlParser(video.description)}
                                                </p>
                                            )}
                                            {video.saveAsDraft ?
                                                <span className='draft'>Draft</span> : <span className='published'>Published</span>
                                            }
                                        </div>
                                        <div className='d-flex justify-space-between'><span>Type:</span> <span>({video.contentType})</span></div>
                                        <div className="video-infoo">
                                        <div className="attachment-container">
                                            <a href={video.attachment} target="_blank" rel="noopener noreferrer">
                                                {video.attachment ? (
                                                    <>
                                                        {video.attachment.endsWith(".pdf") && <span>PDF</span>}
                                                        {video.attachment.endsWith(".doc") || video.attachment.endsWith(".docx") && <span>DOC</span>}
                                                        {video.attachment.endsWith(".xls") || video.attachment.endsWith(".xlsx") && <span>XLS</span>}
                                                        <div className='d-flex align-center'>
                                                            <Icon icon="ant-design:file-pdf-filled" height="24" style={{ color: "red" }} />
                                                            <span>Attachment</span>
                                                        </div>
                                                    </>
                                                ) : (
                                                    <span> No Attachment!</span>
                                                )}
                                            </a>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </Carousel>
                </div>
            ) : (
                <div className="list-view">
                    {data?.map((video: any, index: any) => (
                        <div key={index} className="video-item">
                            <div className="video-details-wraper">
                                <div className="thumbnail-container">
                                    <img src={video.thumbnail} alt="" />
                                </div>
                                <div className="video-details">
                                    <div className="video-title">
                                        <h3>{video.title}</h3>
                                    </div>
                                    <div className="video-description">
                                        {video.description && video.description.length > 20 ? (
                                            <p>
                                                {ReactHtmlParser(`${video.description.substring(0, 20)}...`)}
                                            </p>
                                        ) : (
                                            <p>
                                                {ReactHtmlParser(video.description)}
                                            </p>
                                        )}
                                        {video.saveAsDraft ?
                                            <span className='draft'>Draft</span> : <span className='published'>Published</span>
                                        }
                                    </div>
                                    <div className='d-flex justify-space-between'><span>Type:</span> <span>({video.contentType})</span></div>
                                    <div className="video-infoo">
                                        <div className="attachment-container">
                                            <a href={video.attachment} target="_blank" rel="noopener noreferrer">
                                                {video.attachment ? (
                                                    <>
                                                        {video.attachment.endsWith(".pdf") && <span>PDF</span>}
                                                        {video.attachment.endsWith(".doc") || video.attachment.endsWith(".docx") && <span>DOC</span>}
                                                        {video.attachment.endsWith(".xls") || video.attachment.endsWith(".xlsx") && <span>XLS</span>}
                                                        <div className='d-flex align-center'>
                                                            <Icon icon="ant-design:file-pdf-filled" height="24" style={{ color: "red" }} />
                                                            <span>Attachment</span>
                                                        </div>
                                                    </>
                                                ) : (
                                                    <span> No Attachment!</span>
                                                )}
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="dots"> <Icon icon="pepicons-pencil:dots-y" height="24" /></div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}

export default AudioVideoSection;
