// Breadcrumb.d.ts

export type BreadcrumbProps = {
    items: string[];
  };
  