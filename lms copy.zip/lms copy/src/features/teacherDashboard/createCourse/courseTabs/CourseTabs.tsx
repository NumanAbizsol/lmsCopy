import React, { useEffect, useState } from 'react';
import { Tabs, Menu, Dropdown } from 'antd';
import CourseSectionContainer from '../../../rawCode/courseSectionContainer/CourseSectionContainer';
import { Icon } from '@iconify/react';
import './CourseTabs.scss';
import { useNavigate } from 'react-router-dom';
import CourseContainer from '../courseContainer/CourseContainer';
import Section from '../courseContainer/course/section/Section';
import Course from '../courseContainer/course/Course';
import Sidebar from '../../../../components/shared/headerAndTabs/sidebar/Sidebar';
import CourseSetting from '../courseContainer/course/setting/CourseSetting';

const { TabPane } = Tabs;

function CourseTabs({ setCourses, courses }: any) {
  const [selectedPreview, setSelectedPreview] = useState(null);
  const [activeTab, setActiveTab] = useState('generalinfo')
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(false);
console.log(courses)

  const handlePreviewClick = (type: any) => {
    setSelectedPreview(type);
  };

  const navigation = useNavigate();
  const handleNavbutton = () => {
    navigation("/my-courses")
  }

  const menu = (
    <Menu onClick={(e) => handlePreviewClick(e.key)}>
      <Menu.Item key="course">Course Preview</Menu.Item>
      <Menu.Item key="section">Section Preview</Menu.Item>
      <Menu.Item key="chapter">Chapter Preview</Menu.Item>
    </Menu>
  );

  // Updated data for tab values
  const tabData = {
    generalinfo: "General Info",
    curriculum: "Curriculum",
    bulkImporter: "Bulk Importer",
    settings: "Settings",
    drip: "Drip",
    pricing: "Pricing",
    publish: "Publish",
  };

  return (
    <>
      <div className="tabs-navbar">
        <div className="back-btn" onClick={handleNavbutton}>
          <span> <Icon icon="eva:arrow-ios-back-outline" height="24" /></span>
          Back to courses
        </div>
        <div className="course-name">
          <h3>{courses?.title}</h3>
        </div>
        <div className="preview-btn">
          <Dropdown overlay={menu} trigger={['click']}>
            <a className="ant-dropdown-link" onClick={(e) => e.preventDefault()}>
              {selectedPreview ? `Preview: ${selectedPreview}` : 'Select Preview'}
            </a>
          </Dropdown>
          <span> <Icon icon="eva:arrow-ios-forward-outline" height="24" /></span>

        </div>
      </div>
      <div style={{ display: "flex", flexDirection: "row" }}>
        {/* <div className="sidebarr"
        >
          <Sidebar
            isSidebarCollapsed={isSidebarCollapsed}
            setIsSidebarCollapsed={setIsSidebarCollapsed}
          />
        </div> */}
        <div style={{width:'100%'}}>        <Tabs activeKey={activeTab} >
          <TabPane tab={tabData.curriculum} key="curriculum">
            {courses && <Section course={courses} setCourses={setCourses} />}
          </TabPane>
          <TabPane tab={tabData.bulkImporter} key="bulkImporter">
          </TabPane>
          <TabPane tab={tabData.settings} key="settings">
          {courses && <CourseSetting course={courses} setCourses={setCourses} />}

          </TabPane>
          <TabPane tab={tabData.drip} key="drip">
          </TabPane>
          <TabPane tab={tabData.pricing} key="pricing">
          </TabPane>
          <TabPane tab={tabData.publish} key="publish">
          </TabPane>
        </Tabs>
        </div>

      </div>
    </>
  );
}

export default CourseTabs;
