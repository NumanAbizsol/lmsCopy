import React, { useEffect, useState } from "react";
import QuillEditor from "react-quill";


import {
  useAppSelector,
  useAppDispatch,
} from "../../../../hooks/useTypedSelector";
import {
  getbulkImport,
  setbulkImport,
  setEditorContent,
} from "../../../../redux/Slices/BulkImportSlice";
import "./ImportBulkFile.scss";
///component funtionality

function ImportBulkFile(props: any) {
  const [files, setFiles] = useState<File[]>([]);
  const [fileList, setFileList] = useState<string[]>([]);
  const dispatch = useAppDispatch();
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [editorContent,setEditorContentl]=useState("")

  function validateFileType(file: any) {
    const allowedTypes = ["image/jpeg", "image/png", "application/pdf"];

    if (!allowedTypes.includes(file.type)) {
      alert("Invalid file type. Please upload a JPEG, PNG, or PDF file.");
     
      setSelectedFiles([]);
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = e.target.files;

    // Validate file types
    Array.from(selectedFiles || []).forEach((file) => {
      const allowedTypes = [
        "image/png",
        "application/pdf",
        "audio/mpeg",
        "audio/wav",
        "video/mp4",
        "video/quicktime",
      ];

      if (!allowedTypes.includes(file.type)) {
        alert(
          "Invalid file type. Please upload a JPEG, PNG, PDF file,Audio or Video File."
        );

        e.target.value = "";
        return;
      }

      setFiles((prevFiles) => [...prevFiles, file]);
    });
  };

 //////
 const handleEditor=(value:any)=>{
    setEditorContentl(value)
    // dispatch(setEditorContent(editorContent))
    console.log("dispatcheditor",editorContent)
console.log("editor",value)
 }
  //////////////

  useEffect(() => {
    dispatch(getbulkImport());
  }, [dispatch]);
  const bulkimport = useAppSelector(
    (state: any) => state.bulkImportfile.fileList
  );
  useEffect(() => {
    console.log("bulkimport", bulkimport);
  }, [bulkimport]);

  ///logic of cancelbtn
  const handleRemove = (index: number) => {
    const updatedList = [...bulkimport];
    updatedList.splice(index, 1);
    setFileList(updatedList);
    dispatch(setbulkImport(updatedList));
    
    // writeToLocalStorage("selectedFiles", JSON.stringify(updatedList));
  };
  ////logic of submitbtn
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // setFileList(deserializedFiles);
    dispatch(setbulkImport(files?.map((file) => file.name)));
    dispatch(setEditorContent(editorContent))
    // dispatch(setbulkImport(files))
    console.log("ssa", (files?.map((file) => file.name)));
  };

  return (
    <>
      <h1 style={{ marginLeft: "200px" }}> Importbulk file</h1>
      <div className="bulkimportmain">
        <div className="bulkimportbtndiv">
          <button
            style={{
              width: "80px",
              height: "40px",
              marginRight: "10px",
              backgroundColor: "#10BAAC",
              color: "white",
              borderRadius: "4px",
              border: "1px solid #10BAAC ",
            }}
          >
            +Lesson
          </button>
          <button
            style={{
              width: "120px",
              height: "40px",
              marginRight: "38px",
              backgroundColor: "#10BAAC",
              color: "white",
              borderRadius: "4px",
              border: "1px solid #10BAAC ",
              fontSize: "11px",
            }}
          >
            Copy Lesson From{" "}
          </button>
        </div>
        <div className="filechoosebox">
          <form onSubmit={handleSubmit}>
            <input
              type="file"
            //   value={files}
              name="file"
              multiple
              onChange={handleChange}
            ></input>

            {/* <button type="submit">Uploade</button> */}
          </form>
        </div>

        <div className="filechoose2">
          --------------------------or-------------------------
        </div>
        <h4>discription</h4>
        <QuillEditor value={editorContent} onChange={handleEditor}/>

        <div style={{ display: "flex", justifyContent: "end" }}>
          <button
            onClick={handleSubmit as any}
            style={{
              width: "100px",
              height: "40px",
              marginRight: "38px",
              fontSize: "10px",
              marginTop: "10px",
              backgroundColor: "#10BAAC",
              color: "white",
              borderRadius: "4px",
              border: "1px solid #10BAAC ",
            }}
            type="submit"
          >
            Save & Continue
          </button>
        </div>

        <div>
          <div
            style={{
              display: "flex",
              paddingLeft: "200px",
              fontSize: "30px",
              paddingTop: "50px",
            }}
          >
            File List
          </div>

          <div
            style={{
              display: "flex",
              justifyContent: "center",
              gap: "10PX",
              borderRadius: "8px",
              marginBottom: "100px",
              backgroundColor: "white",
              width: "52%",
              marginLeft: "200px",
              boxShadow: "0 6px 4px rgba(0, 0, 0, 0.1)",
            }}
          >
            <ul>
             
  {Array.isArray(bulkimport) && bulkimport.length > 0
    ? bulkimport.map((fileName: any, index: any) =>{
                console.log("map", fileName);
                return (
                  <div
                    style={{
                      display: "flex",
                      marginBottom: "10px",
                      backgroundColor: "white",
                    }}
                    key={index}
                  >
                    <li>{fileName}</li>
                    <div>
                      {" "}
                      <button
                        style={{
                          marginLeft: "20px",

                          borderRadius: "4px",
                          backgroundColor: "#10BAAC",
                          color: "white",
                          flexShrink: 0,
                        }}
                        onClick={() => handleRemove(index)}
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                );
              }):''}
            </ul>
          </div>
        </div>
      </div>
    </>
  );
}

export default ImportBulkFile;
