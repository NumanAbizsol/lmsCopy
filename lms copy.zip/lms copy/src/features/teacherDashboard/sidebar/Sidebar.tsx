import React from "react";
import SidebarItems from "./sidebarItems/sidebarItems/SidebarItems";
import "./Sidebar.scss";
import UpgradePlan from "../upgradePlan/UpgradePlan";
import Logo from "../../../assets/images/urqaalogo.png";
import Ulogo from "../../../assets/images/Ulogo.svg";
const Sidebar = ({ isSidebarCollapsed, setIsSidebarCollapsed }: any) => {
  console.log(isSidebarCollapsed);
  const handlesidebarCollapse = () => {
    setIsSidebarCollapsed(true);
  };
  const handleToggleSidebar = () => {
    setIsSidebarCollapsed((state: any) => !state);
  };
  return (
    <div className="student-sidebar-container">
      <div className="student-sidebar-wrapper">
        <div
          className="header-left"
          style={
            isSidebarCollapsed
              ? {
                  width: "95%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  padding: "2px 12px 2px 32px",
                }
              : {
                  width: "95%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  padding: "0px",
                }
          }
        >
          <div className="logo-container">
            <img src={isSidebarCollapsed ? Logo : Ulogo} alt="" />
          </div>
          {isSidebarCollapsed && (
            <div className="toggle-btn" onClick={handleToggleSidebar}>
              |||
            </div>
          )}
        </div>
        {!isSidebarCollapsed && (
          <div className="test" onClick={handlesidebarCollapse}>
            |||
          </div>
        )}
        <SidebarItems isSidebarCollapsed={isSidebarCollapsed} />
        {isSidebarCollapsed && <UpgradePlan />}
      </div>
    </div>
  );
};

export default Sidebar;
