import React, { useState } from "react";
import Header from "../header/Header";
import NotificationPanel from "../notifications/notificationPanel/NotificationsPanel";
import CourseCards from "../../../components/shared/courseCards/courseCards/CourseCards";
import CreateCourse from "../createCourse/courseContainer/createCourse/CreateCourse";
import "./Dashboard.scss";
import Content from "../content/Content";
import SidebarItems from "../../../components/shared/headerAndTabs/sidebar/sidebarItems/sidebarItems/SidebarItems";
import Sidebar from "../../../components/shared/headerAndTabs/sidebar/Sidebar";

function Dashboard() {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(true);
  return (
    <div style={{display:'flex',flexDirection:'row'}}>

      <Sidebar
        isSidebarCollapsed={isSidebarCollapsed}
        setIsSidebarCollapsed={setIsSidebarCollapsed}
      />
      <div
        className="dashboard"
      >
        <div
          className="main-dashboard-container"
        >
          <div
            // className="teacher-dashboard-sidebar"
            style={{ width: !isSidebarCollapsed ? "5%" : "16%" }}
          >

          </div>
          <div className="teacher-dashboard-content">
            {/* <Header /> */}

            <Content />
            {/* <CourseCards style={{ width: "350px", height: "auto" }} /> */}
          </div>
          {/* <div className="teacher-dashboard-notifications">
          <NotificationPanel />
        </div> */}
        </div>
      </div>
    </div>

  );
}

export default Dashboard;
