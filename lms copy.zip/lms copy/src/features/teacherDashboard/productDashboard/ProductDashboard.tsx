import React from 'react';
import './ProductDashboard.scss'; 
import { useNavigate } from 'react-router-dom';

export interface ProductCard {
  heading: string;
  text: string;
  imgSrc: any;
  path:string;
}

interface ProductDashboardProps {
  products: ProductCard[];
}


const ProductDashboard: React.FC<ProductDashboardProps> = ({ products }) => {
  const navigate=useNavigate()
  const handleCardClick=(e:string)=>{
    console.log('clicked')
    navigate(e)
  }
  return (
    <div className="product-dashboard-wrapper d-flex justify-center">
      {products.map((product, index) => (
        <div onClick={(e:any)=>handleCardClick(product.path)} className="product-card d-flex align-center justify-space-between m_b_20 p-30" key={index} >
          <div className="card-content d-flex flex-column">
            <h3 className="card-heading main-heading">{product.heading}</h3>
            <p className="card-text p">{product.text}</p>
          </div>
          <img className="card-img" src={product.imgSrc} alt={`Product ${index + 1}`} />
        </div>
      ))}
    </div>
  );
};

export default ProductDashboard;
