import "./DripSchedule.css";
import { Collapse, DatePicker, Switch } from "antd";
import React, { useState } from "react";
const { Panel } = Collapse;

const DripSchedule = () => {
  const [isSwitchOn, setIsSwitchOn] = useState(true);

  const DripScheduleData = [
    {
      heading: "Student enrollment date",
      para: "When students access the course for the first time",
    },

    {
      heading: "On a specific date",
      para: "Lorem Ipsum is simply dummy text of the printing bry bryy .",
    },
  ];

  return (
    <>
      <div className="DripSchedule-container1">
        <h1>Set drip schedule</h1>
        <p>
          A drip schedule allows you to control when students will have access
          to your content, whether you have a specific launch date or want to
          limit the amount of lessons that can be viewed in a certain time
          period.
        </p>

        <div className="DripSchedule-inner">
          <h1>Released By:</h1>

          <div className="DripSchedule-content">
            {DripScheduleData.map((row, index) => (
              <div key={index} className="DripSchedule-item">
                <div className="DripSchedule-left">
                  <div className="DripSchedule-header">
                    <input type="radio" name="organizationRadio" />
                    &nbsp;
                    <h2>{row.heading}</h2>
                  </div>
                  <p style={{ marginLeft: "24px" }}>{row.para}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* <div className="dripSchedule-container2">
        <Collapse accordion expandIconPosition="right">
          <Panel
            key="1"
            header={<div style={{ fontWeight: "bold" }}>Sec 1</div>}
          >
            <h1>Content</h1>

            {["Audio", "Video", "Pdf"].map((contentType, index) => (
              <div key={index}>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    background: "#e6f7ff",
                    padding: "10px",
                  }}
                >
                  <div
                    style={{ flex: 1, marginRight: "10px", fontSize: "17px" }}
                  >
                    {contentType}
                  </div>

                  <DatePicker style={{ marginLeft: "10px" }} />
                </div>
                <hr />
              </div>
            ))}
          </Panel>
        </Collapse>
      </div> */}

      <div className="dripSchedule-container2">
        <div className="Accordion1-con2">
          <Collapse accordion expandIconPosition="right">
            <Panel
              key="1"
              header={
                <div style={{ fontSize: "18px", color: "#081735" }}>
                  <b>Course Drip</b>
                </div>
              }
              style={{
                backgroundColor: "white",
                marginBottom: "8px",
              }}
            >
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                }}
              >
                <div style={{ display: "flex", alignItems: "center" }}>
                  {/* <Switch style={{ marginLeft: "20px" ,handleBg:"green"}} /> */}
                  <Switch
                    style={{
                      marginLeft: "20px",
                      backgroundColor: isSwitchOn ? "grey" : "#00A171",
                    }}
                    checked={isSwitchOn}
                    onChange={(checked) => setIsSwitchOn(checked)}
                  />

                  <span style={{ marginLeft: "10px" }}>Yes</span>
                </div>
                <div>
                  <DatePicker />
                </div>
              </div>
            </Panel>
          </Collapse>
        </div>
      </div>
    </>
  );
};

export default DripSchedule;
