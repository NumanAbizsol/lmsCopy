import React, { useState } from "react";
import Logo from "../../../assets/images/urqaalogo.svg";
import Profile from "../../../assets/images/videobg.png";
import Ulogo from "../../../assets/images/Ulogo.svg";
import {
  SearchOutlined,
  MessageOutlined,
  SettingOutlined,
  ProfileOutlined,
  LogoutOutlined,
} from "@ant-design/icons";
import "./Header.scss";
import { Dropdown, Menu, Space } from "antd";
import MenuItem from "antd/es/menu/MenuItem";

const Header = ({ setIsSidebarCollapsed, isSidebarCollapsed }: any) => {
  const [showprofilemodel, setShowprofilemodel] = useState(false);

  const handleToggleSidebar = () => {
    setIsSidebarCollapsed((state: any) => !state);
  };
  const handleshowprofilemodel = () => {
    setShowprofilemodel(!showprofilemodel);
  };
  const profileMenu = (
    <div style={{marginTop:'30px'}}>

    <Menu>
      <Menu.Item key="settings" icon={<ProfileOutlined />}>
        My Profile
      </Menu.Item>
      <Menu.Item key="Language" icon={<ProfileOutlined />}>
        Language
      </Menu.Item>
      <Menu.Item key="Display" icon={<ProfileOutlined />}>
        Display Mode
      </Menu.Item>
      <Menu.Item key="settings" icon={<SettingOutlined />}>
        Settings
      </Menu.Item>
      <Menu.Item key="logout" icon={<LogoutOutlined />}>
        Logout
      </Menu.Item>
    </Menu>
    </div>

  );
  console.log(showprofilemodel);
  return (
    <div className="teacher-header">
      {/* <div className="header-left">
                <div className="logo-container">
                    <img src={isSidebarCollapsed?Logo:Ulogo} alt="" />
                    
                </div>
          {isSidebarCollapsed && <div className="toggle-btn" onClick={handleToggleSidebar}>|||</div>}
            </div> */}
      <div className="header-right">
        <div className="msgs-notification-bar">
          <MessageOutlined className="notifi-icon" />
          <span className="notifi-value">10</span>
        </div>
        <div className="settings-notifications">
          <SettingOutlined className="notifi-icon" />
          <span className="notifi-value">13</span>
        </div>
        <div className="header-vertical-bar">
          <span>|</span>
        </div>
        <div className="user-profile">
          <span className="profile-name">Hello Nouman</span>
          <img
            src={Profile}
            alt="User Avatar"
            className="profile-img"
            onClick={handleshowprofilemodel}
          />
        </div>
      </div>

      {showprofilemodel && (
        <Dropdown
          overlay={<Space>{profileMenu}</Space>}
          placement="bottomRight"
          trigger={['click']}
          visible={showprofilemodel}
        >
          <div></div>
        </Dropdown>
      )}
    </div>
  );
};

export default Header;
