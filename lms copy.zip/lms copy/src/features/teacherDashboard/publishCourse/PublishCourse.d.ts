// CoursePublishState.ts

export interface PublishCourseProps {
    status: 'draft' | 'publish';
    proTip: string;
    anticipationText: string;
  }
  