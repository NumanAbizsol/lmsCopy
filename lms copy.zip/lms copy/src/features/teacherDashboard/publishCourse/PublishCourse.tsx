import React, { useState } from "react";
import "./PublishCourse.scss"; //
import { useDispatch, useSelector } from "react-redux";
import { updateOrganizationData } from "../../../redux/Slices/CoursesSlice";
import { Link, useNavigate } from "react-router-dom";
import CustomRadio from "../../../components/inputs/radio/Radio";
import CustomButton from "../../../components/shared/button/Button";

import {PublishCourseProps} from "./PublishCourse.d"
const PublishCourse: React.FC = () => {
  const nav=useNavigate()
  const dispatch=useDispatch()
  const [publishState, setPublishState] = useState<PublishCourseProps>({
    status: "draft",
    proTip: "", 
    anticipationText: "", 
  });

  const handleStatusChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newStatus= event.target.value as "draft" | "publish";
    setPublishState({
      ...publishState,
      status:newStatus
    });
  };
  const {course} = useSelector((state:any) => state.course);
console.log(course.publishState);

const handleRedux=()=>{

  dispatch(updateOrganizationData({ course: { publishState: publishState } }));
}
const handleNavigate=()=>{
  nav('/primary-pricing')
}
console.log("publishState",publishState)
  return (
    <div className="course-publish-container">
      <h2>Publish</h2>
      <br />
      <div className="radio-group">
        <div className="radiogroup1">
          <div className="radiogroup2">
            <CustomRadio
            
              name="status"
              value="draft"
              checked={publishState.status === "draft"}
              onChange={handleStatusChange}
            />
            <label htmlFor="draft">
              <h4 className="heading4">Draft</h4>
            </label>
          </div>
          <p className="para">
            Students cannot purchase or enroll in this course. For students that
            are already enrolled, this course will not appear on their Student
            Dashboard.
          </p>
        </div>
        <div className="radiogroup1">
          <div className="radiogroup2">
            <CustomRadio
             
              checked={publishState.status === "publish"}
              onChange={handleStatusChange}

              name="status"
          value="publish"
          
         
            />
            <label htmlFor="publish">
              <h4 className="heading4">Publish</h4>
            </label>
          </div>
          <p className="para">
            Students can purchase, enroll in, and access the content of this
            course. For students that are enrolled, this course will appear on
            their Student Dashboard.
          </p>
        </div>
      </div>

      <hr className="line" />

      <div className="text-input-group">
        <h4 className="heading4">
          Anticipating a large number of sign-ups at launch?
        </h4>
        <p className="para1">
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry. Lorem Ipsum has been the industry's standard dummy text ever
          since the 1500s, when an unknown printer took a galley of type and
          scrambled it to make a type specimen book. It has survived not only
          five centuries, but also the leap into electronic typesetting,
          remaining essentially unchanged

        </p>
        <hr className="line" />

        <div className="radiogroup1">
          <div className="radiogroup2">
            <CustomRadio
             
              name="status"
              // value="publish"
              // checked={publishState.status === "publish"}
              // onChange={handleStatusChange}
            />
            <label htmlFor="publish">
              <h4 className="heading4">Pro tip</h4>
            </label>
          </div>
          <p className="para">
            Lorem Ipsum is simply dummy text of the printing and typesetting
            industry. Lorem Ipsum has been the industry's standard dummy text
            ever since the 1500s, when an unknown printer took a galley of type
            and scrambled it to make a type specimen book. It has survived not
            only five centuries, but also the leap into electronic typesetting,
            remaining essentially unchanged
            <br /><br />
            <Link to={"/"} className="lern">
            {" "}
            Learn more ... 
          </Link>
          </p>
       
         
        </div>
      </div>

       <div className="footerBtn">
   <CustomButton variant="primary" onClick={handleRedux} className="primaryBtn">save redux1</CustomButton>
    <CustomButton variant="secondary" onClick={handleNavigate} className="secondaryBtn">Next</CustomButton>
   </div>

    </div>
  );
};

export default PublishCourse;
