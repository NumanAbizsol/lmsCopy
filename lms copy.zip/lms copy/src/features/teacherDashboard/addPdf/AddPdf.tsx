import React, { useState, ChangeEvent, useRef, useEffect, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import ReactQuill from "react-quill";
import pdfUpload from "../../../assets/images/pdfupload.png";
import AddVideoSetting from "../../../assets/images/addVideoSetting.png";
import { checkboxData } from "../../../constants/Constants";
import CustomButton from "../../../components/shared/button/Button";
import "./AddPdf.scss";
import CustomInput from "../../../components/inputs/input/Input";
import CustomCheckbox from "../../../components/inputs/Customcheckbox/CustomCheckbox";
import uploadImgIcon from "../../../assets/images/upload.svg"
import browserupload from "../../../assets/images/videouploadicon.svg";

const MAX_FILE_SIZE_MB = 50;

const AddPdf = ({ section, setCourses, sectionIndex, chapterIndex, setContentType, setChapterIndex, setSectionIndex,contentType}: any) => {
  const [title, setTitle] = useState<string>("");
  const [description, setDescription] = useState<string>("");
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [fileType, setFileType] = useState<string | null>(null);
  const [fileSizeError, setFileSizeError] = useState<string | null>(null);
  const [fileTypeError, setFileTypeError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [saveAsDraft, setSaveAsDraft] = useState<boolean>(false);
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [imageFileSizeError, setImageFileSizeError] = useState<string | null>(null);
  const [thumbnail, setThumbnail] = useState<string | null>(null);
  const [imageFileTypeError, setImageFileTypeError] = useState<string | null>(null);
  const imgfileInputRef = useRef<HTMLInputElement>(null);




  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];

    const allowedFileTypes = [
      "application/pdf",
      "application/msword",
      "text/plain",
    ];
    const disallowedFileTypes = ["image", "audio", "video"];

    if (allowedFileTypes.includes(file.type)) {
      const fileSizeInMB = file.size / (1024 * 1024);

      if (fileSizeInMB > MAX_FILE_SIZE_MB) {
        setFileSizeError("File size exceeds the maximum allowed size (50 MB)");
        setFileTypeError(null);
        return;
      }

      setFileSizeError(null);

      setUploadedFile(file);
      setFileType(file.type.split("/")[1]);
      setFileTypeError(null);
    } else if (disallowedFileTypes.some((type) => file.type.includes(type))) {
      setUploadedFile(null);
      setFileTypeError("Image, audio, and video files are not allowed");
    } else {
      setUploadedFile(null);
      setFileTypeError(
        "Only PDF, Word, and text files (.pdf, .doc, .txt) are allowed"
      );
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: ".pdf, .doc, .txt",
    maxFiles: 1,
  } as any);

  const handleTitleChange = (e: ChangeEvent<HTMLInputElement>) => {
    setTitle(e.target.value);
  };

  const handleDescriptionChange = (value: string) => {
    setDescription(value);
  };

  useEffect(() => {
    if (uploadedFile) {
      fileInputRef.current?.click();
    }
  }, [uploadedFile]);

  const handleImageUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const imageFile = e.target.files?.[0];

    if (imageFile) {
      const imageSizeInMB = imageFile.size / (1024 * 1024);

      if (imageSizeInMB > MAX_FILE_SIZE_MB) {
        setImageFileSizeError("File size exceeds the maximum allowed size (50 MB)");
        setImageFileTypeError(null);
        return;
      }

      setImageFileSizeError(null);

      // Check if the file type is image (png or jpg)
      if (imageFile.type.startsWith("image/")) {
        const reader = new FileReader();

        reader.onload = () => {
          setThumbnail(reader.result as string); // Assuming only one thumbnail is allowed
          setUploadedImages([reader.result as string]);
        };

        reader.readAsDataURL(imageFile);
        setImageFileTypeError(null);
      } else {
        setImageFileTypeError("Only PNG and JPG images are allowed");
        setUploadedImages([]);
      }
    }
  };


  const handleRemoveImage = (index: number) => {
    const updatedImages = [...uploadedImages];
    updatedImages.splice(index, 1);
    setUploadedImages(updatedImages);
  };

  const saveData = (e: any) => {
    e.preventDefault();
    console.log(title, uploadedFile, description,contentType, "hhhhhhhhhhhhhhhh");

    if (chapterIndex === null) {
      setCourses((prevState: any) => ({
        ...prevState,
        section: prevState.section?.map((sect: any, currentIndex: number) => {
          if (currentIndex === sectionIndex) {
            return {
              ...sect,
              content: [
                ...sect.content,
                {
                  pdf: uploadedFile,
                  thumbnail:thumbnail,
                  title: title,
                  description: description,
                  saveAsDraft:saveAsDraft,
                  contentType,
                },
              ],
            };
          }
          return sect;
        }),
      }));
    } else {
      setCourses((prevCourse: any) => {
        const newCourse = { ...prevCourse };
        if (
          newCourse.section &&
          newCourse.section[sectionIndex] &&
          newCourse.section[sectionIndex].chapter &&
          newCourse.section[sectionIndex].chapter[chapterIndex]
        ) {
          newCourse.section[sectionIndex].chapter[chapterIndex].content = [
            ...newCourse.section[sectionIndex].chapter[chapterIndex].content,
            { title, pdf: uploadedFile, description,saveAsDraft,thumbnail,contentType },
          ];
        }
        return newCourse;
      });
    }

    setChapterIndex(null);
    setSectionIndex(null);
    setContentType('');
    setSaveAsDraft(false);
  };

  return (
    <>
      <div className="new-add-pdf-container-main">
        <div className="new-add-pdf-container">
          <h1 className="new-heading-text-pdf">Add Pdf</h1>
          <CustomCheckbox  label="Save it as draft"  onChange={(e) => setSaveAsDraft(e.target.checked)}/>
          <div {...getRootProps()} className="new-upload-file">
            <input {...getInputProps()} ref={fileInputRef} />
            {uploadedFile ? (
              <>
                {fileType === "pdf" ? (
                  <div>
                    <p>File uploaded: {uploadedFile.name}</p>
                    <button
                      className="open-file-button"
                      onClick={() =>
                        window.open(URL.createObjectURL(uploadedFile))
                      }
                    >
                      Open File
                    </button>
                  </div>
                ) : (
                  <div>
                    <p className="error-message">{fileTypeError}</p>
                  </div>
                )}
              </>
            ) : (
              <>
                <div className="new-image-container">
                  <img
                    src={pdfUpload}
                    alt="Uploaded"
                    className="new-uploaded-image"
                  />
                </div>
                <h1>Browse Files to upload</h1>
                {isDragActive && <p>Drop the files here ...</p>}

                {fileTypeError && (
                  <p className="error-message">{fileTypeError}</p>
                )}
                {fileSizeError && (
                  <p className="error-message">{fileSizeError}</p>
                )}
              </>
            )}
          </div>
          <form>
          <div className="thumbnail-image-upload d-flex align-center gap-10 m_t_20" onClick={() => imgfileInputRef.current?.click()}>
              {uploadedImages.length === 0?(
              <div className="img-picker d-flex-column justify-center align-center p-50" >
                <input
                  {...getRootProps()}
                  {...getInputProps()}
                  ref={imgfileInputRef}
                  onChange={handleImageUpload}
                  accept=".png, .jpg"
                  multiple={false}  // Allow only one file to be selected
                />
                <img src={browserupload} alt="Uploaded" className="new-uploaded-image" />
                <b>Upload Thumbnail</b>
                <p> PNG,JPG (max. 800x400px)</p>
              </div>
              ):(
              <div className="new-image-containerr d-flex align-center justify-center gap-10" >
              
                  <div className="uploaded-image-container d-flex">
                    <img src={uploadedImages[0]} alt={`Thumbnail`} className="uploaded-thumbnail" style={{ width: "300px", height: "228px" }} />
                    <button type="button" onClick={() => handleRemoveImage(0)} className="remove-image-button">
                      &times;
                    </button>
                  </div>
    
              </div>
              )}
              {imageFileSizeError && (
                <p className="error-message">{imageFileSizeError}</p>
              )}
              {imageFileTypeError && (
                <p className="error-message">{imageFileTypeError}</p>
              )}
            </div>
            <label htmlFor="new-Title" className="new-input-label-pdf">
              Title
            </label>
            <CustomInput
              placeholder="Text"
              value={title}
              onChange={handleTitleChange}
            />

            <label htmlFor="new-Description" className="new-input-label-pdf">
              Description
            </label>
            <div className="new-custom-quill-pdf">
              <ReactQuill
                theme="snow"
                style={{
                  border: "none",
                  width: "100%",
                  background: "none",
                }}
                value={description}
                onChange={handleDescriptionChange}
              />
            </div>

            <div className="checkbox-container-pdf">
              <div className="left-content-pdf">
                <img
                  src={AddVideoSetting}
                  alt="Icon"
                  className="left-content-image-pdf"
                />
                <h2>Pdf Settings</h2>
              </div>
              <div className="checkbox-text-row-pdf">
                {checkboxData.map((label, index) => (
                  <div key={index}>
                    <input type="checkbox" id={`checkbox${index + 1}`} />
                    <label htmlFor={`checkbox${index + 1}`}>{label}</label>
                  </div>
                ))}
              </div>
            </div>

            <div className="Addpdf-buttons">
              <CustomButton
                variant="secondary"
                onClick={() => console.log("Cancel button clicked")}
              >
                Cancel
              </CustomButton>
              <CustomButton variant="primary" onClick={saveData}>
                Upload
              </CustomButton>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default AddPdf;
