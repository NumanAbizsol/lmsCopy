// MyLayoutComponent.tsx

import React, { useEffect, useState } from "react";
import "./CourseDashboard.scss";
import Header from "../header/Header";
// import Sidebar from "../sidebar/Sidebar";
import Products, { ProductCard } from "../productDashboard/ProductDashboard";
import Sidebar from "../../../components/shared/headerAndTabs/sidebar/Sidebar";
import CourseThumbnail from '../../../assets/images/courseProduct.svg'
import QuizThumbnail from '../../../assets/images/quizProduct.svg'
import FlashcardThumbnail from "../../../assets/images/Flashcard.png"

interface CoursesDashboardProps {
  isSidebarCollapsed: boolean;
}
const dummyProducts: ProductCard[] = [
  {
    heading: "Courses",
    text: "My Courses",
    path: "/my-courses",
    imgSrc: CourseThumbnail,
  },
  {
    heading: "Quizs",
    text: "Learn the basics of React.",
    path: "/quiz",
    imgSrc: QuizThumbnail,
  },
  {
    heading: "Flash Card",
    text: "Learn the basics of React.",
    path: "/flashcard",
    imgSrc: FlashcardThumbnail,
  },
];

const CoursesDashboard: React.FC<CoursesDashboardProps> = () => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(true);
  useEffect(() => {
    console.log("isSidebarCollapsed", isSidebarCollapsed);
  }, [isSidebarCollapsed]);

  return (
    <div>
      <div className="layout-container">
        <div
          className="course-sidebar"
          style={{ width: !isSidebarCollapsed ? "5%" : "16%" }}
        >
          <Sidebar
            isSidebarCollapsed={isSidebarCollapsed}
            setIsSidebarCollapsed={setIsSidebarCollapsed}
          />
        </div>
        <div className="course-content-container">
          {/* <Header
            setIsSidebarCollapsed={setIsSidebarCollapsed}
            isSidebarCollapsed={isSidebarCollapsed}
          /> */}
          <Products products={dummyProducts} />
        </div>
      </div>
    </div>
  );
};

export default CoursesDashboard;
