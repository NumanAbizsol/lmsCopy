import React, { ChangeEvent, useState } from "react";
import "./PrimaryPricing.scss";
import { Link, useNavigate } from "react-router-dom";
import { updateOrganizationData } from "../../../redux/Slices/CoursesSlice";
import { useDispatch } from "react-redux";
import CustomInput from "../../../components/inputs/input/Input";
import CustomRadio from "../../../components/inputs/radio/Radio";
import SwitchButton from "../../../components/shared/switchButton/SwitchButton";
import CustomButton from "../../../components/shared/button/Button";

type Props = {};

type PricingOptions = {
  isFree: boolean;
  amount: string;
  currency: "dollar" | "pound";
  expireDate: string;
  paidEvery: 'Month' | 'Year';
  numberOfMonth: string;
  // subscription: {
  //   amount: string;
  //   currency: "dollar" | "pound";
  //   paidEvery: "month" | "year";
  // };
  // freeTrial: {
  //   enabled: boolean;
  //   expirationDate: string;
  // };
};

const PrimaryPricing = (props: Props) => {
  const dispatch = useDispatch();

  const nav = useNavigate();
  const [pricingOptions, setPricingOptions] = useState<PricingOptions>({
    isFree: true, // default selected option
    
      amount: "",
      currency: "dollar",
      expireDate: "",
      paidEvery: "Month",
      numberOfMonth: "",
    
    // subscription: {
    //   amount: "",
    //   currency: "dollar",
    //   paidEvery: "month",
    // },
    // freeTrial: {
    //   enabled: false,
    //   expirationDate: "",
    // },
  });

  // function isValidSection(key: string): key is keyof PricingOptions {
  //   return ["oneTimePayment", "subscription", "freeTrial"].includes(key);
  // }
  // const handleInputChange = (
  //   event: ChangeEvent<HTMLInputElement | HTMLSelectElement>,key:any,section:String
  // ) => {
  //   const { name, value } = event.target;
  //   console.log("name-->",name,"value--->",value);
    
  //   // const section = event.target.getAttribute(
  //   //   "data-section"
  //   // ) as keyof PricingOptions;

  //   // if (!section || !isValidSection(section)) {
  //   //   console.error(`Invalid section: ${section}`);
  //   //   return;
  //   // }
  //   // console.log("section",section);
    
  //   // setPricingOptions((prevOptions) => {
  //   //   return {
  //   //     ...prevOptions,
  //   //     [section]:{ ...prevOptions.[section], [key]: value }
  //   //   };
  //   // });
  // };

  const handleSave = () => {
    dispatch(
      updateOrganizationData({ course: { pricingOptions: pricingOptions } })
    );
  };

  // const handleToggleChange = (event: ChangeEvent<HTMLInputElement>) => {
  //   setPricingOptions({
  //     ...pricingOptions,
  //     freeTrial: {
  //       ...pricingOptions.freeTrial,
  //       enabled: event.target.checked,
  //     },
  //   });
  // };

  const handleNavigate = () => {
    nav("/publish-course");
  };

  const isInteger = (value: string) => {
    const reg = /^\d+$/; // Regular expression to check if string contains only digits
    return reg.test(value);
  };

  // const handleInputChange = (event: ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
  //   const { name, value, type } = event.target;
  
  //   if (type === 'radio') {
  //     if (value === 'free') {
  //       setPricingOptions(prevOptions => ({
  //         ...prevOptions,
  //         freeOption: true
  //       }));
  //     } else if (value === 'oneTimePayment') {
  //       setPricingOptions(prevOptions => ({
  //         ...prevOptions,
  //         freeOption: false
  //       }));
  //     }
  //   } else {
  //     setPricingOptions(prevOptions => ({
  //       ...prevOptions,
  //       oneTimePayment: {
  //         ...prevOptions.oneTimePayment,
  //         [name]: value
  //       }
  //     }));
  //   }
  // };
  
  const handleOptionChange = (event: ChangeEvent<HTMLInputElement>) => {
    setPricingOptions({
      ...pricingOptions,
      isFree: event.target.value === 'free',
    });
  };
  const isIntegerInRange = (value: string, min: number, max: number) => {
    const number = parseInt(value, 10);
    return !isNaN(number) && number >= min && number <= max;
  };
  const handleChange = (event: ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = event.target;
    console.log("name",name,"value",value);
    
   
  if (name === "numberOfMonth") {
    if (value !== '' && !isIntegerInRange(value, 1, 12)) {
      // If the value is not an empty string and not in range, don't update the state.
      return;
    }
  } else if (name === "amount") {
    if (value !== '' && !isInteger(value)) {
      // If the value is not an empty string and not an integer, don't update the state.
      return;
    }
  }

    setPricingOptions({
      ...pricingOptions,
      [name]: value,
    });
  };


  console.log("Pricing options1", pricingOptions);


  return (
    <div className="parent-container">
      <div className="pricing">
        <h3>Primary Pricing</h3>
        <p>
          Set the initial pricing option that will be displayed on the course
          landing page
        </p>
      </div>
      <hr className="line" />
      <div className="custom-radio1">
        <CustomRadio
          name="isFree"
          value="free"
          checked={pricingOptions.isFree}
          onChange={handleOptionChange}
        />
        <label htmlFor="freeOption">
          <h4 className="heading4">Free</h4>
        </label>
      </div>
      <hr className="line" />
      <div className="oneTimePayment">
        <div className="custom-radio1">
          <CustomRadio
            
          name="isFree"
          value="oneTime"
          checked={!pricingOptions.isFree}
          onChange={handleOptionChange}
          />
          <label htmlFor="oneTimePaymentOption">
            <h4 className="heading4">One Time Payment</h4>
          </label>
        </div>
        <p className="paymentPara">
          Charge students a one-time fee to access the content. optionally, you
          can set an enrollment duration that will limit the time students have
          access to your content
        </p>
        <p className="amtText">Amount</p>
        <div className="amount">
          <select
           
            className="slect"
            name="currency"
            value={pricingOptions.currency}
            onChange={handleChange}
           disabled ={pricingOptions.isFree}
          >
            <option value="dollar">$</option>
            <option value="Pound">£</option>
          </select>
          <CustomInput
            name="amount"
        
            placeholder="Enter Amount"
            customClass="amountInpt"
            customStyles={
              {
                
              }
            }
            type="text"
          value={pricingOptions.amount}
          onChange={handleChange}
         

          />
        </div>
        <p className="amtText">Set Expire</p>
        <CustomInput
          customClass="exprInpt"
          placeholder="DD / MM / YY"
          type="date"
          name="expireDate"
          value={pricingOptions.expireDate}
          onChange={handleChange}
        
        />
        
        <div>
          <p className="amtText">Paid Every </p>
          <div className="amount">
            <select
             
           
              className="slect slect1"
              // name="currency"
              name="paidEvery"
              value={pricingOptions.paidEvery}
              onChange={handleChange}
          disabled={pricingOptions.isFree}

            
            >
              <option value="month">Month</option>
              <option value="year">Year</option>
            </select>
            <CustomInput
              name="numberOfMonth"
              type="text"
              placeholder="Enter month"
              customClass="amountInpt"
            
          
              value={pricingOptions.numberOfMonth}
              onChange={handleChange}
             
              // onChange={handleInputChange}
            />
          </div>
        </div>
        <div>
          {" "}
          <hr className="line" />
        </div>
        {/* iska neecha subcription ka start hoga */}
        
        <div className="custom-radio1">
          <CustomInput
            type="radio"
            // id="subcription"
            // name="pricingOption"
            // value="subscription"
            // checked={pricingOptions.selectedOption === "subscription"}
            // onChange={handleInputChange}
            
          />
          <label htmlFor="subcription">
            <h4 className="subcriptionHeading">
              Subscription / Membership{" "}
              <span>Available on start and above</span>
            </h4>
          </label>
        </div>
        <p className="subcritionDes">
          Student can buy all quizzes at once by this subscription Change
          students recurring monthly fees for access to course content.{" "}
          <Link to={"/"} className="lern">
            {" "}
            Learn more ...
          </Link>
        </p>
        <div className="priceAndMonth">
          <div>
            <p className="amtText">Amount</p>
            <div className="amount">
              <select name="amount" id="selectAmount" className="slect">
                <option value="dollar">$</option>
                <option value="Pound">£</option>
              </select>
              <input
                type="text"
                placeholder="Enter Amount"
                className="amountInpt"
              />
            </div>
          </div>

          <div>
            <p className="amtText">Paid </p>
            <div className="amount">
              <select name="amount" id="" className="slect slect1">
                <option value="dollar">Month</option>
                <option value="Pound">Year</option>
              </select>
              <input
                type="text"
                placeholder="Enter month"
                className="amountInpt"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="switchParent">
        <div className="switch">
          <div>
            <SwitchButton
              // customClass="react-switch-checkbox"
              // id={`react-switch-new`}
              // type="checkbox"
            />
           
          </div>
          <p className="switch-text">Free Trial Period</p>
        
        </div>
        <div>
          <p className="subcritionDes">
            Regular payment will be begin when trail ended
          </p>

          <div className="">
            <p className="amtText">Set Expire</p>
            <CustomInput
              type="date"
              placeholder="DD / MM / YY"
              customClass="exprInpt"
            />
          </div>
        </div>
      </div>
      <div className="footerBtn">
        <CustomButton variant="primary" onClick={handleSave} className="primaryBtn">
          save redux
        </CustomButton>
        <CustomButton variant="primary" onClick={handleNavigate} className="secondaryBtn">
          Next
        </CustomButton>
      </div>
    </div>
  );
};

export default PrimaryPricing;
