import React, { useState, ChangeEvent, useRef, useEffect } from "react";
import { useDropzone } from "react-dropzone";
import ReactQuill from "react-quill";
import AddVideoSetting from "../../../assets/images/addVideoSetting.png";
import { checkboxData } from "../../../constants/Constants";
import CustomButton from "../../../components/shared/button/Button";
import "./AddAudio.scss";
import CustomCheckbox from "../../../components/inputs/Customcheckbox/CustomCheckbox";
import browserupload from "../../../assets/images/videouploadicon.svg";
import uploadImgIcon from "../../../assets/images/upload.svg"


const MAX_FILE_SIZE_MB = 50;

const AddAudio = ({ section, setCourses, sectionIndex, chapterIndex, setContentType, setChapterIndex, setSectionIndex,contentType }: any) => {
  const [title, setTitle] = useState<string>("");
  const [description, setDescription] = useState<string>("");
  const [audioUpload, setAudioUpload] = useState<string | null>(null);
  const [fileSizeError, setFileSizeError] = useState<string | null>(null);
  const [fileTypeError, setFileTypeError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [saveAsDraft, setSaveAsDraft] = useState<boolean>(false);
  const imgfileInputRef = useRef<HTMLInputElement>(null);
  const attachmentfileInputRef = useRef<HTMLInputElement>(null);
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [imageFileSizeError, setImageFileSizeError] = useState<string | null>(null);
  const [imageFileTypeError, setImageFileTypeError] = useState<string | null>(null);
  const [thumbnail, setThumbnail] = useState<string | null>(null);
  const [uploadedAttachment, setUploadedAttachment] = useState<string | null>(null);



  const { getRootProps, getInputProps } = useDropzone();

  const handleFileUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];

    if (file) {
      const fileSizeInMB = file.size / (1024 * 1024);

      if (fileSizeInMB > MAX_FILE_SIZE_MB) {
        setFileSizeError("File size exceeds the maximum allowed size (50 MB)");
        setFileTypeError(null);
        return;
      }

      setFileSizeError(null);

      // Check if the file type is audio
      if (file.type.startsWith("audio/")) {
        const reader = new FileReader();

        reader.onload = () => {
          setAudioUpload(reader.result as string);
        };

        reader.readAsDataURL(file);
        setFileTypeError(null);
      } else {
        setFileTypeError("Only audio uploads are allowed");
        setAudioUpload(null);
      }
    }
  };

  const handleTitleChange = (e: ChangeEvent<HTMLInputElement>) => {
    setTitle(e.target.value);
  };

  const handleDescriptionChange = (value: string) => {
    setDescription(value);
  };

  const handleClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };
  const handleImageUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const imageFile = e.target.files?.[0];

    if (imageFile) {
      const imageSizeInMB = imageFile.size / (1024 * 1024);

      if (imageSizeInMB > MAX_FILE_SIZE_MB) {
        setImageFileSizeError("File size exceeds the maximum allowed size (50 MB)");
        setImageFileTypeError(null);
        return;
      }

      setImageFileSizeError(null);

      // Check if the file type is image (png or jpg)
      if (imageFile.type.startsWith("image/")) {
        const reader = new FileReader();

        reader.onload = () => {
          setThumbnail(reader.result as string); // Assuming only one thumbnail is allowed
          setUploadedImages([reader.result as string]);
        };

        reader.readAsDataURL(imageFile);
        setImageFileTypeError(null);
      } else {
        setImageFileTypeError("Only PNG and JPG images are allowed");
        setUploadedImages([]);
      }
    }
  };


  const handleRemoveImage = (index: number) => {
    const updatedImages = [...uploadedImages];
    updatedImages.splice(index, 1);
    setUploadedImages(updatedImages);
  };

  const handleAttachmentsChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];

    if (file) {
      const fileSizeInMB = file.size / (1024 * 1024);
      if (fileSizeInMB > MAX_FILE_SIZE_MB) {
        console.error("File size exceeds the maximum allowed size (50 MB)");
        return;
      }
      // Check if the file type is allowed (PDF, Doc, Excel)
      const allowedFileTypes = ["application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"];
      if (!allowedFileTypes.includes(file.type)) {
        console.error("Invalid file type. Only PDF, Doc, and Excel files are allowed.");
        return;
      }

      const reader = new FileReader();
      reader.onload = () => {
        setUploadedAttachment(reader.result as string);
      };
      reader.readAsDataURL(file);

      if (attachmentfileInputRef.current) {
        attachmentfileInputRef.current.value = "";
      }
    }
  };

  const saveData = (e: any) => {
    e.preventDefault();

    console.log(title, audioUpload, description, "audio description");

    if (chapterIndex === null) {
      setCourses((prevState: any) => ({
        ...prevState,
        section: prevState.section?.map((sect: any, currentIndex: number) => {
          if (currentIndex === sectionIndex) {
            return {
              ...sect,
              content: [
                ...sect.content,
                {
                  audio: audioUpload,
                  thumbnail: thumbnail,
                  title: title,
                  description: description,
                  saveAsDraft:saveAsDraft,
                  attachment: uploadedAttachment,
                  contentType,
                },
              ],
            };
          }
          return sect;
        }),
      }));
    } else {
      setCourses((prevCourse: any) => {
        const newCourse = { ...prevCourse };
        if (
          newCourse.section &&
          newCourse.section[sectionIndex] &&
          newCourse.section[sectionIndex].chapter &&
          newCourse.section[sectionIndex].chapter[chapterIndex]
        ) {
          newCourse.section[sectionIndex].chapter[chapterIndex].content = [
            ...newCourse.section[sectionIndex].chapter[chapterIndex].content,
            { title, audio: audioUpload, description,thumbnail,attachment:uploadedAttachment,contentType },
          ];
        }
        return newCourse;
      });
    }
    setChapterIndex(null);
    setSectionIndex(null);
    setContentType("");
    setSaveAsDraft(false);
  };



  return (
    <>
      <div className="new-add-audio-container-main">
        <div className="new-add-audio-container">
          <h1 className="new-heading-audio-text">Add Audio</h1>
          <CustomCheckbox  label="Save it as draft"  onChange={(e) => setSaveAsDraft(e.target.checked)}/>
          <div onClick={handleClick} className="new-upload-file">
            <input
              {...getRootProps()}
              {...getInputProps()}
              ref={fileInputRef}
              onChange={handleFileUpload}
            />
            {audioUpload ? (
              <audio controls>
                <source src={audioUpload} type="audio/mp3" />
                Your browser does not support the audio tag.
              </audio>
            ) : (
              <>
                <div className="new-image-container">
                  <img
                    src={AddVideoSetting}
                    alt="Uploaded"
                    className="new-uploaded-image"
                  />
                </div>
                <h1>Browse Files to upload</h1>
                {fileSizeError && (
                  <p className="error-message">{fileSizeError}</p>
                )}
                {fileTypeError && (
                  <p className="error-message">{fileTypeError}</p>
                )}
              </>
            )}
          </div>
          <form>
          <div className="thumbnail-image-upload d-flex align-center gap-10 m_t_20" onClick={() => imgfileInputRef.current?.click()}>
              {uploadedImages.length === 0?(
              <div className="img-picker d-flex-column justify-center align-center p-50" >
                <input
                  {...getRootProps()}
                  {...getInputProps()}
                  ref={imgfileInputRef}
                  onChange={handleImageUpload}
                  accept=".png, .jpg"
                  multiple={false}  // Allow only one file to be selected
                />
                <img src={browserupload} alt="Uploaded" className="new-uploaded-image" />
                <b>Upload Thumbnail</b>
                <p> PNG,JPG (max. 800x400px)</p>
              </div>
              ):(
              <div className="new-image-containerr d-flex align-center justify-center gap-10" >
              
                  <div className="uploaded-image-container d-flex">
                    <img src={uploadedImages[0]} alt={`Thumbnail`} className="uploaded-thumbnail" style={{ width: "300px", height: "228px" }} />
                    <button type="button" onClick={() => handleRemoveImage(0)} className="remove-image-button">
                      &times;
                    </button>
                  </div>
    
              </div>
              )}
              {imageFileSizeError && (
                <p className="error-message">{imageFileSizeError}</p>
              )}
              {imageFileTypeError && (
                <p className="error-message">{imageFileTypeError}</p>
              )}
            </div>
            <label htmlFor="new-Title" className="new-input-label-audio">
              Title
            </label>
            <input
              className="new-input-field-audio"
              placeholder="Text"
              value={title}
              onChange={handleTitleChange}
              required
            />
            <label htmlFor="new-Description" className="new-input-label-audio">
              Description
            </label>
            <div className="new-custom-quill-audio">
              <ReactQuill
                theme="snow"
                style={{
                  border: "none",
                  width: "100%",
                  background: "none",
                }}
                value={description}
                onChange={handleDescriptionChange}
              />
            </div>
            <label htmlFor="new-Add Attachment" className="input_label">
              Add Attachment
            </label>
            <div className="attachment-input-container d-flex justify-center align-center" onClick={() => attachmentfileInputRef.current?.click()}>
              <label
                className="attachments"
                htmlFor="attachmentsInput"
                style={{ textAlign: "center" }}
              >
                <span>
                  <img src={uploadImgIcon} alt="" />
                </span>
                {uploadedAttachment ? "Change Attachment" : "Upload Attachment (PDF, Doc, Excel)"}
              </label>
              <input
                type="file"
                ref={attachmentfileInputRef}
                accept=".pdf, .doc, .docx, .xls, .xlsx"
                id="attachmentsInput"
                className="course-attachments"
                onChange={handleAttachmentsChange}
                style={{ display: "none" }}
              />
            </div>
            <div className="checkbox-container-audio">
              <div className="Addaudio-buttons">
                <CustomButton variant="secondary" onClick={() => console.log("Cancel button clicked")}>
                  Cancel
                </CustomButton>
                <CustomButton variant="primary" onClick={saveData}>
                  Upload
                </CustomButton>
              </div>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default AddAudio;
