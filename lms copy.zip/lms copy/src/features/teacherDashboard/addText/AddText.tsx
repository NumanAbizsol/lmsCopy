import React, { useState, ChangeEvent } from "react";
import ReactQuill from "react-quill";
import AddVideoSetting from "../../../assets/images/addVideoSetting.png";
import { checkboxData } from "../../../constants/Constants";
import CustomButton from "../../../components/shared/button/Button";
// import "./AddPdf.scss";
import CustomInput from "../../../components/inputs/input/Input";

const AddPdf = ({}: any) => {
  const [title, setTitle] = useState<string>("");
  const [description, setDescription] = useState<string>("");
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);

  const handleTitleChange = (e: ChangeEvent<HTMLInputElement>) => {
    setTitle(e.target.value);
  };

  const handleDescriptionChange = (value: string) => {
    setDescription(value);
  };

  const saveData = (e: any) => {
    e.preventDefault();
    console.log(title, uploadedFile, description, "hhhhhhhhhhhhhhhh");
  };

  return (
    <>
      <div id="new-text-container-main">
        <div id="new-add-text-container">
          <h1 id="new-heading-text">Add Text</h1>

          <form>
            <label htmlFor="new-Title" id="new-input-label-text">
              Title
            </label>
            <CustomInput
              placeholder="Text"
              value={title}
              onChange={handleTitleChange}
            />

            <label htmlFor="new-Description" id="new-input-label-text">
              Description
            </label>
            <div id="new-custom-quill-text">
              <ReactQuill
                theme="snow"
                value={description}
                onChange={handleDescriptionChange}
              />
            </div>

            <div id="checkbox-container-text">
              <div id="left-content-text">
                <img
                  src={AddVideoSetting}
                  alt="Icon"
                  id="left-content-image-text"
                />
                <h2>Text Settings</h2>
              </div>
              <div id="checkbox-text-row-text">
                {checkboxData.map((label, index) => (
                  <div key={index}>
                    <input type="checkbox" id={`checkbox${index + 1}`} />
                    <label htmlFor={`checkbox${index + 1}`}>{label}</label>
                  </div>
                ))}
              </div>
            </div>

            <div id="Addtext-buttons">
              <CustomButton
                variant="secondary"
                onClick={() => console.log("Cancel button clicked")}
              >
                Cancel
              </CustomButton>
              <CustomButton variant="primary" onClick={saveData}>
                Upload
              </CustomButton>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default AddPdf;
