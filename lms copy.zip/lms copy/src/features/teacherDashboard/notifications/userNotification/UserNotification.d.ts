export type UserNotificationProps = {
    hideBorder?: boolean;
  }