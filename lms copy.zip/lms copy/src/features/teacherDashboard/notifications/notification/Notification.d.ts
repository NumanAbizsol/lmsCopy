export type NotificationProps = {
    title: string;
    description: string;
    date: string;
    time: string;
    hideBorder?: boolean;
  };