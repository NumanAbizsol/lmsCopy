import { DatePicker } from "antd";
// import moment from "moment";
import dayjs, { Dayjs } from "dayjs";
import { RangePickerProps } from "antd/es/date-picker/generatePicker";
import uiscalendar from "../../../../assets/images/uisCalender.svg";
import video from "../../../../assets/images/video.svg";
import { CourseData } from "../SetDripSchedule.d";
import { useState } from "react";
import CustomInput from "../../../../components/inputs/input/Input";
import "../SetDripSchedule.scss";
import CustomButton from "../../../../components/shared/button/Button";
import {ContentItem,Chapter} from '../SetDripSchedule.d'


interface RenderContentProps {
  contentItems: ContentItem[];
  onUpdate: (updatedItem: ContentItem, contentIndex: number) => void;
  backgroundColor: string;
  courseData: CourseData;
}

type RangeValue = RangePickerProps<Dayjs>["value"];

const RenderContent: React.FC<RenderContentProps> = ({
  contentItems,
  onUpdate,
  backgroundColor,
  courseData,
}) => {
  console.log("content  jjjjj", contentItems);
  console.log("con1", courseData.enrollmentType);

  const [items, setItems] = useState(contentItems);


  const handleDateChange = (dates: RangeValue, contentIndex: number) => {
    const updatedLessons = items.map((item, index) => {
      if (index === contentIndex) {
        return {
          ...item,
          publishDate: dates && dates[0] ? dayjs(dates[0].toDate()) : null,
          endDate: dates && dates[1] ? dayjs(dates[1].toDate()) : null,
        };
      }
      return item;
    });

    setItems(updatedLessons); // Local state ko update karen
    onUpdate(updatedLessons[contentIndex], contentIndex); // Parent component ko updated item send karen
  };

  const handleStudentEnrollmentDaysChange = (days: string, contentIndex: number) => {
    const updatedItems = items.map((item, index) => {
      if (index === contentIndex) {
        return {
          ...item,
          studentEnrollmentDays: parseInt(days, 10), // assuming days is a string from input
        };
      }
      return item;
    });
    
    setItems(updatedItems);
    // Assuming you want to propagate this change to a parent component or elsewhere
    onUpdate(updatedItems[contentIndex], contentIndex);
  };
    console.log("items",items)
  
  return (
    <div style={{ backgroundColor: backgroundColor }}>
      {items.map((item, index) => (
        <div
          className={`renderContent ${
            courseData.enrollmentType === "studentEnrollment"
              ? "studentEnrollment"
              : ""
          }`}
        >
          <div className="indexDev">
            <strong>{index + 1}</strong>
            <img src={video} alt="img1" style={{ color: "#475569" }} />
            <div>
              <h4>{item.title}</h4>
              <p>Type: video</p>
            </div>
          </div>
          {/* <p dangerouslySetInnerHTML={{ __html: item.description }}></p> */}
          {/* Add any other content rendering logic here */}
          {courseData && courseData.enrollmentType === "specificDate" ? (
            <div className="calendar-dev">
              <div>
                {item.publishDate && (
                  <div>
                    <img src={uiscalendar} alt="" className="uicalendar" />
                    <p className="pblsh">
                      {" "}
                      Publish On: {item.publishDate.format("YYYY-MM-DD")}
                    </p>
                  </div>
                )}
                {item.endDate && (
                  <div>
                    <img src={uiscalendar} alt="" className="uicalendar" />
                    <p className="pblsh">
                      {" "}
                      End Date: {item.endDate.format("YYYY-MM-DD")}
                    </p>
                  </div>
                )}
              </div>
              <DatePicker.RangePicker
                format="YYYY-MM-DD"
                //   onClick={toggleDatePicker}
                onCalendarChange={(dates) => handleDateChange(dates, index)}
                // value={[lesson.publishDate, lesson.endDate]}
              />
            </div>
          ) : courseData &&
            courseData.enrollmentType === "studentEnrollment" ? (
            // <div>
            <div className="d-flex gap-10 ">
              <>
                <p>Will Be Released</p>
                <div
                  className="d-flex "
                  style={{ width: "23%", height: "5vh" }}
                >
                  <CustomInput
                  name="studentEnrollmentDays"
                    type="text"
                    placeholder="0"
                    customStyles={{
                      backgroundColor: "white",
                      borderRight: "none",
                      outline: "none",
                    }}
                  
                    value={item.studentEnrollmentDays || ""}
                    onChange={(e) => handleStudentEnrollmentDaysChange(e.target.value, index)}
                  />
                  <CustomButton
                    variant="primary"
                    customStyle={{
                      borderTopLeftRadius: "0", // Corrected syntax
                      borderBottomLeftRadius: "0",
                    }}
                  >
                    Days
                  </CustomButton>
                </div>
                <p>After Start Date</p>
                {/* // </div> */}
              </>
            </div>
          ) : null}
          {/* <hr/> */}
        </div>
      ))}
    </div>
  );
};

export default RenderContent;
