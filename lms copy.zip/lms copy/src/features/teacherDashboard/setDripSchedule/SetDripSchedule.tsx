import React, { useEffect, useState } from "react";
import "./SetDripSchedule.scss";
import { Calendar, Collapse, DatePicker, Switch } from "antd";
import calendar from "../../../assets/images/calendar.svg";
import uiscalendar from "../../../assets/images/uisCalender.svg";
import SwitchButton from "../../../components/shared/switchButton/SwitchButton";
import { Button } from "antd";
import { CalendarOutlined } from "@ant-design/icons";
import dayjs from "dayjs";
import video from ".././../../assets/images/video.svg";
import RenderChapter from "./renderChapter/RenderChapter";
import RenderContent from "./renderContent/RenderContent";
import CustomRadio from "../../../components/inputs/radio/Radio";
import moment, { Moment } from "moment";

import {Chapter,ContentItem,Section,CourseData,Lesson} from './SetDripSchedule.d'

// type RangeValue = RangePickerProps<dayjs.Dayjs>['value'];
// type RangeValue = [Moment | null, Moment | null] | null;
type RangeValue = [dayjs.Dayjs | null, dayjs.Dayjs | null] | null;
const SetDripSchedule = () => {
  const [courseData, setCourseData] = useState<CourseData | null>(null);

  const [dates, setDates] = useState<[Moment, Moment] | []>([]);
  const [open, setOpen] = useState(false);
  const [enrollmentType, setEnrollmentType] = useState<'studentEnrollment' | 'specificDate'>('studentEnrollment');



  
  useEffect(() => {
    const courseJson = localStorage.getItem("course");
    if (courseJson) {
      try {
        const course = JSON.parse(courseJson);
        setCourseData(course);
      } catch (error) {
        console.error("Failed to parse course data", error);
      }
    }
  }, []);
  console.log("courseData:", courseData);

  const { Panel } = Collapse;
  const DripScheduleData = [
    {
      heading: "Student enrollment date",
      para: "When students access the course for the first time",
    },
    {
      heading: "On a specific date",
      para: "Lorem Ipsum is simply dummy text of the printing bry bryy .",
    },
  ];
  const DripSchedule = [
    {
      heading: "Lesson:1: Hello!",
      para: "Will be released.",
    },
    {
      heading: "Course information and welcome!",
      para: "Will be released.",
    },
    {
      heading: "Intro to maintenance task analysis",
      para: "Will be released.",
    },
    {
      heading: "1- Maintenance task analysis-lesson 1(final)PDF",
      para: "Will be released.",
    },
    {
      heading: "Assignment 1- introduction captured",
      para: "Will be released.",
    },
  ];

  const handleContentUpdate = (
    updatedContentItem: ContentItem,
    sectionIndex: number,
    chapterIndex?: number
  ) => {
    console.log("first", updatedContentItem.index, sectionIndex, chapterIndex);
    if (!courseData) return;

    const updatedCourseData = { ...courseData };
    let updatedSection = updatedCourseData.section[sectionIndex];
    console.log("second", updatedSection);
    if (typeof chapterIndex === "number") {
      // Agar chapterIndex provide ki gai hai to chapter ke andar update karen
      let updatedChapter = updatedSection.chapter[chapterIndex];
      updatedChapter.content = updatedChapter.content.map((item, idx) => {
        return idx === sectionIndex ? updatedContentItem : item;
      });
    } else {
      // Section ke andar direct update karen
      updatedSection.content = updatedSection.content.map((item, idx) => {
        console.log("third", item);
        return idx === sectionIndex ? updatedContentItem : item;
      });
    }

    // State aur local storage ko update karen
    setCourseData(updatedCourseData);
  };

  const saveToLocalStorage = (data: CourseData) => {
    const dataToSave = JSON.stringify(data, (key, value) => {
      if (key === "publishDate" || key === "endDate") {
        return value ? dayjs(value).format("YYYY-MM-DD") : null;
      }
      return value;
    });
    localStorage.setItem("course", dataToSave);
  };

  useEffect(() => {
    const courseJson = localStorage.getItem("course");
    if (courseJson) {
      try {
        const courseData = JSON.parse(courseJson, (key, value) => {
          if (key === "publishDate" || key === "endDate") {
            return value ? dayjs(value) : null;
          }
          return value;
        });
        setCourseData(courseData);
      } catch (error) {
        console.error("Failed to parse course data", error);
      }
    }
  }, []);

  useEffect(() => {
    // Save data to local storage whenever courseData updates
    if (courseData) {
      saveToLocalStorage(courseData);
    }
  }, [courseData]);


  // Radio button ke liye onChange handler
  const handleEnrollmentTypeChange = (type: 'studentEnrollment' | 'specificDate') => {
    setEnrollmentType(type);
    setCourseData(prevData => {
      if (prevData) {
        return { ...prevData, enrollmentType: type };
      } else {
        // Provide a default structure for CourseData when prevData is null
        return {
          title: '', // Default value for title
          tagLine: '', // Default value for tagLine
          url: '', // Default value for url
          description: '', // Default value for description
          section: [], // Default value for section
          enrollmentType: type
        };
      }
    });
  };
  console.log(courseData)
  
  return (
    <>
      <div className="setDripScheduleMainCon">
        <div className="setDripSchedule-con1">
          <h1>Set drip schedule</h1>
          <p>
            A drip schedule allows you to control when students will have access
            to your content, whether you have a specific launch date or want to
            limit the amount of lessons that can be viewed in a certain time
            period.
          </p>

          <div className="setDripSchedule-inner">
            <h1>Released By:</h1>

            
              <div className="radio-parent">
                <div className="radio-parent1">
                 <div>
                 <CustomRadio
                    name="enrollment"
                    value="studentEnrollment"
                    checked={enrollmentType === "studentEnrollment"}
                    onChange={() => handleEnrollmentTypeChange('studentEnrollment')}
                  />
                 </div>
                 <div >
                 <label htmlFor="draft">
                    <h4 className="heading4">Student Enrollments Days</h4>
                  </label>
                  <p>When student enrolls in the course</p>
                 </div>
                </div>
                <div className="radio-parent1">
                  <CustomRadio
                    name="enrollment"
                    value="specificDate"
                    checked={enrollmentType === "specificDate"}
                    onChange={() => handleEnrollmentTypeChange('specificDate')}
                  />
                  <div>
                    <label htmlFor="draft">
                      <h4 className="heading4">On Specific Date</h4>
                    </label>
                    <p>Select a date when this course will be released</p>
                  </div>
                </div>
              </div>
           
            <br />
            <br />
          </div>
        </div>
        <br />
        <div className="dripSchedule-container2">
          <div className="Accordion1-con2">
            <Collapse accordion expandIconPosition="right">
              <Panel
                key="1"
                header={
                  <div style={{ fontSize: "18px", color: "#081735" }}>
                    <b>Course Drip</b>
                  </div>
                }
                style={{
                  backgroundColor: "white",
                  marginBottom: "8px",
                }}
              >
                <div className="switchParent">
                  <div className="switch">
                    {/* <div>
                      <SwitchButton />
                      <p className="switch-text">Yes</p>
                    </div> */}
                    <div>{/* <img src={calendar} alt="" /> */}</div>
                  </div>
                  <div style={{}}>
                    <Collapse accordion expandIconPosition="right">
                      {courseData?.section?.map((section, sectionIndex) => (
                        <Panel
                          key={sectionIndex}
                          header={
                            <div style={{ fontSize: "18px", color: "#081735" }}>
                              <h4 className="sectionheading">
                                {section?.title}
                              </h4>
                            </div>
                          }
                          style={{
                            backgroundColor: "white",
                            marginBottom: "8px",
                          }}
                        >
                          <div
                            style={{
                              fontFamily: "Arial, sans-serif",
                              color: "#333",
                            }}
                          >
                            {section?.chapter &&
                              section?.chapter?.length > 0 && (
                                <RenderChapter
                                  chapters={section.chapter}
                                  onUpdate={(updatedItem, chapterIndex) =>
                                    handleContentUpdate(
                                      updatedItem,
                                      sectionIndex,
                                      chapterIndex
                                    )
                                  }
                                  backgroundColor="white"
                                  courseData={courseData}
                                />
                              )}
                            {section?.content &&
                              section?.content?.length > 0 && (
                                <RenderContent
                                  contentItems={section.content}
                                  onUpdate={(updatedItem) =>
                                    handleContentUpdate(
                                      updatedItem,
                                      sectionIndex
                                    )
                                  }
                                  backgroundColor="white"
                                  courseData={courseData}
                                />
                              )}
                          </div>
                        </Panel>
                      ))}
                    </Collapse>
                  </div>
                </div>
              </Panel>
            </Collapse>
          </div>
        </div>
      </div>
    </>
  );
};

export default SetDripSchedule;
