import RenderContent from "../renderContent/RenderContent";
import {CourseData} from "../SetDripSchedule.d"
import {ContentItem,Chapter} from '../SetDripSchedule.d'

  // interface RenderChapterProps {
  //   chapters: Chapter[];
  //   onUpdate: (updatedItem: ContentItem, chapterIndex?: number) => void;
  //   backgroundColor: string;
  // }
  
  

  interface RenderChapterProps {
    chapters: Chapter[];
    onUpdate: (updatedItem: ContentItem, chapterIndex?: number) => void;
    backgroundColor: string;
    courseData: CourseData;
  }

  const RenderChapter: React.FC<RenderChapterProps> = ({ chapters, onUpdate, backgroundColor ,courseData}) => {
    return (
      <div style={{ background: backgroundColor }}>
        {chapters.map((chapter, chapterIndex) => (
          <div key={chapterIndex}>
            <div className="chapTitle">
              <h4 className="h4title">Chapter {chapterIndex + 1}:</h4>
              <p>{chapter.title}</p>
            </div>
            {chapter.content && chapter.content.length > 0 && (
              <RenderContent 
                contentItems={chapter.content} 
                onUpdate={(updatedItem) => onUpdate(updatedItem, chapterIndex)}
                backgroundColor="white"
                courseData={courseData}

              />
            )}
          </div>
        ))}
      </div>
    );
  };

  export default RenderChapter;
  

