import moment, { Moment } from "moment";

export interface Chapter {
    title: string;
    description: string;
    content: ContentItem[];
  }
 export interface ContentItem {
    index?: number;
    title: string;
    type: string;
    description: string;
  studentEnrollmentDays:number;
  publishDate?: Dayjs | null;
  endDate?: Dayjs | null;

  }
  
 export interface Section {
    title: string;
    chapter: Chapter[];
    content: ContentItem[];
  }
  
 export interface CourseData {
    title: string;
    tagLine?: string;
    url?: string;
    description?: string;
    section: Section[];
    enrollmentType?: 'studentEnrollment' | 'specificDate' ;
  }
  
 export interface Lesson {
    id: number;
    name: string;
    type: string;
    publishDate: Moment | null;
    endDate: Moment | null;
  }