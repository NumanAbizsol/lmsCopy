
export interface User {
  key: string;
  fullName: string;
  amount: string;
  role: string;
  dateCreated: string;
  emailAddress: string;
  lastSignIn: string;
  enrolledBy: string;
  status: string;
  avatar: string;
}

export interface User {
  enrolledInProducts: string[];
}