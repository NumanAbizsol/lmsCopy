import React, { useState } from "react";
import {
  Table,
  Space,
  Avatar,
  Button,
  Input,
  Checkbox,
  message,
  Tag,
  Modal,
} from "antd";
import {
  DeleteOutlined,
  EditOutlined,
  CheckOutlined,
  CloseOutlined,
  SearchOutlined,
  ExclamationCircleOutlined,
  SmileOutlined,
} from "@ant-design/icons";
import CustomButton from "../../../components/shared/button/Button";
import Select from "../../../components/inputs/select/Select";
import img from "../../../assets/images/assignmentProduct.png";
import "./CurrentUser.scss";
import Tab from "../../../components/shared/headerAndTabs/Tabs";
import { User } from "./CurrentUser.d";
import CustomInput from "../../../components/inputs/input/Input";
import CustomCheckbox from "../../../components/inputs/Customcheckbox/CustomCheckbox";
import { validateEmail } from "../../../components/shared/formValidations/validation";
import Sidebar from "../../../components/shared/headerAndTabs/sidebar/Sidebar";
import OverlayConfirmationModal from "../OrgProduct/OverlayConfirmationModal";

const CurrentUser: React.FC = () => {
  const [dataSource, setDataSource] = useState<User[]>([]);
  const [selectedTab, setSelectedTab] = useState<number>(0);
  const [selectedRole, setSelectedRole] = useState<string>("");
  const [uniqueEmails, setUniqueEmails] = useState<Set<string>>(new Set());
  const [firstNameError, setFirstNameError] = useState<string>("");
  const [emailError, setEmailError] = useState<string>("");
  const [roleError, setRoleError] = useState<string>("");
  const [editingKey, setEditingKey] = useState<string | null>(null);

  const [editModalVisible, setEditModalVisible] = useState(false);
  const [editingUserData, setEditingUserData] = useState<User | null>(null);

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    role: "",
  });
  const [isModalVisible, setIsModalVisible] = useState(false);

  const handleDeleteConfirm = () => {
    setIsModalVisible(true);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
  };
  const handleDelete = (key: React.Key) => {
    const newData = dataSource.filter((item) => item.key !== key);
    setDataSource(newData);
    setIsModalVisible(false);
  };

  const isEditing = (record: User): boolean => record.key === editingKey;
  const options = [
    { label: "Admin", value: "admin" },
    { label: "User", value: "user" },
    { label: "Teacher", value: "teacher" },
  ];

  const edit = (key: string): void => {
    const user = dataSource.find((record) => record.key === key);
    if (user) {
      setEditingKey(user.key);
      setFormData({
        firstName: user.fullName.split(" ")[0],
        lastName: user.fullName.split(" ")[1] || "",
        email: user.emailAddress,
        role: user.role,
      });
      setEditingUserData(user);
      setEditModalVisible(true);
    }
  };
  const handleEditCancel = (): void => {
    setEditingUserData(null);
    setEditModalVisible(false);
  };

  const handleEditSave = (): void => {
    // Your logic to save the edited data
    setEditingUserData(null);
    setEditModalVisible(false);
  };

  const save = (key: string): void => {
    const newData = [...dataSource];
    const index = newData.findIndex((item) => key === item.key);

    if (index > -1) {
      const item = newData[index];
      newData.splice(index, 1, {
        ...item,
        fullName: `${formData.firstName} ${formData.lastName}`,
        role: selectedRole,
        emailAddress: formData.email,
      });
      setDataSource(newData);
      setEditingKey(null);
    } else {
      message.error("User not found.");
    }
  };

  const cancel = (): void => {
    setEditingKey(null);
    setFormData({
      firstName: "",
      lastName: "",
      email: "",
      role: "",
    });
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    name: string
  ) => {
    const { value } = e.target;
    console.log(`${name}: ${value}`);
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSearch = (value: string) => {
    const filteredData = dataSource.filter((user) =>
      Object.values(user).some((field) => {
        const fieldValue = field?.toString().toLowerCase();
        const includes = fieldValue.includes(value.toLowerCase());
        return includes;
      })
    );

    setDataSource(filteredData);
  };

  const handleFormSubmit = () => {
    const trimmedFirstName = formData.firstName.trim();
    if (!trimmedFirstName) {
      setFirstNameError("First name is required");
      setEmailError("Email is required");
      setRoleError("Role is required");
      return;
    }
    setFirstNameError("");

    const emailValidationResult = validateEmail(formData.email);
    if (emailValidationResult) {
      setEmailError(emailValidationResult);
      return;
    }
    setEmailError("");

    if (!selectedRole) {
      setRoleError("Role is required");
      return;
    }
    setRoleError("");

    const generateKey = (): string => {
      return Math.random().toString(36).substr(2, 9);
    };

    const newUser: User = {
      key: generateKey(),
      fullName: `${formData.firstName} ${formData.lastName}`,
      amount: "Rs 0",
      role: selectedRole,
      dateCreated: new Date().toLocaleDateString(),
      emailAddress: formData.email,
      lastSignIn: "",
      enrolledBy: "Self",
      status: "Pending",
      avatar: "",
      enrolledInProducts: ["LMS"],
    };

    setDataSource([...dataSource, newUser]);

    setUniqueEmails(new Set(uniqueEmails).add(formData.email));

    setFormData({
      firstName: "",
      lastName: "",
      email: "",
      role: "",
    });

    resetForm();

    Modal.success({
      title: "User Added",
      content: "The user has been added successfully.",
      icon: <SmileOutlined />,
      onOk: () => {},
    });
  };

  const resetForm = () => {
    setFormData({
      firstName: "",
      lastName: "",
      email: "",
      role: "",
    });
  };

  const tabData = [{ name: "User Listing" }, { name: "Add User" }];

  const columns = [
    {
      title: "Name",
      dataIndex: "fullName",
      key: "fullName",
      render: (text: string, record: User) => (
        <div>
          {isEditing(record) ? (
            <span className="d-flex">
              <Input
                style={{ width: "40%" }}
                value={formData.firstName}
                onChange={(e) =>
                  setFormData({ ...formData, firstName: e.target.value })
                }
              />
              <Input
                style={{ width: "40%" }}
                value={formData.lastName}
                onChange={(e) =>
                  setFormData({ ...formData, lastName: e.target.value })
                }
              />
            </span>
          ) : (
            <>
              <Checkbox />
              <Avatar
                src={img}
                alt="Avatar"
                style={{ width: "35px", height: "35px", marginLeft: "8px" }}
              />
              <span
                style={{
                  color: "#101828",
                  padding: "4px 8px",
                  fontSize: "15px",
                  position: "relative",
                }}
              >
                <b>{text}</b>
              </span>
            </>
          )}
        </div>
      ),
    },
    {
      title: "Amount Spent",
      dataIndex: "amount",
      key: "amount",
    },
    {
      title: "Date Created",
      dataIndex: "dateCreated",
      key: "dateCreated",
    },
    {
      title: "Email Address",
      dataIndex: "emailAddress",
      key: "emailAddress",
    },
    {
      title: "Enrolled By",
      dataIndex: "enrolledBy",
      key: "enrolledBy",
    },
    {
      title: "Enrolled In products",
      dataIndex: "enrolledInProducts",
      key: "enrolledInProducts",
      render: (text: string[]) => (
        <span>
          {text.map((product, index) => (
            <Tag key={index} color="blue">
              {product}
            </Tag>
          ))}
        </span>
      ),
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (text: string) => (
        <span
          style={{
            color: "#027A48",
            background: "#ECFDF3",
            padding: "4px 8px",
            borderRadius: "8px",
            fontSize: "13.5px",
          }}
        >
          <b>{text}</b>
        </span>
      ),
    },
    {
      title: "Role",
      dataIndex: "role",
      key: "role",
      render: (text: string) => (
        <span
          style={{
            color: "#6941C6",
            background: "#f0f5ff",
            padding: "4px 8px",
            borderRadius: "8px",
            fontSize: "13.5px",
          }}
        >
          <b>{text}</b>
        </span>
      ),
    },
    {
      title: "Actions",
      key: "actions",
      render: (text: string, record: User) => (
        <Space size="middle">
          <Button
            icon={<DeleteOutlined />}
            danger
            onClick={handleDeleteConfirm}
          />

          <OverlayConfirmationModal
            heading={"Warning"}
            description={"Are you sure you want to delete?"}
            visible={isModalVisible}
            onCancel={handleCancel}
            onConfirm={() => handleDelete(record.key)}
            IconComponent={ExclamationCircleOutlined}
          />

          {isEditing(record) ? (
            <>
              <Button
                icon={<CheckOutlined />}
                onClick={() => save(record.key)}
              />
              <Button icon={<CloseOutlined />} onClick={cancel} />
            </>
          ) : (
            <Button icon={<EditOutlined />} onClick={() => edit(record.key)} />
          )}
        </Space>
      ),
    },
  ];
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState();
  const handleRoleChange = (value: string) => {
    setSelectedRole(value);
    setRoleError("");
    setFormData((prevData) => ({
      ...prevData,
      role: value,
    }));
  };

  return (
    <div style={{ display: "flex" }}>
      <div className="sidebar-wraper">
        <Sidebar
          isSidebarCollapsed={isSidebarCollapsed}
          setIsSidebarCollapsed={setIsSidebarCollapsed}
          isForOrganization={true}
        />
      </div>

      <div
        style={{ width: !isSidebarCollapsed ? "95%" : "75%" }}
        className="Currentuser-Main"
      >
        <div className="main-heading ">User Management</div>
        <div className="tabsContainer">
            <Tab
              tabData={tabData}
              selectedTab={selectedTab}
              setSelectedTab={setSelectedTab}
            />
          </div>

        <div className="ujuju">
       

          {selectedTab === 0 && (
            <div className="Currentuser-heading">
              <h1 style={{ margin: "10px", fontSize: "28px" }}>
                Current Users
              </h1>
            </div>
          )}

          {selectedTab === 0 && (
            <Input
              placeholder="Search..."
              prefix={<SearchOutlined style={{ color: "rgba(0,0,0,.25)" }} />}
              id="current-input"
              style={{
                width: "250px",
                borderRadius: "4px",
                border: "1px solid #d9d9d9",
                backgroundColor: "#fafafa",
                fontSize: "15px",
                marginLeft: "15px",
                marginBottom: "10px",
              }}
              onChange={(e) => handleSearch(e.target.value)}
            />
          )}

          {selectedTab === 0 && (
            <div id="Currentuser-cont-2">
              <Table columns={columns} dataSource={dataSource} />
            </div>
          )}

          {selectedTab === 1 && (
            <div className="Adding-user">
              <h1 className="main-heading">Adding User</h1>
              <div className="Adding-user-form-inner">
                <div>
                  <label htmlFor="firstName" className="input_label">
                    First Name
                  </label>

                  <CustomInput
                    placeholder="Your Name"
                    value={formData.firstName}
                    onChange={(e) => handleInputChange(e, "firstName")}
                  />

                  {firstNameError && (
                    <div
                      className="error-message"
                      style={{ position: "absolute" }}
                    >
                      {firstNameError}
                    </div>
                  )}
                </div>

                <div>
                  <label htmlFor="lastName" className="input_label">
                    Last Name
                  </label>
                  <CustomInput
                    placeholder="khan"
                    value={formData.lastName}
                    onChange={(e) => handleInputChange(e, "lastName")}
                  />
                </div>
              </div>

              <div className="Adding-user-form-inner">
             

              <div className="m_t_20">
                <label htmlFor="email" className="input_label">
                  Email*
                </label>
                <CustomInput
                  placeholder="Xyz@gmail.com"
                  value={formData.email}
                  onChange={(e) => {
                    handleInputChange(e, "email");
                  }}
                />
                {emailError && (
                  <div
                    className="error-message"
                    style={{ position: "absolute" }}
                  >
                    {emailError}
                  </div>
                )}
              </div>

              <div className="Currentuser-select">
                <label htmlFor="email">
                  <h5>
                    Select User Role{" "}
                  </h5>
                </label>
                <Select
                  variant={"single-select"}
                  options={options}
                  handleChange={handleRoleChange}
                  value={formData.role}
                />
                {roleError && (
                  <div
                    className="error-message"
                    style={{ position: "absolute" }}
                  >
                    {roleError}
                  </div>
                )}
              </div>
              </div>
              <br />
              <div>
                <div className="currentUser-radio">
                  {" "}
                  <p>Enrolled In products</p>{" "}
                  <div className="checkbox-group">
                    {" "}
                    <CustomCheckbox label="LMS" id="checkbox1" />{" "}
                    <CustomCheckbox label="HRM" id="checkbox2" />{" "}
                    <CustomCheckbox label="CMS" id="checkbox3" />
                  </div>{" "}
                </div>
              </div>
              <div className="CurrentUser_btn_div">
                <CustomButton
                  onClick={resetForm}
                  variant="secondary"
                  className="CurrentUser_btn_1"
                >
                  Cancel
                </CustomButton>
                <CustomButton
                  variant="primary"
                  className="CurrentUser_btn_1"
                  onClick={handleFormSubmit}
                >
                  Send Invitation
                </CustomButton>
              </div>
            </div>
          )}
        </div>
      </div>
      {/* **********************MOdal******************************* */}

      {editingUserData && (
        <Modal
          title="Edit User"
          visible={editModalVisible}
          onCancel={handleEditCancel}
          onOk={handleEditSave}
        >
          <div className="Adding-user-form-inner">
            <div>
              <label htmlFor="firstName" className="input_label">
                First Name
              </label>

              <CustomInput
                placeholder="Your Name"
                value={formData.firstName}
                onChange={(e) => handleInputChange(e, "firstName")}
              />

              {firstNameError && (
                <div className="error-message" style={{ position: "absolute" }}>
                  {firstNameError}
                </div>
              )}
            </div>

            <div>
              <label htmlFor="lastName" className="input_label">
                Last Name
              </label>
              <CustomInput
                placeholder="khan"
                value={formData.lastName}
                onChange={(e) => handleInputChange(e, "lastName")}
              />
            </div>
          </div>

          <div className="m_t_20">
            <label htmlFor="email" className="input_label">
              Email*
            </label>
            <CustomInput
              placeholder="Xyz@gmail.com"
              value={formData.email}
              disabled
              onChange={(e) => {
                handleInputChange(e, "email");
              }}
            />
            {emailError && (
              <div className="error-message" style={{ position: "absolute" }}>
                {emailError}
              </div>
            )}
          </div>

          <div className="m_t_20">
            <label htmlFor="email">
              <h5>
                <b>Select User Role</b>{" "}
              </h5>
            </label>
            <Select
              variant={"single-select"}
              options={options}
              handleChange={handleRoleChange}
              value={formData.role}
            />
            {roleError && (
              <div className="error-message" style={{ position: "absolute" }}>
                {roleError}
              </div>
            )}
          </div>
        </Modal>
      )}
    </div>
  );
};

export default CurrentUser;
