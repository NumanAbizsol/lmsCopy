import  { useState, useEffect } from "react";
import {
  useAppDispatch,
  useAppSelector,
} from "../../../hooks/useTypedSelector";
import { useNavigate } from "react-router-dom";
import { getOrganization } from "../../../redux/Slices/OrganizationSlice";
import "./OrganizationSetting.css";
import CustomButton from "../../../components/shared/button/Button";
import item from "../../../assets/images/Item.png";
import Sidebar from "../../../components/shared/headerAndTabs/sidebar/Sidebar";

type OrganizationSettingProps = {};

const OrganizationSetting = (props: OrganizationSettingProps) => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(true);
  const [organizationData, setOrganizationData] = useState({
    timezone: "Your Timezone",
    language: "Your Language",
    currency: "Your Currency",
  });

  useEffect(() => {
    dispatch(getOrganization());
  }, [dispatch]);

  const { organization } = useAppSelector(
    (state: any) => state.organization
  );

  useEffect(() => {
    if (organization && organization.length > 0) {
      setOrganizationData({
        timezone: organization[0]?.timezone || "Your Timezone",
        language: organization[0]?.language || "Your Language",
        currency: organization[0]?.currency || "Your Currency",
      });
    }
  }, [organization]);

 
  const handleEditClick = () => {
    navigate("/edit-org-setting", {
      state: {
        organizationData: {
          organizationName: organization[0]?.OrganizationName,
          orgUrl: organization[0]?.OrgUrl,
        },
      },
    });
  };

  return (
    <div className="org-setting-wrapper d-flex">
      <div className="sidebar-wraper">
        <Sidebar
          isSidebarCollapsed={isSidebarCollapsed}
          setIsSidebarCollapsed={setIsSidebarCollapsed}
          isForOrganization={true}
        />
      </div>
      <div className="content-wrapper" style={{ width: "100%" }}>
        <div
          className="organization-setting-container"
          style={{ width: "auto" }}
        >
          <div className="main-heading">Organization Settings</div>
          <hr />
          <div className="org-setting-container">
            <div className="org-info">
              <div className="org-setting-name">
                <b>Organization</b>: &nbsp; &nbsp;
                {organization[0]?.OrganizationName}
              </div>
              <p>
                <b style={{ color: "#10baac" }}>Logo</b>: &nbsp; &nbsp;
                <img
                  className="org-logo"
                  src={organization[0]?.Thumbnail}
                  // src={organization}

                  alt="Logo"
                />
              </p>
              <div className="org-additional-info">
                <b style={{ color: "#10baac" }}>Url</b>:&nbsp; &nbsp;{" "}
                {organization[0]?.OrgUrl}
              </div>
            </div>
          </div>
          <div className="org-setting-container-2">
            <div>
              <b>Your current time zone is</b>
              <br />

              <span className="highlight">{organizationData.timezone}</span>
              <div>
                <b>Language is</b>
                <br />

                <span className="highlight">{organizationData.language}</span>
              </div>
              <div>
                <b>Currency locale is</b>
                <br />

                <span className="highlight">{organizationData.currency}</span>
              </div>
            </div>
          </div>
          <hr />
          <CustomButton
            variant="primary"
            onClick={handleEditClick}
            className="CurrentUser_btn_1"
          >
            {/* {hasPermissionForAction("EDIT_ORGANIZATION")?"Edit":"No Permission!"} */}
          </CustomButton>

          <img src={item} className="org-setting-img" alt="Item" />
        </div>
      </div>
    </div>
  );
};

export default OrganizationSetting;
