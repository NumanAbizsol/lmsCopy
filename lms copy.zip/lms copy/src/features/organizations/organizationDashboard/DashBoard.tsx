import { useState, useEffect } from "react";
import CustomButton from "../../../components/shared/button/Button";
import { ReactComponent as EditIcon } from "../../../assets/images/edit.svg";
import { ReactComponent as Setting } from "../../../assets/images/settings.svg";
import { ReactComponent as MoreVertical } from "../../../assets/images/more-vertical.svg";
import { useNavigate } from "react-router-dom";
import "./Dashboard.scss";
import ChildDetail from "../../../components/shared/childDetail/ChildDetail";
import OrganizationModel from "./OrganizationModel";
import { Menu, Dropdown, Space } from "antd";
import { Icon } from "@iconify/react";
import usePermission from "../../../PermissionHook";
import {
  useAppSelector,
  useAppDispatch,
} from "../../../hooks/useTypedSelector";
import { getOrganization } from "../../../redux/Slices/OrganizationSlice";
import Sidebar from "../../../components/shared/headerAndTabs/sidebar/Sidebar";

interface Organization {
  id: string;
  OrganizationName: string;
  OrgUrl: string;
  Thumbnail?: string;
  apps?: any[];
}

const OrganizationDashboard = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { hasPermissionForAction } = usePermission();
  const [organization, setOrganization] = useState<Organization[]>([]);

  const dispatch = useAppDispatch();
  const [editingOrgId, setEditingOrgId] = useState<string | null>(null);

  useEffect(() => {
    dispatch(getOrganization());
  }, []);

  let orga = useAppSelector((state: any) => state.organization.organization);

  useEffect(() => {
    setOrganization(orga);
  }, [orga]);

  const navigate = useNavigate();

  const handleProductNavigation = () => {
    navigate("/teacher");
  };

  const handleEditOrganizationName = (orgId: string) => {
    setEditingOrgId(orgId);
  };

  const handleSaveOrganizationName = (orgId: string, newName: string) => {
    const updatedOrganization = organization.map((org) =>
      org.id === orgId ? { ...org, OrganizationName: newName } : org
    );
    setOrganization(updatedOrganization);
    setEditingOrgId(null);
  };

  const menu = (
    <Menu>
      <Menu.Item key="2">
        <Space>
          <Icon icon="mdi:delete" height="20" />
          Delete
        </Space>
      </Menu.Item>
    </Menu>
  );

  return (
    <div style={{ display: "flex" }}>
      <div className="sidebar-wraper">
        <Sidebar isSidebarCollapsed={false} setIsSidebarCollapsed={() => {}} />
      </div>
      <div style={{ width: "95%", margin: "20px 30px" }}>
        <div className="org-heading">
          <h1 style={{ margin: "0px" }}>List of Organizations</h1>
          {hasPermissionForAction("CREATE_ORGANIZATION") ? (
            <CustomButton
              variant="primary"
              showPlusButton={true}
              customStyle={{ height: "50px" }}
              onClick={() => setIsModalOpen(true)}
            >
              Create An Organization
            </CustomButton>
          ) : "No Permissions for this Action!"}
        </div>

        {organization &&
          organization.map((org: Organization) => (
            <div key={org.id} className="main-container">
              <div className="org-heading" style={{ margin: "20px" }}>
                <div
                  className="org-heading"
                  style={{ justifyContent: "flex-start" }}
                >
                  <div className="user-avatar">
                    {org?.Thumbnail ? (
                      <img
                        style={{ width: "inherit" }}
                        src={org?.Thumbnail}
                        alt="User Icon"
                      />
                    ) : (
                      <div className="initials">
                        {org?.OrganizationName?.slice(0, 2).toUpperCase()}
                      </div>
                    )}
                  </div>
                  <div className="product-name">
                    {editingOrgId === org.id ? (
                      <input
                        type="text"
                        value={org.OrganizationName}
                        onChange={(e) =>
                          handleSaveOrganizationName(org.id, e.target.value)
                        }
                        onClick={(e) => e.stopPropagation()}
                        onBlur={() => setEditingOrgId(null)}
                      />
                    ) : (
                      <>
                        <h2>{org?.OrganizationName}</h2>
                        <p>{org?.OrgUrl}</p>
                      </>
                    )}
                  </div>
                  <EditIcon
                    onClick={() => handleEditOrganizationName(org.id)}
                    style={{
                      marginLeft: "10px",
                      cursor: "pointer",
                    }}
                  />
                </div>
                <div className="org-heading">
                  <Setting
                    style={{
                      marginRight: "10px",
                      padding: "5px",
                      backgroundColor: "#F9FAFB",
                    }}
                  />
                  <Dropdown
                    overlay={menu}
                    placement="bottomRight"
                    trigger={["click"]}
                  >
                    <MoreVertical
                      style={{
                        marginRight: "10px",
                        padding: "5px",
                        backgroundColor: "#F9FAFB",
                        borderRadius: "50%",
                      }}
                    />
                  </Dropdown>
                </div>
              </div>
              {org?.apps?.map((app: any) => (
                <div key={app.id} onClick={handleProductNavigation}>
                  <ChildDetail title={app?.name} />
                </div>
              ))}
            </div>
          ))}
        <OrganizationModel
          isfromDashboard={true}
          setIsModalOpen={setIsModalOpen}
          isModalOpen={isModalOpen}
        />
      </div>
    </div>
  );
};

export default OrganizationDashboard;
