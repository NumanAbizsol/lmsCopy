import CustomModal from "../createOrganization/customModal/CustomModal";
import OrganizationSetup from "../createOrganization/organization";

const OrganizationModel=({isModalOpen,setIsModalOpen,isfromDashboard=false}:any)=>{


return<>
<CustomModal isOpen={isModalOpen} onClose={()=>{setIsModalOpen(false)}}>
<OrganizationSetup setOrganizationmodal={setIsModalOpen} isfromDashboard={isfromDashboard} isModelView={true}/>
</CustomModal>
</>
}
export default OrganizationModel