import OrgProduct from "./OrgProduct";
import HrmPhoto from "../../../assets/images/Photo.png";
import "./OrgProduct.scss";
import React, { useState } from "react";
import "./OrgProduct.scss";
import { Input, Result, Button } from "antd";
import { SearchOutlined } from "@ant-design/icons";
import CustomSelect from "../../../components/inputs/select/Select";
import Sidebar from "../../../components/shared/headerAndTabs/sidebar/Sidebar";

interface OrgProductData {
  id: number;
  upperText: string;
  lowerText: string;
  imgSrc: string;
  ActiveUsers: string;
  Numbers: string;
  ourDate: Date;
}

const OrgProducts: OrgProductData[] = [
  {
    id: 1,
    upperText: "LMS",
    lowerText: "ACCESS CODE",
    imgSrc: HrmPhoto,
    ActiveUsers: "2300",
    Numbers: "25",
    ourDate: new Date(2023, 1, 2),
  },
  {
    id: 2,
    upperText: "HRM",
    lowerText: "ACCESS CODE",
    imgSrc: HrmPhoto,
    ActiveUsers: "1500",
    Numbers: "30",
    ourDate: new Date(2024, 1, 2),
  },
  {
    id: 3,
    upperText: "CMS",
    lowerText: "ACCESS CODE",
    imgSrc: HrmPhoto,
    ActiveUsers: "1500",
    Numbers: "30",
    ourDate: new Date(2024, 1, 2),
  },
  // {
  //   id: 4,
  //   upperText: "HRM",
  //   lowerText: "ACCESS CODE",
  //   imgSrc: HrmPhoto,
  //   ActiveUsers: "1500",
  //   Numbers: "30",
  //   ourDate: new Date(2024, 1, 2),
  // },
  // {
  //   id: 5,
  //   upperText: "HRM",
  //   lowerText: "ACCESS CODE",
  //   imgSrc: HrmPhoto,
  //   ActiveUsers: "1500",
  //   Numbers: "30",
  //   ourDate: new Date(2024, 1, 2),
  // },
  // {
  //   id: 6,
  //   upperText: "HRM",
  //   lowerText: "ACCESS CODE",
  //   imgSrc: HrmPhoto,
  //   ActiveUsers: "1500",
  //   Numbers: "30",
  //   ourDate: new Date(2024, 1, 2),
  // },
  // {
  //   id: 7,
  //   upperText: "HRM",
  //   lowerText: "ACCESS CODE",
  //   imgSrc: HrmPhoto,
  //   ActiveUsers: "1500",
  //   Numbers: "30",
  //   ourDate: new Date(2024, 1, 2),
  // },
  // {
  //   id: 8,
  //   upperText: "HRMX",
  //   lowerText: "ACCESS CODE",
  //   imgSrc: HrmPhoto,
  //   ActiveUsers: "1500",
  //   Numbers: "30",
  //   ourDate: new Date(2024, 1, 2),
  // },
];
interface ActiveUser {
  value: string;
  label: string;
}

const activeUsers: ActiveUser[] = [
  { value: "1", label: "Active Users" },
  { value: "2", label: "Inactive Users" },
];

const ChkingOrgProduct: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [orgProducts, setOrgProducts] = useState<OrgProductData[]>(OrgProducts);
  const [archivedItems, setArchivedItems] = useState<OrgProductData[]>([]);
  const [activeUser, setActiveUser] = useState<any>("1");

  // Filter products based on search term
  const filteredProducts = orgProducts.filter((product) =>
    product.upperText.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const handleDelete = (idToRemove: number) => {
    const itemToDelete = orgProducts.find(
      (product) => product.id === idToRemove
    );

    if (itemToDelete) {
      const updatedProducts = orgProducts.filter(
        (product) => product.id !== idToRemove
      );
      setOrgProducts(updatedProducts);
      setArchivedItems([...archivedItems, itemToDelete]); // Move item to archived
    }
  };

  const handleActiveUser = (value: string) => {
    console.log("Selected:", value);
    setActiveUser(value);
  };
  const [isSidebarCollapsed,setIsSidebarCollapsed]=useState(true)

  return (
    <div style={{ display: "flex" }}>
      <div
        className="sidebar-wraper"
        // style={{ width: !isSidebarCollapsed ? "5%" : "25%" }}
      >
        <Sidebar
          isSidebarCollapsed={isSidebarCollapsed}
          setIsSidebarCollapsed={setIsSidebarCollapsed}
          isForOrganization={true}
        />
      </div>
      <div
        style={{ width: !isSidebarCollapsed ? "95%" : "75%" }}
        className="mainBodyOrgProducts"
      >
        <div style={{ padding: "20px" }}>
          <hr className="upperLine"></hr>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              // gap: "20px",
            }}
          >
            <Input
              placeholder="Search"
              className="searchText"
              prefix={
                <SearchOutlined
                  style={{
                    color: "rgba(0,0,0,.25)",
                    paddingRight: "10px",
                    width: "24px",
                    height: "24px",
                  }}
                />
              }
              id="current-input"
              onChange={handleSearch} // Handle input change
              style={{
                width: "250px",
                border: "none",
                fontSize: "15px",
                marginLeft: "15px",
                marginBottom: "10px",
              }}
            />

            <CustomSelect
              variant="single-select"
              options={activeUsers}
              customClass={"check"} // Apply your custom class here
              value={activeUser}
              handleChange={handleActiveUser}
            />

            <span className="activeUsers ">USER ID</span>
            <span className="activeUsers ">ORDER DATE</span>
            <span className="activeUsers ">Options</span>
          </div>

          {filteredProducts.map((product) => (
            <OrgProduct
              id={product.id}
              key={product.id}
              upperText={product.upperText}
              lowerText={product.lowerText}
              imgSrc={product.imgSrc}
              ActiveUsers={product.ActiveUsers}
              Numbers={product.Numbers}
              ourDate={product.ourDate}
              onDelete={() => handleDelete(product.id)}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default ChkingOrgProduct;
