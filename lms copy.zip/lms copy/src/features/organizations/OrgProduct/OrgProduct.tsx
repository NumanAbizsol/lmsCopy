import React, { useState, FC } from "react";
import "./OrgProduct.scss";
import CustomRadio from "../../../components/inputs/radio/Radio";
import { Menu, Dropdown, Button } from "antd";
import {
  CopyOutlined,
  DeleteOutlined,
  ExclamationCircleOutlined,
} from "@ant-design/icons";
import { Icon } from "@iconify/react";
import OverlayConfirmationModal from "./OverlayConfirmationModal";

interface OrgProductProps {
  id: number;
  upperText: string;
  lowerText: string;
  imgSrc: string;
  ActiveUsers: React.ReactNode;
  Numbers: React.ReactNode;
  ourDate: Date;
  onDelete: (id: number) => void;
}

const OrgProduct: FC<OrgProductProps> = ({
  id,
  upperText,
  lowerText,
  imgSrc,
  ActiveUsers,
  Numbers,
  ourDate,
  onDelete,
}) => {
  const [isModalVisible, setIsModalVisible] = useState(false);

  const handleDeleteConfirm = () => {
    setIsModalVisible(true);
  };

  const handleDelete = () => {
    onDelete(id);
    setIsModalVisible(false);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
  };

  const menu = (
    <Menu className="custom-card-menu" style={{ padding: "20px" }}>
      <Menu.Item key="delete">
        <Button icon={<DeleteOutlined />} onClick={handleDeleteConfirm} danger>
          Delete
        </Button>
      </Menu.Item>
      <Menu.Item key="duplicate">
        <Button icon={<CopyOutlined />}>Duplicate</Button>
      </Menu.Item>
    </Menu>
  );

  return (
    <div>
      <div>
        <div className="org-heading">
          <div className="RadioImageContent">
            <div>
              <CustomRadio />
            </div>

            <div className="user-avatar">
              <img style={{ width: "inherit" }} src={imgSrc} alt="User Icon" />
            </div>
            <div className="product-name">
              <h2>{upperText}</h2>

              <p>{lowerText}</p>
            </div>
          </div>

          <div className="activeUserNUmber">{ActiveUsers}</div>
          <div className="activeUserNUmber">{Numbers}</div>

          <div className="activeUserNUmber">{ourDate.toLocaleDateString()}</div>

          <Dropdown overlay={menu} trigger={["click"]}>
            <span
              style={{ cursor: "pointer" }}
              onClick={(e) => e.preventDefault()}
            >
              <Icon
                icon="ion:ellipsis-horizontal"
                height="24px"
                color="#828282"
              />
            </span>
          </Dropdown>

          <OverlayConfirmationModal
            heading={"Warning"}
            description={"Are you sure you want to delete?"}
            visible={isModalVisible}
            onCancel={handleCancel}
            onConfirm={handleDelete}
            IconComponent={ExclamationCircleOutlined}
          />
        </div>
      </div>
    </div>
  );
};

export default OrgProduct;
