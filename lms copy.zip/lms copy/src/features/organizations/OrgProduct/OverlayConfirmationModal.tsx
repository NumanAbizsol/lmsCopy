import "./confirmationModal.scss";
import CustomButton from "../../../components/shared/button/Button";

interface OverlayConfirmationModalProps {
  visible: boolean;
  onCancel: () => void;
  onConfirm: () => void;
  IconComponent: React.ElementType;
  heading: string;
  description: string;
  customStyle?: React.CSSProperties;
}

// const OverlayConfirmationModal = ({ visible, onCancel, onConfirm,IconComponent,heading,description,customStyle }) => {
const OverlayConfirmationModal: React.FC<OverlayConfirmationModalProps> = ({
  visible,
  onCancel,
  onConfirm,
  IconComponent,
  heading,
  description,
  customStyle,
}) => {
  // Component logic

  return (
    <>
    <div
      className="justify-center align-center "
      style={{
        display: visible ? "flex" : "none",
        position: "fixed",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        backgroundColor: "rgba(0, 0, 0, 0.5)",
        // backgroundColor:"red",
        zIndex: 1,
      }}
    >
      <div
        className="text-center p-50 overlay-content"
        style={{
          borderRadius: "8px",
          minWidth: "35%",
          // height: "12px",
          
          
        }}
      >
        {/* {{ fontSize: "100px", color: "orange" }} */}
        <div className=" m_t_10">
          <IconComponent
            style={
              customStyle ? customStyle : { fontSize: "100px", color: "orange" }
            }

            // style={customStyle ? customStyle : {{ fontSize: "100px", color: "orange" }} }
          />
          <h1 className="main-heading">{heading}</h1>
          <p className="paragraph m_t_10">{description}</p>
          <div
            className="divide-screen  justify-center gap-5 "
            style={{ marginTop: "15px" }}
          >
            <CustomButton onClick={onCancel} variant="secondary">
              Cancel
            </CustomButton>
            <CustomButton onClick={onConfirm} variant="primary">
              Confirm
            </CustomButton>
          </div>
        </div>
      </div>
    </div>
    </>
  );
};

export default OverlayConfirmationModal;
