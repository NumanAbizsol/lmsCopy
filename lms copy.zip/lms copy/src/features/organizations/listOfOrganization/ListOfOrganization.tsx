import React, { useState } from "react";
import "./ListOfOrganization.scss";
import {
  ListOfOrganizationData,
  monthlyPrices,
  yearlyPrices,
  rows,
} from "../../../constants/Constants";
import { Link, useNavigate } from "react-router-dom";
import back from "../../../assets/images/Back.png";

const ListOfOrganization = () => {
  const [selectedToggle, setSelectedToggle] = useState<string>("Monthly");
  const prices = selectedToggle === "Monthly" ? monthlyPrices : yearlyPrices;
  const [selectedPriceIndex, setSelectedPriceIndex] = useState<number | null>(
    null
  );
  const [isButtonHovered, setIsButtonHovered] = useState<number | null>(null);
  const [showContent, setShowContent] = useState<boolean>(false);
  const navigate = useNavigate();

  const handleToggleChange = (toggle: string) => {
    setSelectedToggle(toggle);
    setSelectedPriceIndex(null);
    setShowContent(false);
  };

  const handleRadioChange = (index: number) => {
    setSelectedPriceIndex(index);
    setShowContent(true);
  };

  const handleButtonClick = (index: number) => {
    setSelectedPriceIndex(index);
    navigate("/updated-org-dash-card");
  };

  return (
    <div id="ListOfOrganization-container">
      <Link to="/updated-organization-dashboard">
        <img src={back} alt="back-arrow" style={{ margin: "5px" }} />
      </Link>
      <div className="org-heading">
        <h1 className="main-heading">Select product</h1>
      </div>

      <div id="ListOfOrganization-content">
        {ListOfOrganizationData.map((row, index) => (
          <div key={index} id="organization-item">
            <div id="content-left">
              <div id="row-header">
                <h2>{row.heading}</h2>
                <input
                  type="radio"
                  name="organizationRadio"
                  onChange={() => handleRadioChange(index)}
                  checked={selectedPriceIndex === index}
                />
              </div>
              <p>{row.para}</p>
            </div>
          </div>
        ))}
      </div>

      {showContent && (
        <div>
          <div className="ListOfOrganization-toggle">
            <h3
              onClick={() => handleToggleChange("Monthly")}
              className={selectedToggle === "Monthly" ? "selected" : ""}
            >
              Monthly
            </h3>
            <h3
              onClick={() => handleToggleChange("Yearly")}
              className={selectedToggle === "Yearly" ? "selected" : ""}
            >
              Yearly
            </h3>
          </div>

          <div className="grid-container">
            {prices.map((item, index) => (
              <div key={index} className="grid-item">
                <div className="heading-wrapper">
                  <h1 style={{ color: "#10BAAC" }}>
                    {selectedPriceIndex !== null
                      ? prices[selectedPriceIndex].price
                      : item.price}
                  </h1>
                  <h6 style={{ color: "grey" }}>
                    {selectedPriceIndex !== null
                      ? prices[selectedPriceIndex].smallHeading
                      : item.smallHeading}
                  </h6>
                </div>
                <button
                  className={`button ${
                    isButtonHovered === index ? "hovered-button" : ""
                  }`}
                  onMouseEnter={() => setIsButtonHovered(index)}
                  onMouseLeave={() => setIsButtonHovered(null)}
                  onClick={() => handleButtonClick(index)}
                >
                  {selectedPriceIndex !== null
                    ? prices[selectedPriceIndex].buttonText
                    : item.buttonText}
                </button>
              </div>
            ))}

            {rows.slice(3).map((row, index) => (
              <div key={index} className="grid-item-inner-container">
                {row.imgSrc ? (
                  <div className="image-wrapper ">
                    <img
                      src={row.imgSrc}
                      alt={`Row ${index + 13} Image`}
                      className="custom-img-class"
                    />
                  </div>
                ) : (
                  <>
                    <div className="grid-item2">
                      <h3
                        style={{
                          textAlign: "center",
                          padding: "5px",
                          fontSize: "17px",
                        }}
                      >
                        {row.heading}
                      </h3>
                      <div className={"red"}>
                        <h2
                          style={{
                            textAlign: "left",
                            padding: "5px",
                            fontSize: "17px",
                          }}
                        >
                          {row.headings}
                        </h2>
                        <p>{row.para}</p>
                        <span
                          style={{
                            textAlign: "left",
                            display: "block",
                            padding: "5px",
                            color: "#858a9e",
                          }}
                        >
                          {row.para2}
                        </span>
                      </div>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ListOfOrganization;
