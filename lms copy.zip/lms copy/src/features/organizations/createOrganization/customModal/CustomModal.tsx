import React, { FC, ReactNode } from "react";
import "./CustomModal.scss";
import crossImage from "../../../../assets/images/cross ison.png";

// interface CustomModalProps {
//   isOpen: boolean;
//   onClose: () => void;
//   children: ReactNode;
//   customStyles?: React.CSSProperties;
// }

interface CustomModalProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode;  // Explicitly specify the type as React.ReactNode
  customStyles?: React.CSSProperties;
}

const CustomModal: React.FC<CustomModalProps> = ({
  isOpen,
  onClose,
  children,
}) => {
  if (!isOpen) {
    return null;
  }

  return (
    <div className="custom-modal">
      <div className="Modal-Content">
        <div className="close-icon" onClick={onClose}>
          <img src={crossImage} alt="Close" />
        </div>
        {children}
      </div>
    </div>
  );
};

export default CustomModal;





