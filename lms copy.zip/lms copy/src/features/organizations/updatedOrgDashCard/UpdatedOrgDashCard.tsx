import OrganizationCard from "../../../components/shared/OrganizationCard/OrganizationCard";
import { cardData } from "../../../constants/Constants";
import Book from "../../../assets/images/Book.png";
import Groups from "../../../assets/images/Groups.png";
import users from "../../../assets/images/users.png";
import { ReactComponent as MoreVertical } from "../../../assets/images/more-vertical.svg";
import { Menu, Dropdown, Space } from "antd";
import { Icon } from "@iconify/react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

import "./UpdatedOrgDashCard.scss";
import Sidebar from "../../../components/shared/headerAndTabs/sidebar/Sidebar";
const UpdatedOrgDashCard = () => {
  const menu = (
    <Menu>
      <Menu.Item key="1">
        <Space>
          <Icon icon="mdi:rename" height="20" />
          Rename
        </Space>
      </Menu.Item>
      <Menu.Item key="2">
        <Space>
          <Icon icon="mdi:delete" height="20" />
          Delete
        </Space>
      </Menu.Item>
    </Menu>
  );

  const [count, setCount] = useState(0);
  const [counter, setCounter] = useState(0);

  const handleImg1Click = () => {
    setCount(count + 1);
  };
  const handleImg2Click = () => {
    setCounter(counter + 1);
  };
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(true);
  const navigate = useNavigate();

  const handleImageClick = () => {
    navigate("/teacher");
  };
  return (
    <>
      <div style={{ display: "flex" }}>
        <div className="sidebar-wraper">
          <Sidebar
            isSidebarCollapsed={isSidebarCollapsed}
            setIsSidebarCollapsed={setIsSidebarCollapsed}
            isForOrganization={true}
          />
        </div>
        <div
          style={{ width: !isSidebarCollapsed ? "95%" : "75%" }}
          className="Updated-org-dash-card"
        >
          <div className="Updated-org-dash-welcome-section-card">
            <h1 className="main-heading ">Dashboard Coming Soon</h1>
            <p className="name-text-card">Let’s Explore your org !</p>
          </div>

          <div id="Updated-org-dash-cards">
            {cardData.map((card) => (
              <OrganizationCard
                key={card.id}
                imageUrl={card.imageUrl}
                title={card.title}
                description={card.description}
              />
            ))}
          </div>

          <div className="Updated-card-container ">
         
            <div className="Updated-display">
              <div
                className="Updated-book-img-container"
                onClick={handleImageClick}
              >
                <div>
                  <img src={Book} alt="Book" className="book-img-animation" />
                </div>
              </div>
              <Dropdown
                overlay={menu}
                placement="bottomRight"
                trigger={["click"]}
              >
                <MoreVertical
                  style={{
                    marginRight: "10px",
                    padding: "5px",
                    backgroundColor: "#F9FAFB",
                    borderRadius: "50%",
                  }}
                />
              </Dropdown>
            </div>

            <div>
              <div className="Updated-text">
                LMS
                <div className="Updated-btn">
                  <div className="Updated-btn-img">
                    <div className="Updated-left-side">
                      <div className="Updated-img1" onClick={handleImg1Click}>
                        <img src={Groups} alt="Group" className="group-img" />
                      </div>

                      <span className="Updated-counter">{count}</span>
                    </div>
                    <div>
                      <span className="Updated-line"></span>
                    </div>
                    <div className="Updated-right-side">
                      <div className="Updated-img2" onClick={handleImg2Click}>
                        <img src={users} alt="Users" className="users-img" />
                      </div>
                      <span className="Updated-counter">{counter}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default UpdatedOrgDashCard;
