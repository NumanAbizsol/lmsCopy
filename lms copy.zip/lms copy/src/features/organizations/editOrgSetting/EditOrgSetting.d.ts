import { validateThumbnail } from '../../../components/shared/formValidations/validation';
export  interface FormData {
  OrganizationName: string;
  OrgUrl: string;
  Thumbnail:string;
}


 export type FormData = {
  OrganizationName: string;
  OrgUrl: string;
  Thumbnail:string;
};