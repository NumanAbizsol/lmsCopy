import React, { useState, useRef, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import CustomInput from "../../../components/inputs/input/Input";
import uploadImgIcon from "../../../assets/images/upload.svg";
import { Modal } from "antd";
import ImageCropper from "../../../components/shared/ImageCropper/ImageCrop";
import CustomButton from "../../../components/shared/button/Button";
import { useNavigate } from "react-router-dom";
import "./EditOrgSetting.scss";
import { FormData } from "./EditOrgSetting.d";
import Sidebar from "../../../components/shared/headerAndTabs/sidebar/Sidebar";
import { validateThumbnail } from "../../../components/shared/formValidations/validation";
import {
  useAppDispatch,
  useAppSelector,
} from "../../../hooks/useTypedSelector";
import {
  updateOrganizationData,
  getOrganization,
  createOrganization,
} from "../../../redux/Slices/OrganizationSlice";

const EditOrgSetting: React.FC = () => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [src, setSrc] = useState<string>("");
  const [showCroppedImage, setShowCroppedImage] = useState<boolean>(false);
  const [ImgCropModalOpen, setImgCropModalOpen] = useState<boolean>(false);
  const [cropedImg, setCropedimg] = useState<string>("");
  const [formData, setFormData] = useState<FormData>({
    OrganizationName: "",
    OrgUrl: "",
    Thumbnail: "",
  });

  const dispatch = useAppDispatch();

  useEffect(() => {
    dispatch(getOrganization());
  }, [dispatch]);

  const navigate = useNavigate();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files && e.target.files[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        console.error("File size exceeds 2MB limit");
        return;
      }
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setSrc(result);
      };
      reader.readAsDataURL(file);
    }
    setImgCropModalOpen(true);
  };

  const openFileInput = () => {
    fileInputRef.current?.click();
  };

  const handleCropAndSave = () => {
    setShowCroppedImage(true);
    setImgCropModalOpen(false);
  };

  const handleCancel = () => {
    navigate("/organization-setting");
  };

  const { organization, loading, error }: any = useAppSelector(
    (state: any) => state.organization
  );
  useEffect(() => {
    setFormData((pre: any) => ({
      OrganizationName: organization[0]?.OrganizationName || "",
      OrgUrl: organization[0]?.OrgUrl || "",
      Thumbnail: organization[0]?.Thumbnail || "",
    }));
  }, [organization]);

  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(true);

  useEffect(() => {}, [formData]);

  const handleUpdateNow = () => {
    dispatch(createOrganization({ ...formData }));

    // setFormData((prev) => ({ ...prev, Thumbnail: cropedImg }));

    const handleOrganizationNameChange = (e: any) => {
      console.log(e.target);
      setFormData((pre) => ({ ...pre, OrganizationName: e.target.value }));
    };

    navigate("/organization-setting");
  };

  return (
    <>
      <div style={{ display: "flex" }}>
        <div className="sidebar-wraper">
          <Sidebar
            isSidebarCollapsed={isSidebarCollapsed}
            setIsSidebarCollapsed={setIsSidebarCollapsed}
            isForOrganization={true}
          />
        </div>
        <div
          style={{ width: !isSidebarCollapsed ? "95%" : "75%" }}
          className="edit-org-setting"
        >
          <h1 className="main-heading">Organization Settings</h1>
          <hr />
          <div className="Adding-user-form-inner">
            <div>
              <label htmlFor="firstName" className="input_label">
                Organization Name
              </label>

              <CustomInput
                placeholder="Organization Name"
                value={formData.OrganizationName}
                onChange={(e) =>
                  setFormData((pre) => ({
                    ...pre,
                    OrganizationName: e.target.value,
                  }))
                }
              />
            </div>

            <div>
              <label htmlFor="lastName" className="input_label">
                URL
              </label>
              <CustomInput
                placeholder="URL"
                value={organization[0]?.OrgUrl}
                disabled
              />
            </div>
          </div>

          <div>
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              id="thumbnailInput"
              className="Org_input_field"
              onChange={handleFileChange}
              style={{ display: "none" }}
              // value={organization[0]?.Thumbnail}
            />
            <p>
              <b style={{ color: "#343a40", marginTop: "5px" }}>Logo</b>: &nbsp;
              &nbsp;
              <br />
              {showCroppedImage ? (
                <img
                  className="org-logo"
                  src={cropedImg}
                  alt="Cropped Thumbnail"
                />
              ) : (
                <img
                  className="org-logo"
                  src={organization[0]?.Thumbnail}
                  alt="Logo"
                />
              )}
            </p>
            <CustomButton
              variant="secondary"
              className="Upload-edit-org"
              onClick={openFileInput}
            >
              <img src={uploadImgIcon} alt="" />
              &nbsp; Upload Thumbnail Png
            </CustomButton>
          </div>

          <Modal
            title="Crop Image"
            visible={ImgCropModalOpen}
            onCancel={() => setImgCropModalOpen(false)}
            footer={null}
          >
            <ImageCropper setCropedimg={setCropedimg} images={src} />
            <CustomButton
              variant="primary"
              onClick={handleCropAndSave}
              customStyle={{ marginTop: "15px" }}
            >
              Crop & Save
            </CustomButton>
          </Modal>

          {showCroppedImage && (
            <div className="cropped-image-row">
              <h2>Cropped Image</h2>
              <img src={cropedImg} alt="Cropped Thumbnail" />
            </div>
          )}
          <div className="right-align-buttons">
            <CustomButton
              variant="secondary"
              className="editOrgbutton"
              onClick={handleCancel}
            >
              Cancel
            </CustomButton>
            <CustomButton
              variant="primary"
              className="editOrgbutton"
              onClick={handleUpdateNow}
            >
              Update now
            </CustomButton>
          </div>
        </div>
      </div>
    </>
  );
};

export default EditOrgSetting;
