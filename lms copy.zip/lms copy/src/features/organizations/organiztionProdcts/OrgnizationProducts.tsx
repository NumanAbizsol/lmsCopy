import React, { useState } from "react";
import "./OrganizationProducts.scss";
import dashboard from "../../../assets/images/dashboard.svg";
import thumbnail from "../../../assets/images/Rectangle 151.svg";

import Tab from "../../../components/shared/headerAndTabs/Tabs";
import Card from "../../../components/shared/card/Card";
import StudentCourseCard from "../../../components/shared/studentCourseCard/studentCourseCard/StudentCourseCard";
// import StudentCard from "./studentCard/StudentCard";

type Props = {};
const courses = [
  {
    id: 1,
    thumbnail: {thumbnail},
    title: "Course Title 1",
    description: "Course Description 1",
    instructor: { name: "Instructor Name 1", image: "path-to-instructor-image-1.png" },
    rating: 4.5,
    enrolled: 120,
    price: "Free" // Assuming this course is free
  },
  {
    id: 2,
    thumbnail: {thumbnail},
    title: "Course Title 1",
    description: "Course Description 1",
    instructor: { name: "Instructor Name 1", image: "path-to-instructor-image-1.png" },
    rating: 4.5,
    enrolled: 120,
    price: "Free" // Assuming this course is free
  },
  {
    id: 1,
    thumbnail: {thumbnail},
    title: "Course Title 1",
    description: "Course Description 1",
    instructor: { name: "Instructor Name 1", image: "path-to-instructor-image-1.png" },
    rating: 4.5,
    enrolled: 120,
    price: "Free" // Assuming this course is free
  },

];
const OrgnizationProducts = (props: Props) => {
  const [isDashboard, setDashboard] = useState(true);
  const tabData = [{ name: "HRM" }, { name: "LMS" },{ name: "Ecom"}];
  const [selectedTab, setSelectedTab] = useState<number>(0);
  return (
    <div className="land-cont d-flex gap-10">
      <div className="org-cont1 d-flex  align-center">
        <div className="cont1-left">
          <div className="cont1-left-content d-flex gap-10">
            <h1 className="cont1-heading">Organization Title</h1>
            <p className="cont1-desc">Organization Description</p>
            <div className="d-flex gap-10">
              <button className="primary-btn">Get started</button>
              <button className="primary-btn secondary-btn">Learn More</button>
            </div>
            <p>Simple, fast and no credit card needed</p>
          </div>
        </div>
        <div className="cont1-right">
          <img src={dashboard} alt="dashboard" />
        </div>
      </div>
     <div style={{backgroundColor:'white',paddingLeft:'3rem',paddingRight:'3rem', display:'flex',flexDirection:'column',gap:'40px'}}>
     <div className="tab-container">
        <div className="d-flex justify-center tab-container1" style={{marginTop:'1.5rem'}}>
            <h1 className="cont1-heading">Organization Products</h1>
            <Tab
            tabData={tabData}
            selectedTab={selectedTab}
            setSelectedTab={setSelectedTab}
            className="tabs-main-container"
            />
        </div>
      </div>
      <div className="courses-cont">
        <h1 className="card-heading" >Courses</h1>
        <br /><br />
        <div className="card-container">
            {/* <StudentCard title={"course Title"} enrolled={"720"} description={"this is description"} rating={4.5}/> */}
           {/* <Card title={"title"} section={3} imageSrc={thumbnail} enrolledCount={20} /> */}
             {/* <Card title={"title1"} section={4}/> */}
             {
              courses.map((course: any) => (
              <div className="card-container ">
                  <StudentCourseCard
                  key={course.id}
                  thumbnail={course.thumbnail}
                  title={course.title}
                  description={course.description}
                  instructor={course.instructor}
                  price={course.price}
                  isFavourite={course.isFavourite}
                  isHidden={course.isHidden}
                  progress={course.progress}
                  isDashboard={isDashboard}
                />
              </div>
              ))
             }
        </div>
      </div>
      <div className="courses-cont">
        <h1 className="card-heading">Quizzes</h1>
        <br /><br />
        <div className="card-container">
            
             {
              courses.map((course: any) => (
              <div className="card-container ">
                  <StudentCourseCard
                  key={course.id}
                  thumbnail={course.thumbnail}
                  title={course.title}
                  description={course.description}
                  instructor={course.instructor}
                  price={course.price}
                  isFavourite={course.isFavourite}
                  isHidden={course.isHidden}
                  progress={course.progress}
                  isDashboard={isDashboard}
                />
              </div>
              ))
             }
        </div>
      </div>
      <div className="courses-cont">
        <h1 className="card-heading">FlashCards</h1>
        <br /><br />
        <div className="card-container">
            
             {
              courses.map((course: any) => (
              <div className="card-container ">
                  <StudentCourseCard
                  key={course.id}
                  thumbnail={course.thumbnail}
                  title={course.title}
                  description={course.description}
                  instructor={course.instructor}
                  price={course.price}
                  isFavourite={course.isFavourite}
                  isHidden={course.isHidden}
                  progress={course.progress}
                  isDashboard={isDashboard}
                />
              </div>
              ))
             }
        </div>
      </div>

     </div>
    </div>
  );
};

export default OrgnizationProducts;
