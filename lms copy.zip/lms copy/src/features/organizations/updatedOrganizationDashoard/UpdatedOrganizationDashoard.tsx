import React, { useState } from "react";
import "./updatedOrganizationDashoard.scss";
import OrganizationCard from "../../../components/shared/OrganizationCard/OrganizationCard";
import CustomButton from "../../../components/shared/button/Button";
import { cardData } from "../../../constants/Constants";
import { useNavigate } from "react-router-dom";
import Sidebar from "../../../components/shared/headerAndTabs/sidebar/Sidebar";
import usePermission from "../../../PermissionHook";

const UpdatedOrganizationDashoard = () => {
  const navigate = useNavigate();
  const [isTransitioning, setIsTransitioning] = useState(false);

  const handleAddProductClick = async () => {
    if (hasRole("admin") && hasPermissionForAction("CREATE_APP")) {
      setIsTransitioning(true);

      setTimeout(() => {
        setIsTransitioning(false);
        navigate("/list-of-orginzation");
      }, 500);
    }
  };
  const { hasRole, hasPermissionForAction } = usePermission();
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(true)

  return (
    <>
      <div style={{ display: "flex", flexDirection: "row" }}>
        <div
          className={`sidebar-wrapper ${
            isTransitioning ? "transitioning" : ""
          }`}
        >
          <Sidebar
            isSidebarCollapsed={isSidebarCollapsed}
            setIsSidebarCollapsed={setIsSidebarCollapsed}
            isForOrganization={true}
          />
        </div>
        <div
          style={{ width: !isSidebarCollapsed ? "95%" : "75%" }}
          className={`Updated-org-dash ${
            isTransitioning ? "transitioning" : ""
          }`}
        >
          <div className="update-dash-cont">
            <div className="text-container">
              <h1 className="main-heading">Dashboard Coming Soon</h1>
              <p className="name-text">Let’s Explore your org!</p>
            </div>
       
                <CustomButton
              variant="secondary"
              className={`AddProduct ${isTransitioning ? "transitioning" : ""}`}
              onClick={handleAddProductClick}
              customStyle={{
                background: "white",
                cursor: "pointer",
                height: "50px" 
              }}
              showPlusButton={true}
            >
                 Add Product
            </CustomButton>
          </div>

          <div id="Updated-org-dash-cards">
            {cardData.map((card) => (
              <OrganizationCard
                key={card.id}
                imageUrl={card.imageUrl}
                title={card.title}
                description={card.description}
              />
            ))}
          </div>

          <div className="Updated-org-dash-button">
            <h1 className="main-heading ">My Products</h1>
            <p className="name-text">No Products Added yet</p>
            {/* <CustomButton
              variant="secondary"
              className={`AddProduct ${isTransitioning ? "transitioning" : ""}`}
              onClick={handleAddProductClick}
              customStyle={{
                background: "white",
                cursor: "pointer",
              }}
            >
              {hasRole("admin") && hasPermissionForAction("CREATE_APP") ? <span className="icon-updated-org-dash">
                +<br /> Add Product
              </span> : "No permission to add Product!"}
            </CustomButton> */}
          </div>
        </div>
      </div>
    </>
  );
};

export default UpdatedOrganizationDashoard;
