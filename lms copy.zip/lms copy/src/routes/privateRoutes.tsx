import usePermission from "../PermissionHook";

export const PrivateRoute = ({
   Component,
  permission,
  roles = ["user"],
  ...rest
}: any) => {
  const { hasRole }: any = usePermission();
console.log(Component,roles)
  return (
    <>{hasRole(roles) ? <Component /> : <Component to="/unauthorized" />}</>
  );
};

;
