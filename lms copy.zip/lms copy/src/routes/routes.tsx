import React, { useState } from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Login from "../pages/auth/login/Login";
import Varification from "../pages/auth/login/varification/Varification";
import OtpPage from "../pages/auth/register/otpPage/OtpPage";
// import OtpPage from "../components/shared/mainProgressBar/MainProgressBar";
import ThankYou from "../pages/auth/register/thankYou/ThankYou";
import Dashboard from "../features/rawCode/dashboard/dashboard/Dashboard";
import UiElements from "../features/uiElements/UiElements";
import RoutesWrapper from "../routes/RoutesWrapper";
import Landingpage from "../features/landingPage/landingPage/LandingPage";
// import Courses from "../features/courses/Courses";
// import CourseBuilder from "../features/courseBuilder/CourseBuilder";
import PricingPlans from "../features/pricingPlans/pricingPlans/PricingPlans";
import Quizes from "../features/quizes/Quizes";
import QuizBuilder from "../features/quizBuilder/quizBuilder/QuizBuilder";
import Register from "../pages/auth/register/Register";
// import Register from "../"
import TeacherDashboard from "../features/teacherDashboard/dashboard/Dashboard";
// import SchoolDashboard from "../features/schools/schoolDashboard/SchoolDashboard";
import CoursesDashboard from "../features/teacherDashboard/createCourse/courseManagement/courseManagement";
import SelectYourSchool from "../features/rawCode/schools/selectYourSchoolTemplete/SelectYourSchoolTemplete";
import LearningProducts from "../features/rawCode/schools/flashcard/Flashcard";
import CreateCourse from "../features/teacherDashboard/createCourse/courseContainer/createCourse/CreateCourse";
import "../assets/styles/main.scss";
import OrganizationSetup from "../features/organizations/createOrganization/organization";
// import SchoolSetup from "../features/rawCode/schools/school/school";
import LmsSetup from "../features/lmsSetup/LmsSetup";
import Course from "../features/teacherDashboard/createCourse/courseContainer/course/Course";
import CourseContainer from "../features/teacherDashboard/createCourse/courseContainer/CourseContainer";
import OrganizationDashboard from "../features/organizations/organizationDashboard/DashBoard";
import Footer from "../components/shared/footer/Footer";
import PricingHeader from "../features/pricingPlans/pricingHeader/PricingHeader";
// import Header from "../components/shared/Header/Header";
import ListOfOrganization from "../features/organizations/listOfOrganization/ListOfOrganization";
import { PrivateRoute } from "./privateRoutes";
import usePermission from "../PermissionHook";
import CourseManagementModal from "../features/organizations/courseManagementModal/CourseManagementModal";
import CourseBuilderDashboard from "../features/teacherDashboard/courseDashboard/CourseDashboard";
import AddVideo from "../features/teacherDashboard/addVideo/AddVideo";
import QuizTypeSelection from "../features/quizes/quizTemplates/QuizTypeSelection";
import AddAudio from "../features/teacherDashboard/addAudio/AddAudio";
import AddPdf from "../features/teacherDashboard/addPdf/AddPdf";
import AddText from "../features/teacherDashboard/addText/AddText"
import CustomDashboard from "../components/shared/headerAndTabs/Header";

import QuizSetting from "../features/teacherDashboard/createCourse/courseContainer/quizSetting/QuizSetting";
import DripSchedule from "../features/teacherDashboard/dripSchedule/DripSchedule";
import SetDripSchedule from "../features/teacherDashboard/setDripSchedule/SetDripSchedule";
import StudentDashboard from "../features/studentDashboard/StudentDashboard";
import LandingPage from "../components/landingPage/LandingPage";
import ForgetPassword from "../pages/auth/login/forgetPassword/ForgetPassword";
import { useAppSelector } from "../hooks/useTypedSelector";
import CurrentUser from "../features/organizations/currentUser/CurrentUser";
import UpdatedOrganizationDashoard from "../features/organizations/updatedOrganizationDashoard/UpdatedOrganizationDashoard";
import UpdatedOrgDashCard from "../features/organizations/updatedOrgDashCard/UpdatedOrgDashCard";
import ChkingOrgProduct from "../features/organizations/OrgProduct/ChkingOrgProduct";
import OrganizationSetting from "../features/organizations/organizationSetting/OrganizationSetting";
import EditOrgSetting from "../features/organizations/editOrgSetting/EditOrgSetting";
import Header from '../components/shared/orgHeader/OrgHeader'
import StudentCoursePlayer from "../features/studentDashboard/studentCoursePlayer/StudnentCoursePlayer";
import CoursePlayer from "../features/studentDashboard/CoursePlayer/coursePlayer";
import ExamPlanStudent from "../features/student/dashboard/examPlan/ExamPlanStudent";
import FlashCard from "../features/teacherDashboard/flashcard/FlashCard";
import AddingFlashCard from "../features/teacherDashboard/flashcard/addingFlashCard/AddingFlashCard";
import FlashCardBuilder from "../features/teacherDashboard/flashCardBuilder/FlashCardBuilder";

function AppRoutes() {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const { hasPermissionForAction }: any = usePermission();
  const { user }: any = useAppSelector((state) => state.user);
  return (
    <div className="App">
      <Router>
        <Header />
        {/* <Header/> */}
        <RoutesWrapper>
          <Routes>
            <Route path="/" element={<LandingPage />} />

            <Route path="/otp" element={<OtpPage />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/varification" element={<Varification />} />
            <Route path="/forget-password" element={<ForgetPassword />} />
            <Route
              path="/course-builder"
              element={
                <CourseBuilderDashboard
                  isSidebarCollapsed={isSidebarCollapsed}
                />
              }
            />

            <Route path="/student-dashboard" element={<StudentDashboard />} />
            <Route path="/course-player" element={<CoursePlayer/>} />

            <Route path="/my-courses" element={<CoursesDashboard />} />
            <Route path="/my-player" element={<StudentCoursePlayer />} />
            <Route path="/my-courses/:id" element={<CreateCourse />} />
            <Route path="/organization" element={<OrganizationSetup />} />
            <Route path="/lms-setup" element={<LmsSetup />} />
            <Route
              path="/organization-dashboard"
              element={<OrganizationDashboard />}
            />
            <Route path="/teacher" element={<TeacherDashboard />} />
            <Route path="/quiz" element={<Quizes />} />

            <Route path="/quiztype" element={<QuizTypeSelection />} />
            <Route path="/thankyou" element={<ThankYou />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/landingpage" element={<Landingpage />} />
            <Route path="/ui-elements" element={<UiElements />} />
            <Route path="/teacher" element={<TeacherDashboard />} />
            {/* <Route path="/quiz" element={<Quizes />} /> */}
            <Route path="/quiz/:id" element={<QuizBuilder />} />





            
            <Route
              path="/course-builder"
              element={
                <CourseBuilderDashboard
                  isSidebarCollapsed={isSidebarCollapsed}
                />
              }
            />
            <Route path="/select-school" element={<SelectYourSchool />} />

            <Route
              path="/organization-dashboard"
              element={<OrganizationDashboard />}
            />
            <Route
              path="/list-of-orginzation"
              element={<ListOfOrganization />}
            />
            <Route
              path="/course-management-modal"
              element={<CourseManagementModal />}
            />
            <Route path="/addvideo" element={<AddVideo />} />
            <Route path="/addaudio" element={<AddAudio />} />
            <Route path="/addpdf" element={<AddPdf />} />
            <Route path="/addtext" element={<AddText />} />


            <Route path="/drip-schedule" element={<DripSchedule />} />
            <Route path="/set-drip-schedule" element={<SetDripSchedule />} />
            <Route path="/current-User" element={<CurrentUser />} />

            {hasPermissionForAction("ROUTE_CREATE_ORGANIZATION") ? (
              <>
                <Route path="/organization" element={<OrganizationSetup />} />
                <Route path="/lms-setup" element={<LmsSetup />} />
              </>
            ) : (
              <Route path="/updated-organization-dashboard" element={<OrganizationDashboard />} />
            )}
            <Route path="/otp" element={<OtpPage />} />
            <Route path="/login" element={<Login />} />
            <Route path="/student-dashboard" element={<StudentDashboard />} />
            <Route path="/student-examplan" element={<ExamPlanStudent />} />
            <Route path="/" element={<PricingPlans />} />

            <Route path="/kkk" element={<CourseContainer />} />
            <Route path="/wv" element={<PricingPlans />} />
            {/* <Route path="/sdd" element={<ImportBulkFile/>} /> */}
            <Route path="/my-courses" element={<CoursesDashboard />} />
            {/* <Route
              path="/course"
              element={
              <Course oncancelsave={() => {}} handlecourseChange={() => {}} />
              }
            /> */}
            <Route path="/current-User" element={<CurrentUser />} />
            <Route path="/addvideo" element={<AddVideo />} />
            <Route
              path="/updated-organization-dashboard"
              element={<UpdatedOrganizationDashoard />}
            />
            <Route
              path="/updated-org-dash-card"
              element={<UpdatedOrgDashCard />}
            />
            <Route
              path="/organization-setting"
              element={<OrganizationSetting />}
            />
            <Route path="/edit-org-setting" element={<EditOrgSetting />} />
            <Route path="/Org-Product-Check" element={<ChkingOrgProduct />} />
            
            <Route path="flashcard" element={<FlashCard/>}/>
            <Route path="add-flashcard" element={<AddingFlashCard/>}/>
            <Route path="/flashCard-builder" element={<FlashCardBuilder/>} />

          </Routes>
        </RoutesWrapper>
        {/* <Footer /> */}
      </Router>
    </div>
  );
}

export default AppRoutes;
